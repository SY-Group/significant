import { Client, Account } from 'appwrite';
import Constants from 'expo-constants';

const client = new Client()
    .setEndpoint('https://cloud.appwrite.io/v1') // Replace with your endpoint
    .setProject('67b885c3001537c4d7cf'); // Replace with your project ID

const account = new Account(client);

export { client, account };

// stores/locationStore.ts
import { create } from 'zustand';

interface LocationState {
    country: string | null;
    region: string | null;
    setLocation: (country: string, region: string) => void;
}

export const useLocationStore = create<LocationState>((set) => ({
    country: null,
    region: null,
    setLocation: (country, region) => set({ country, region }),
}));

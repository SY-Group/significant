// utils/appwrite.ts
import { Client, Account, Databases, ID } from 'react-native-appwrite';

const client = new Client()
    .setEndpoint('https://fra.cloud.appwrite.io/v1')
    .setProject('67b885c3001537c4d7cf');

const account = new Account(client);
const databases = new Databases(client);

export { client, account, databases, ID };

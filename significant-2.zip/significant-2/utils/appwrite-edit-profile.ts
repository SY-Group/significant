import { Client, Databases, ID } from 'appwrite';

export const client = new Client()
    .setEndpoint('https://fra.cloud.appwrite.io/v1') // Replace this
    .setProject('67b885c3001537c4d7cf'); // Replace this

export const databases = new Databases(client);
export const DATABASE_ID = '67b890b100131eecc7d6'; // Replace this
export const COLLECTION_ID = '6866dc11002e9f4ce58f';
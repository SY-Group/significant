import { Ionicons } from "@expo/vector-icons";
import { ImageSourcePropType } from "react-native";

// Definition of the interfaces and types used in the application
export interface IUser {
    id: string;
    email: string;
    phone?: string;
    name?: string;
    dob?: string;
    google_id?: string;
    is_email_verified?: boolean;
}

// Define the AuthState interface for Zustand
export interface IAuthState {
    user: IUser | null;
    loading: boolean;
    loadUser: () => Promise<void>;
    register: ({ name, dob, email, phone, password }: IRegisterFormData) => Promise<{ success: boolean, message: string }>;
    login: (email: string, password: string) => Promise<{ success: boolean, message: string }>;
    googleLogin?: () => Promise<boolean>;
    logout: () => Promise<{ success: boolean, message: string }>;
    checkAuthState: () => Promise<boolean>;
}

export interface ILoginFormData {
    email: string;
    password: string;
}

export interface IRegisterFormData extends ILoginFormData {
    name: string;
    dob: string;
    phone: string;
    confirmPassword?: string;
}

export interface INotification {
    $id: string;
    $createdAt: string;
    title: string;
    message: string;
    read_by: Array<string>;
}

export interface INotificationState {
    notifications: INotification[];
    unreadCount: number;
    isLoading: boolean;
    error: string | null;
    realTimeInitialize: boolean;

    // Notification actions
    fetchNotifications: (userId: string) => Promise<void>;
    markAsRead: (notificationId: string, userId: string) => Promise<void>;
    markAllAsRead: (userId: string) => Promise<void>;
    initializeNotifications: (userId: string) => void;
}

export interface IIPDetails {
    id: string,
        name: string,
        fullName?: string,
        tagline: string,
        logo: ImageSourcePropType,
        comingSoon: boolean
}

export type TIPtab = 'sports' | 'entertainments';

export interface IAccountScreenTab {
    title: string,
        componentName: string,
        icon: keyof typeof Ionicons.glyphMap,
}

export interface IdummyNotification {
    id: string,
        title: string,
        message: string,
        createdAt: string,
        read: boolean
}

export type TUploadFile = {
    uri: string;
    name: string;
    type: string;
    size: number;
};

export interface IupdateUser {
    name: string,
        gender: string,
        phone: string,
        dob: string
}
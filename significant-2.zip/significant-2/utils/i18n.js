import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import * as RNLocalize from 'react-native-localize';

const resources = {
    en: {
        translation: {
            myAccount: "My Account",
            profile: "Profile",
            password: "Password",
            language: "Language",
            logout: "Log out",
        },
    },
    ar: {
        translation: {
            myAccount: "حسابي",
            profile: "الملف الشخصي",
            password: "كلمة المرور",
            language: "اللغة",
            logout: "تسجيل خروج",
        },
    },
};

i18n
    .use(initReactI18next)
    .init({
        compatibilityJSON: 'v3',
        resources,
        lng: RNLocalize.getLocales()[0].languageCode.startsWith('ar') ? 'ar' : 'en',
        fallbackLng: 'en',
        interpolation: {
            escapeValue: false,
        },
    });

export default i18n;

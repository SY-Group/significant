// // utils/appwrite.ts
// import { Client, Account, Databases } from 'appwrite';
//
// const client = new Client();
//
// client
//     .setEndpoint('https://fra.cloud.appwrite.io/v1') // Replace with your endpoint
//     .setProject('67cdd84d0009a5120c76'); // Replace with your project ID
//
// const account = new Account(client);
// const databases = new Databases(client);
//
// export { account, databases };


import { Client, Databases } from 'react-native-appwrite';


export const config = {
    endpoint: process.env.EXPO_PUBLIC_APPWRITE_ENDPOINT,
    projectId: process.env.EXPO_PUBLIC_APPWRITE_PROJECT_ID,
}

export const client = new Client()
    .setEndpoint(config.endpoint!)
    .setProject(config.projectId!)

export const databases = new Databases(client);
import { IAccountScreenTab, IdummyNotification, IIPDetails } from "../utils/TS.constants";

export const SPORTS: Array<IIPDetails> = [
    {
        id: 't10-stcl',
        name: 'T10-STCL',
        fullName: 'T10 Super Tennis Cricket League',
        tagline: 'Fast, Fierce, Unstoppable Cricket Action!',
        logo: require('@/assets/images/t10stcl-card.webp'),
        comingSoon: false
    },
    {
        id: 'gl-60',
        name: 'GL-60',
        fullName: 'Global Legends 60',
        tagline: 'Where Legends Rise, Glory Never Ages!',
        logo: require('@/assets/images/global-legends-card.webp'),
        comingSoon: true,
    },
    {
        id: 'gaya-gladiators',
        name: 'Gaya Gladiators',
        fullName: 'Bihar Tennis Cricket League',
        tagline: 'Unleashing Power, Conquering Glory!',
        logo: require('@/assets/images/gaya-gladiators-card.webp'),
        comingSoon: true,
    },
];

export const ENTERTAINMENTS: Array<IIPDetails> = [
    {
        id: 'i-am-dance',
        name: 'I Am Dance',
        tagline: 'Feel the Rhythm, Live the Movement!',
        logo: require('@/assets/images/i-am-dance-card.webp'),
        comingSoon: true,
    },
    {
        id: 'tasavvur',
        name: 'Tasavvur',
        tagline: 'Imaging Beyond Boundaries!',
        logo: require('@/assets/images/tasavvur-card.webp'),
        comingSoon: true,
    },
    {
        id: 'zabt-e-ishq',
        name: 'Zabt-E-Ishq',
        tagline: 'Where Love Meets Destiny!',
        logo: require('@/assets/images/zabt-e-ishq-card.webp'),
        comingSoon: true,
    },
    {
        id: 'zindagi-aur-hum',
        name: 'Zindagi Aur Hum',
        tagline: 'Celebrating Life, Embracing Us!',
        logo: require('@/assets/images/zindagi-aur-hum-card.webp'),
        comingSoon: true,
    }
];

export const accountScreenTabs: Array<IAccountScreenTab> = [
    {
        title: 'Profile',
        componentName: '/(screens)/edit-profile',
        icon: 'person'
    },
    {
        title: 'Reset Password',
        componentName: '/(auth)/enter-email',
        icon: 'lock-closed'
    },
]

export const dummyNotifications: Array<IdummyNotification> = [
    {
        id: 'as1sg',
        title: "New Update for the app!",
        message: "Please visit our Significant Sports official website to download the latest update of our app",
        createdAt: '2025-03-02T12:00:00Z',
        read: false
    },
    {
        id: 'absd241d',
        title: "Are you ready for your first tournament match to play!",
        message: "Demo Message will appear here, hurray the message is showing here hurray the message is showing here ",
        createdAt: '2025-03-02T12:00:00Z',
        read: false
    },
    {
        id: 'ahd321',
        title: "Hey Anirban, congratulations 🎉 you're selected for the match",
        message: "Demo Message will appear here, hurray the message is showing here hurray the message is showing here",
        createdAt: '2025-03-02T12:00:00Z',
        read: true
    },
    {
        id: 'sdfh',
        title: "New Update for the app!",
        message: "Please visit our Significant Sports official website to download the latest update of our app",
        createdAt: '2025-03-02T12:00:00Z',
        read: true
    },
    {
        id: 'wre',
        title: "Are you ready for your first tournament match to play!",
        message: "Demo Message will appear here, hurray the message is showing here hurray the message is showing here",
        createdAt: '2025-03-02T12:00:00Z',
        read: true
    },
    {
        id: 'xhd',
        title: "Hey Anirban, congratulations 🎉 you're selected for the match",
        message: "Demo Message will appear here, hurray the message is showing here hurray the message is showing here",
        createdAt: '2025-03-02T12:00:00Z',
        read: true
    },
    {
        id: 'jst',
        title: "New Update for the app!",
        message: "Please visit our Significant Sports official website to download the latest update of our app",
        createdAt: '2025-03-02T12:00:00Z',
        read: true
    },
    {
        id: 'dfr',
        title: "Are you ready for your first tournament match to play!",
        message: "Demo Message will appear here, hurray the message is showing here hurray the message is showing here",
        createdAt: '2025-03-02T12:00:00Z',
        read: true
    },
    {
        id: 'aet',
        title: "Hey Anirban, congratulations 🎉 you're selected for the match",
        message: "Demo Message will appear here, hurray the message is showing here hurray the message is showing here",
        createdAt: '2025-03-02T12:00:00Z',
        read: true
    },
]


export const allSearchItems: Array<IIPDetails> = [
    ...SPORTS, ...ENTERTAINMENTS
]
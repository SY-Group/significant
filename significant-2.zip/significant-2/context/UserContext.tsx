// import React, { createContext, useContext, useState } from 'react';
//
// type UserContextType = {
//     email: string | null;
//     setEmail: (email: string | null) => void;
// };
//
// const UserContext = createContext<UserContextType>({
//     email: null,
//     setEmail: () => {},
// });
//
// export const UserProvider = ({ children }: { children: React.ReactNode }) => {
//     const [email, setEmail] = useState<string | null>(null);
//     return (
//         <UserContext.Provider value={{ email, setEmail }}>
//             {children}
//         </UserContext.Provider>
//     );
// };
//
// export const useUserContext = () => useContext(UserContext);


import React, { createContext, useContext, useState } from 'react';

type UserContextType = {
    email: string | null;
    setEmail: (email: string | null) => void;
    profileImage: string | null;
    setProfileImage: (uri: string | null) => void;
};

const UserContext = createContext<UserContextType>({
    email: null,
    setEmail: () => {},
    profileImage: null,
    setProfileImage: () => {},
});

export const UserProvider = ({ children }: { children: React.ReactNode }) => {
    const [email, setEmail] = useState<string | null>(null);
    const [profileImage, setProfileImage] = useState<string | null>(null);

    return (
        <UserContext.Provider value={{ email, setEmail, profileImage, setProfileImage }}>
            {children}
        </UserContext.Provider>
    );
};

export const useUserContext = () => useContext(UserContext);

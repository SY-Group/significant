import { StyleSheet } from 'react-native';

export const COLORS = {
    primary: '#FFA500',  // Primary theme color
    primaryBg: '#121212',  // Primary background color
    secondaryBg: '#131313',
    text: '#FFFFFF',  // Primary text color
    secondaryTxt: 'rgba(202, 203, 206, 0.63)',
    error: 'red',  // Error color
    success: 'green',
    overlay: '#FFFFFF1A', // Glass effect overlay color
    secondaryOverlay: '#FFFFFF2A',
    themeOverlay: '#FFA50073' // Glass effect with theme color overlay
};

export const BORDER = {
    primaryRadius: 8,
    secondaryRadius: 12,
}

export const FONTS = {
    primary: 'Inter', // Primary font
};

export default StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: COLORS.primaryBg,
        padding: 20,
        resizeMode: 'cover',
    },
    text: {
        fontSize: 16,
        color: COLORS.text,
        fontFamily: FONTS.primary,
    },
    button: {
        // marginTop: 10,
        backgroundColor: COLORS.primary,
        paddingHorizontal: 24,
        paddingVertical: 12,
        borderRadius: BORDER.primaryRadius,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        gap: 10,
    },
    buttonText: {
        color: 'black',
        fontWeight: 'bold',
        fontSize: 16,
        fontFamily: FONTS.primary,
        textAlign: 'center'
    },
    input: {
        backgroundColor: COLORS.overlay,
        borderWidth: 1,
        borderColor: '#222222',
        borderRadius: BORDER.primaryRadius,
        fontSize: 14,
        color: COLORS.text,
        paddingHorizontal: 12,
        paddingVertical: 8,
        marginBottom: 20,
    },
    title: {
        fontSize: 28,
        color: COLORS.text,
        fontWeight: 'bold',
        textAlign: 'center',
    },
    titleOrange: {
        color: COLORS.primary,
    },
    comingSoon: {
        position: "absolute",
        top: 0,
        right: 1,
        bottom: 0,
        paddingInline: 5,
        paddingBlock: 2,
        backgroundColor: COLORS.overlay,
        zIndex: 1,
        justifyContent: 'center'
    },
    comingSoonTxt: {
        textAlign: 'center',
        textTransform: 'uppercase',
        fontSize: 6,
        fontWeight: 'bold',
        letterSpacing: 1,
        color: COLORS.primary,
    },
    errMsg: {
        color: COLORS.error,
        fontSize: 12,
        marginTop: -15,
    },
});
import React, { useState } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    FlatList,
    Image,
} from 'react-native';
import { FontAwesome } from '@expo/vector-icons';
import { useRouter } from 'expo-router';

export default function IntellectualPropertiesScreen() {
    const [activeTab, setActiveTab] = useState("Entertainment");
    const router = useRouter();

    const handleSports = () => {
        router.push('../IP/IP-1');
    };

    const data = [
        {
            id: "1",
            title: "I am Dance",
            image: require('@/assets/images/i-am-dance-card.webp'),
        },
        {
            id: "2",
            title: "Tasavvur",
            image: require('@/assets/images/tasavvur-card.webp'),
        },
        {
            id: "3",
            title: "Zabt-E-Ishq",
            image: require('@/assets/images/zabt-e-ishq-card.webp'),
        },
        {
            id: "4",
            title: "Zindagi Aur Hum",
            image: require('@/assets/images/zindagi-aur-hum-card.webp'),
        },
    ];

    const renderCard = ({ item }) => {
        const handlePress = () => {
            if (item.title === 'I am Dance') {
                router.push('../../Register-IamDance/Register-IAD'); // ✅ Adjust this path as per your routing
            }
        };

        return (
            <TouchableOpacity onPress={handlePress} activeOpacity={0.85} style={styles.card}>
                <Image source={item.image} style={styles.cardImage} />
                <View style={styles.cardContent}>
                    <Text style={styles.cardTitle}>{item.title}</Text>
                </View>
            </TouchableOpacity>
        );
    };

    return (
        <View style={styles.container}>
            <Text style={styles.title}>Intellectual Properties</Text>

            {/* Tabs */}
            <View style={styles.tabsContainer}>
                <TouchableOpacity
                    style={[
                        styles.tabButton,
                        activeTab === "Sports" && styles.activeTab,
                    ]}
                    onPress={handleSports}
                >
                    <Text
                        style={[
                            styles.tabText,
                            activeTab === "Sports" && styles.activeTabText,
                        ]}
                    >
                        Sports
                    </Text>
                </TouchableOpacity>
                <TouchableOpacity
                    style={[
                        styles.tabButton,
                        activeTab === "Entertainment" && styles.activeTab,
                    ]}
                    onPress={() => setActiveTab("Entertainment")}
                >
                    <Text
                        style={[
                            styles.tabText,
                            activeTab === "Entertainment" && styles.activeTabText,
                        ]}
                    >
                        Entertainment
                    </Text>
                </TouchableOpacity>
            </View>

            {/* List */}
            <FlatList
                data={data}
                renderItem={renderCard}
                keyExtractor={(item) => item.id}
                contentContainerStyle={styles.listContainer}
            />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#121212',
        paddingVertical: 50,
    },
    title: {
        fontSize: 20,
        fontWeight: 'bold',
        color: '#fff',
        textAlign: 'center',
        marginBottom: 50,
    },
    tabsContainer: {
        flexDirection: 'row',
        justifyContent: 'center',
        marginBottom: 20,
    },
    tabButton: {
        paddingVertical: 15,
        paddingHorizontal: 20,
        borderRadius: 5,
        width: '44%',
        backgroundColor: '#1E1E1E',
        marginHorizontal: 4,
    },
    activeTab: {
        backgroundColor: '#333',
    },
    tabText: {
        fontSize: 14,
        alignSelf: 'center',
        color: '#fff',
    },
    activeTabText: {
        color: '#fff',
        fontWeight: 'bold',
    },
    listContainer: {
        paddingHorizontal: 20,
    },
    card: {
        flexDirection: 'row',
        backgroundColor: '#2c2c2c',
        borderRadius: 12,
        padding: 20,
        marginBottom: 20,
    },
    cardImage: {
        width: 80,
        height: 80,
        borderRadius: 10,
    },
    cardContent: {
        marginLeft: 20,
        justifyContent: 'center',
    },
    cardTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#fff',
    },
});


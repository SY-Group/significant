// app/lib/notifications.ts
// import * as Notifications from 'expo-notifications';
// import * as Device from 'expo-device';
// import { Platform } from 'react-native';
//
// // Configure foreground notifications
// Notifications.setNotificationHandler({
//     handleNotification: async () => {
//         return {
//             shouldShowAlert: true,
//             shouldPlaySound: true,
//             shouldSetBadge: false,
//         };
//     },
// });
//
// export async function registerForPushNotificationsAsync(): Promise<string | null> {
//     if (!Device.isDevice) {
//         alert('Must use physical device for Push Notifications');
//         return null;
//     }
//
//     const { status: existingStatus } = await Notifications.getPermissionsAsync();
//     let finalStatus = existingStatus;
//
//     if (existingStatus !== 'granted') {
//         const { status } = await Notifications.requestPermissionsAsync();
//         finalStatus = status;
//     }
//
//     if (finalStatus !== 'granted') {
//         alert('Failed to get push token');
//         return null;
//     }
//
//     const tokenResponse = await Notifications.getDevicePushTokenAsync();
//     const token = tokenResponse.data;
//     console.log('Device Push Token:', token);
//
//     if (Platform.OS === 'android') {
//         await Notifications.setNotificationChannelAsync('default', {
//             name: 'default',
//             importance: Notifications.AndroidImportance.MAX,
//             sound: 'default',
//         });
//     }
//
//     return token;
// }










// services/notificationService.ts
// import * as Notifications from 'expo-notifications';
// import * as Device from 'expo-device';
// import { Platform } from 'react-native';
//
// export async function registerForPushNotificationsAsync(): Promise<string | null> {
//     if (!Device.isDevice) {
//         alert('Must use physical device for Push Notifications');
//         return null;
//     }
//
//     const { status: existingStatus } = await Notifications.getPermissionsAsync();
//     let finalStatus = existingStatus;
//
//     if (existingStatus !== 'granted') {
//         const { status } = await Notifications.requestPermissionsAsync();
//         finalStatus = status;
//     }
//
//     if (finalStatus !== 'granted') {
//         alert('Failed to get push token for push notification!');
//         return null;
//     }
//
//     const tokenData = await Notifications.getExpoPushTokenAsync();
//     console.log('Expo Push Token:', tokenData.data);
//
//     return tokenData.data;
// }




// import * as Notifications from 'expo-notifications';
// import * as Device from 'expo-device';
// import { Platform } from 'react-native';
// import { databases, account } from '../../utils/appwrite'; // Appwrite setup
// import { ID } from 'appwrite';
//
// /**
//  * Register for Expo Push Notifications and save the token to Appwrite.
//  */
// export async function registerAndSavePushToken(): Promise<void> {
//     if (!Device.isDevice) {
//         alert('Must use physical device for Push Notifications');
//         return;
//     }
//
//     try {
//         // Request permissions
//         const { status: existingStatus } = await Notifications.getPermissionsAsync();
//         let finalStatus = existingStatus;
//
//         if (existingStatus !== 'granted') {
//             const { status } = await Notifications.requestPermissionsAsync();
//             finalStatus = status;
//         }
//
//         if (finalStatus !== 'granted') {
//             alert('Failed to get push token for push notification!');
//             return;
//         }
//
//         // Get Expo push token
//         const tokenData = await Notifications.getExpoPushTokenAsync();
//         const token = tokenData.data;
//         console.log('Expo Push Token:', token);
//
//         // Get logged-in Appwrite user
//         const user = await account.get();
//         const userId = user.$id;
//
//         // Save to Appwrite database
//         await savePushTokenToAppwrite(token, userId);
//
//     } catch (error) {
//         console.error('Error during push token registration:', error);
//     }
// }
//
// /**
//  * Save the push token into Appwrite database.
//  */
// async function savePushTokenToAppwrite(token: string, userId: string) {
//     try {
//         const response = await databases.createDocument(
//             '67cdd8dc00346c416657',     // Replace with your Appwrite Database ID
//             '67cdd942003adadc8498',   // Replace with your Collection ID (e.g., 'push_tokens')
//             ID.unique(),
//             {
//                 userId: userId,
//                 token: token,
//                 platform: Platform.OS,
//             }
//         );
//         console.log('Push token saved to Appwrite:', response);
//     } catch (error) {
//         console.error('Failed to save token to Appwrite:', error);
//     }
// }

import * as Device from 'expo-device';
import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';
import Constants from 'expo-constants';

// Configure how notifications appear when the app is in the foreground
Notifications.setNotificationHandler({
    handleNotification: async () => ({
        shouldShowAlert: true,
        shouldPlaySound: true,
        shouldSetBadge: true,
    }),
});

// Register for push notifications
export async function registerForPushNotificationsAsync() {
    let token;

    if (Platform.OS === 'web') {
        // Web doesn't support push notifications yet
        return null;
    }

    if (Device.isDevice) {
        // Check if we have permission
        const { status: existingStatus } = await Notifications.getPermissionsAsync();
        let finalStatus = existingStatus;

        // If we don't have permission, ask for it
        if (existingStatus !== 'granted') {
            const { status } = await Notifications.requestPermissionsAsync();
            finalStatus = status;
        }

        // If we still don't have permission, return
        if (finalStatus !== 'granted') {
            console.log('Failed to get push token for push notification!');
            return null;
        }

        // Get the token
        token = await Notifications.getExpoPushTokenAsync({
            projectId: Constants.expoConfig?.extra?.eas?.projectId,
        });
    } else {
        console.log('Must use physical device for Push Notifications');
    }

    // Set up notification channels for Android
    if (Platform.OS === 'android') {
        Notifications.setNotificationChannelAsync('default', {
            name: 'default',
            importance: Notifications.AndroidImportance.MAX,
            vibrationPattern: [0, 250, 250, 250],
            lightColor: '#FF231F7C',
        });
    }

    return token?.data;
}

// Send a local notification (for testing)
export async function sendLocalNotification(title: string, body: string) {
    await Notifications.scheduleNotificationAsync({
        content: {
            title: title || "📣 New Notification",
            body: body || "You have a new update",
            sound: 'default',
        },
        trigger: null, // null means send immediately
    });
}

// Add a notification listener
export function addNotificationListener(
    callback: (notification: Notifications.Notification) => void
) {
    return Notifications.addNotificationReceivedListener(callback);
}

// Add a notification response listener (when user taps notification)
export function addNotificationResponseListener(
    callback: (response: Notifications.NotificationResponse) => void
) {
    return Notifications.addNotificationResponseReceivedListener(callback);
}


// lib/createNotification.ts
import { ID } from 'react-native-appwrite';
import { databases } from '@/utils/appwrite';
import Constants from 'expo-constants';

const DB_ID = process.env.EXPO_PUBLIC_APPWRITE_DB_ID;
const COLLECTION_ID = process.env.EXPO_PUBLIC_APPWRITE_NOTIFICATIONS_COLLECTION_ID;

export async function createNotification(userId: string, title: string, message: string) {
    try {
        const res = await databases.createDocument(
            DB_ID,
            COLLECTION_ID,
            ID.unique(),
            {
                title,
                message,
                userId,
                read_by: [],
            }
        );
        console.log('✅ Notification created:', res);
    } catch (err) {
        console.error('❌ Error creating notification:', err);
    }
}

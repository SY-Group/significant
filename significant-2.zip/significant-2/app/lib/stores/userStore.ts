// lib/stores/userStore.ts
import { create } from 'zustand';

interface UserState {
    appwriteUserId: string | null;
    setAppwriteUserId: (id: string) => void;
}

export const useUserStore = create<UserState>((set) => ({
    appwriteUserId: null,
    setAppwriteUserId: (id) => set({ appwriteUserId: id }),
}));

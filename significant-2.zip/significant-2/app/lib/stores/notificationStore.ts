// import { create } from 'zustand';
// import { Query } from 'react-native-appwrite';
// import { client, databases } from '@/utils/appwrite';
// import { INotification, INotificationState } from '@/utils/TS.constants';
// import { sendLocalNotification } from '../notifications';
//
// export const useNotificationStore = create<INotificationState>((set, get) => ({
//     notifications: [],
//     unreadCount: 0,
//     isLoading: false,
//     error: null,
//     realTimeInitialize: false,
//
//     fetchNotifications: async (userId: string) => {
//         set({ isLoading: true, error: null });
//         try {
//             const response = await databases.listDocuments(
//                 process.env.EXPO_PUBLIC_APPWRITE_DB_ID!,
//                 process.env.EXPO_PUBLIC_APPWRITE_NOTIFICATION_COLLECTION_ID!,
//                 [
//                     Query.orderDesc('$createdAt'),
//                 ]
//             );
//
//             const notifications = response.documents as unknown as INotification[];
//             const unreadCount = notifications.filter(notification => !notification.read_by.includes(userId)).length;
//
//             set({
//                 notifications,
//                 unreadCount,
//                 isLoading: false,
//             });
//         } catch (error: any) {
//             set({
//                 error: error.message,
//                 isLoading: false,
//             });
//         }
//     },
//
//     markAsRead: async (notificationId, userId) => {
//         const notifications = get().notifications;
//
//         const CurrentNotificationInd = notifications.findIndex((notification) => notification.$id == notificationId);
//         try {
//             await databases.updateDocument(
//                 process.env.EXPO_PUBLIC_APPWRITE_DB_ID!,
//                 process.env.EXPO_PUBLIC_APPWRITE_NOTIFICATION_COLLECTION_ID!,
//                 notificationId,
//                 {
//                     // push userId in read_by
//                     read_by: [...notifications[CurrentNotificationInd].read_by, userId],
//                 }
//             );
//
//
//             // Update local state
//             const newNotifications = notifications.map(notification =>
//                 notification.$id === notificationId
//                     ? { ...notification, read_by: [...notification.read_by, userId] }
//                     : notification
//             );
//
//             const unreadCount = newNotifications.filter(notification => !notification.read_by.includes(userId)).length;
//
//             set({
//                 notifications: newNotifications,
//                 unreadCount,
//             });
//         } catch (error: any) {
//             console.log('error:', error)
//             set({ error: error.message });
//         }
//     },
//
//     markAllAsRead: async (userId) => {
//         set({ isLoading: true, error: null });
//         try {
//             // This would ideally be a batch operation, but for simplicity we'll update one by one
//             const unreadNotifications = get().notifications.filter(notification => !notification.read_by.includes(userId));
//
//             for (const notification of unreadNotifications) {
//                 await databases.updateDocument(
//                     process.env.EXPO_PUBLIC_APPWRITE_DB_ID!,
//                     process.env.EXPO_PUBLIC_APPWRITE_NOTIFICATION_COLLECTION_ID!,
//                     notification.$id,
//                     {
//                         read_by: [...notification.read_by, userId],
//                     }
//                 );
//             }
//
//             // Update local state
//             const notifications = get().notifications.map(notification => ({ ...notification, read: true }));
//
//             set({
//                 notifications,
//                 unreadCount: 0,
//                 isLoading: false,
//             });
//         } catch (error: any) {
//             set({
//                 error: error.message,
//                 isLoading: false,
//             });
//         }
//     },
//
//     initializeNotifications: async (userId) => {
//         if (get().realTimeInitialize) return;
//         // Fetch initial notifications
//         get().fetchNotifications(userId);
//
//
//         // Subscribe to realtime updates using client.subscribe instead of Realtime constructor
//         try {
//             client.subscribe(`databases.${process.env.EXPO_PUBLIC_APPWRITE_DB_ID!}.collections.${process.env.EXPO_PUBLIC_APPWRITE_NOTIFICATION_COLLECTION_ID!}.documents`, async (response: any) => {
//
//                 if (response.events.includes('databases.*.collections.*.documents.*.create')) {
//                     // A new notification was created
//                     const newNotification = response.payload as unknown as INotification;
//
//                     set(state => ({
//                         notifications: [newNotification, ...state.notifications],
//                         unreadCount: state.unreadCount + 1,
//                     }));
//
//                     // 🔔 Trigger local push notification
//                     await sendLocalNotification(newNotification.title, newNotification.message);
//
//
//                 } else if (response.events.includes('databases.*.collections.*.documents.*.update')) {
//
//                     // A notification was updated
//                     const updatedNotification = response.payload as unknown as INotification;
//
//                     set(state => {
//                         const notifications = state.notifications.map(notification =>
//                             notification.$id === updatedNotification.$id
//                                 ? updatedNotification
//                                 : notification
//                         );
//                         const unreadCount = notifications.filter(notification => !notification.read_by.includes(userId)).length;
//
//                         return {
//                             notifications,
//                             unreadCount,
//                         };
//                     });
//                 }
//             });
//             set({ realTimeInitialize: true });
//         } catch (error) {
//             console.error('Failed to subscribe to realtime updates:', error);
//         }
//     },
// }));


















// import { create } from 'zustand';
// import { Query, ID } from 'react-native-appwrite';
// import { client, databases } from '@/utils/appwrite';
// import { sendLocalNotification } from '../notifications';
//
// // Define notification type
// export interface INotification {
//     $id: string;
//     userId: string;
//     title: string;
//     message: string;
//     $createdAt: string;
//     read_by: string[];
// }
//
// export interface INotificationState {
//     notifications: INotification[];
//     unreadCount: number;
//     isLoading: boolean;
//     error: string | null;
//     realTimeInitialize: boolean;
//     fetchNotifications: (userId: string) => Promise<void>;
//     markAsRead: (notificationId: string, userId: string) => Promise<void>;
//     markAllAsRead: (userId: string) => Promise<void>;
//     clearAllNotifications: (userId: string) => Promise<void>;
//     initializeNotifications: (userId: string) => Promise<void>;
// }
//
// export const useNotificationStore = create<INotificationState>((set, get) => ({
//     notifications: [],
//     unreadCount: 0,
//     isLoading: false,
//     error: null,
//     realTimeInitialize: false,
//
//     fetchNotifications: async (userId: string) => {
//         set({ isLoading: true, error: null });
//         try {
//             const response = await databases.listDocuments(
//                 process.env.EXPO_PUBLIC_APPWRITE_DB_ID!,
//                 process.env.EXPO_PUBLIC_APPWRITE_NOTIFICATIONS_COLLECTION_ID!,
//                 [
//                     Query.equal('userId', [userId]),
//                     Query.orderDesc('$createdAt'),
//                 ]
//             );
//             const notifications = response.documents as INotification[];
//             const unreadCount = notifications.filter(n => !n.read_by.includes(userId)).length;
//             set({ notifications, unreadCount, isLoading: false });
//         } catch (error: any) {
//             set({ error: error.message, isLoading: false });
//         }
//     },
//
//     markAsRead: async (notificationId, userId) => {
//         const notifications = get().notifications;
//         const index = notifications.findIndex(n => n.$id === notificationId);
//         if (index === -1) return;
//         try {
//             await databases.updateDocument(
//                 process.env.EXPO_PUBLIC_APPWRITE_DB_ID!,
//                 process.env.EXPO_PUBLIC_APPWRITE_NOTIFICATIONS_COLLECTION_ID!,
//                 notificationId,
//                 {
//                     read_by: [...notifications[index].read_by, userId],
//                 }
//             );
//             const updated = notifications.map(n =>
//                 n.$id === notificationId
//                     ? { ...n, read_by: [...n.read_by, userId] }
//                     : n
//             );
//             const unreadCount = updated.filter(n => !n.read_by.includes(userId)).length;
//             set({ notifications: updated, unreadCount });
//         } catch (error: any) {
//             set({ error: error.message });
//         }
//     },
//
//     markAllAsRead: async (userId) => {
//         set({ isLoading: true, error: null });
//         const unread = get().notifications.filter(n => !n.read_by.includes(userId));
//         try {
//             for (const n of unread) {
//                 await databases.updateDocument(
//                     process.env.EXPO_PUBLIC_APPWRITE_DB_ID!,
//                     process.env.EXPO_PUBLIC_APPWRITE_NOTIFICATIONS_COLLECTION_ID!,
//                     n.$id,
//                     {
//                         read_by: [...n.read_by, userId],
//                     }
//                 );
//             }
//             const updated = get().notifications.map(n => ({ ...n, read_by: [...n.read_by, userId] }));
//             set({ notifications: updated, unreadCount: 0, isLoading: false });
//         } catch (error: any) {
//             set({ error: error.message, isLoading: false });
//         }
//     },
//
//     clearAllNotifications: async (userId) => {
//         set({ isLoading: true, error: null });
//         const userNotifications = get().notifications.filter(n => n.userId === userId);
//         try {
//             for (const notification of userNotifications) {
//                 await databases.deleteDocument(
//                     process.env.EXPO_PUBLIC_APPWRITE_DB_ID!,
//                     process.env.EXPO_PUBLIC_APPWRITE_NOTIFICATIONS_COLLECTION_ID!,
//                     notification.$id
//                 );
//             }
//             set({ notifications: [], unreadCount: 0, isLoading: false });
//         } catch (error: any) {
//             set({ error: error.message, isLoading: false });
//         }
//     },
//
//     initializeNotifications: async (userId) => {
//         if (get().realTimeInitialize) return;
//         await get().fetchNotifications(userId);
//
//         try {
//             client.subscribe(
//                 `databases.${process.env.EXPO_PUBLIC_APPWRITE_DB_ID!}.collections.${process.env.EXPO_PUBLIC_APPWRITE_NOTIFICATIONS_COLLECTION_ID!}.documents`,
//                 async (response: any) => {
//                     if (response.events.includes('databases.*.collections.*.documents.*.create')) {
//                         const newNotification = response.payload as INotification;
//                         if (newNotification.userId !== userId) return;
//
//                         set(state => ({
//                             notifications: [newNotification, ...state.notifications],
//                             unreadCount: state.unreadCount + 1,
//                         }));
//                         await sendLocalNotification(newNotification.title, newNotification.message);
//                     }
//                     if (response.events.includes('databases.*.collections.*.documents.*.update')) {
//                         const updatedNotification = response.payload as INotification;
//                         set(state => {
//                             const updated = state.notifications.map(n =>
//                                 n.$id === updatedNotification.$id ? updatedNotification : n
//                             );
//                             const unreadCount = updated.filter(n => !n.read_by.includes(userId)).length;
//                             return { notifications: updated, unreadCount };
//                         });
//                     }
//                 }
//             );
//             set({ realTimeInitialize: true });
//         } catch (error) {
//             console.error('Realtime subscription failed:', error);
//         }
//     },
// }));

import { create } from 'zustand';
import { Query, ID } from 'react-native-appwrite';
import { client, databases } from '@/utils/appwrite';
import { sendLocalNotification } from '../notifications';

// Define notification type
export interface INotification {
    $id: string;
    userId: string;
    title: string;
    message: string;
    $createdAt: string;
    read_by: string[];
}

export interface INotificationState {
    notifications: INotification[];
    unreadCount: number;
    isLoading: boolean;
    error: string | null;
    realTimeInitialize: boolean;
    fetchNotifications: (clerkId?: string, appwriteId?: string) => Promise<void>;
    markAsRead: (notificationId: string, userId: string) => Promise<void>;
    markAllAsRead: (userId: string) => Promise<void>;
    clearAllNotifications: (userId: string) => Promise<void>;
    initializeNotifications: (clerkId?: string, appwriteId?: string) => Promise<void>;
}

export const useNotificationStore = create<INotificationState>((set, get) => ({
    notifications: [],
    unreadCount: 0,
    isLoading: false,
    error: null,
    realTimeInitialize: false,

    fetchNotifications: async (clerkId?: string, appwriteId?: string) => {
        set({ isLoading: true, error: null });
        try {
            const response = await databases.listDocuments(
                process.env.EXPO_PUBLIC_APPWRITE_DB_ID!,
                process.env.EXPO_PUBLIC_APPWRITE_NOTIFICATIONS_COLLECTION_ID!,
                [
                    Query.orderDesc('$createdAt'),
                ]
            );

            const userIds = [clerkId, appwriteId].filter(Boolean);

            const allNotifications = response.documents as INotification[];

            const userNotifications = allNotifications.filter(n =>
                userIds.includes(n.userId)
            );

            const unreadCount = userNotifications.filter(n =>
                !n.read_by.some(id => userIds.includes(id))
            ).length;

            set({ notifications: userNotifications, unreadCount, isLoading: false });
        } catch (error: any) {
            set({ error: error.message, isLoading: false });
        }
    },

    markAsRead: async (notificationId, userId) => {
        const notifications = get().notifications;
        const index = notifications.findIndex(n => n.$id === notificationId);
        if (index === -1) return;
        try {
            if (!notifications[index].read_by.includes(userId)) {
                await databases.updateDocument(
                    process.env.EXPO_PUBLIC_APPWRITE_DB_ID!,
                    process.env.EXPO_PUBLIC_APPWRITE_NOTIFICATIONS_COLLECTION_ID!,
                    notificationId,
                    {
                        read_by: [...notifications[index].read_by, userId],
                    }
                );
                const updated = notifications.map(n =>
                    n.$id === notificationId
                        ? { ...n, read_by: [...n.read_by, userId] }
                        : n
                );
                const unreadCount = updated.filter(n =>
                    !n.read_by.includes(userId)
                ).length;
                set({ notifications: updated, unreadCount });
            }
        } catch (error: any) {
            set({ error: error.message });
        }
    },

    markAllAsRead: async (userId) => {
        set({ isLoading: true, error: null });
        const unread = get().notifications.filter(n => !n.read_by.includes(userId));
        try {
            for (const n of unread) {
                await databases.updateDocument(
                    process.env.EXPO_PUBLIC_APPWRITE_DB_ID!,
                    process.env.EXPO_PUBLIC_APPWRITE_NOTIFICATIONS_COLLECTION_ID!,
                    n.$id,
                    {
                        read_by: [...n.read_by, userId],
                    }
                );
            }
            const updated = get().notifications.map(n =>
                n.read_by.includes(userId)
                    ? n
                    : { ...n, read_by: [...n.read_by, userId] }
            );
            set({ notifications: updated, unreadCount: 0, isLoading: false });
        } catch (error: any) {
            set({ error: error.message, isLoading: false });
        }
    },

    clearAllNotifications: async (userId) => {
        set({ isLoading: true, error: null });
        const userNotifications = get().notifications.filter(n => n.userId === userId);
        try {
            for (const notification of userNotifications) {
                await databases.deleteDocument(
                    process.env.EXPO_PUBLIC_APPWRITE_DB_ID!,
                    process.env.EXPO_PUBLIC_APPWRITE_NOTIFICATIONS_COLLECTION_ID!,
                    notification.$id
                );
            }
            const remaining = get().notifications.filter(n => n.userId !== userId);
            const unreadCount = remaining.filter(n => !n.read_by.includes(userId)).length;
            set({ notifications: remaining, unreadCount, isLoading: false });
        } catch (error: any) {
            set({ error: error.message, isLoading: false });
        }
    },

    initializeNotifications: async (clerkId?: string, appwriteId?: string) => {
        if (get().realTimeInitialize) return;
        await get().fetchNotifications(clerkId, appwriteId);

        const userIds = [clerkId, appwriteId].filter(Boolean);

        try {
            client.subscribe(
                `databases.${process.env.EXPO_PUBLIC_APPWRITE_DB_ID!}.collections.${process.env.EXPO_PUBLIC_APPWRITE_NOTIFICATIONS_COLLECTION_ID!}.documents`,
                async (response: any) => {
                    const newNotification = response.payload as INotification;

                    // Handle create
                    if (response.events.includes('databases.*.collections.*.documents.*.create')) {
                        if (!userIds.includes(newNotification.userId)) return;
                        set(state => ({
                            notifications: [newNotification, ...state.notifications],
                            unreadCount: state.unreadCount + 1,
                        }));
                        await sendLocalNotification(newNotification.title, newNotification.message);
                    }

                    // Handle update
                    if (response.events.includes('databases.*.collections.*.documents.*.update')) {
                        set(state => {
                            const updated = state.notifications.map(n =>
                                n.$id === newNotification.$id ? newNotification : n
                            );
                            const unreadCount = updated.filter(n =>
                                !n.read_by.some(id => userIds.includes(id))
                            ).length;
                            return { notifications: updated, unreadCount };
                        });
                    }
                }
            );
            set({ realTimeInitialize: true });
        } catch (error) {
            console.error('Realtime subscription failed:', error);
        }
    },
}));



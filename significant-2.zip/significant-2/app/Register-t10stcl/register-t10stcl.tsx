// import React, { useState, useEffect } from 'react';
// import {
//     View,
//     Text,
//     TextInput,
//     ScrollView,
//     TouchableOpacity,
//     StyleSheet,
//     ImageBackground,
//     Alert,
// } from 'react-native';
// import { useRouter } from 'expo-router';
// import * as WebBrowser from 'expo-web-browser';
// import Icon from 'react-native-vector-icons/FontAwesome';
// import { FontAwesome } from '@expo/vector-icons';
// import DropDownPicker from 'react-native-dropdown-picker';
// import { useLocationStore } from '../../stores/locationStore';
// import { databases, DATABASE_ID, COLLECTION_ID } from '@/utils/appwrite-register-t10stcl';
// import { ID } from 'appwrite';
//
// const RegisterScreen = () => {
//     const [openRegion, setOpenRegion] = useState(false);
//     const [openCity, setOpenCity] = useState(false);
//
//     const [regionValue, setRegionValue] = useState(null);
//     const [cityValue, setCityValue] = useState(null);
//     const [cityOptions, setCityOptions] = useState([]);
//
//     const [registrationNumber, setRegistrationNumber] = useState('');
//     const [playerType, setPlayerType] = useState('');
//     const [agree, setAgree] = useState(false);
//
//     const [fullName, setFullName] = useState('');
//     const [dobDay, setDobDay] = useState('');
//     const [dobMonth, setDobMonth] = useState('');
//     const [dobYear, setDobYear] = useState('');
//
//     const [aadhaar, setAadhaar] = useState('');
//     const [email, setEmail] = useState('');
//     const [phone, setPhone] = useState('');
//     const [street, setStreet] = useState('');
//     const [cityAddress, setCityAddress] = useState('');
//     const [postalCode, setPostalCode] = useState('');
//     const [stateAddress, setStateAddress] = useState('');
//     const [countryAddress, setCountryAddress] = useState('');
//     const [referralCode, setReferralCode] = useState('');
//
//     const { country, region } = useLocationStore();
//     const router = useRouter();
//
//     useEffect(() => {
//         setStateAddress(region || '');
//         setCountryAddress(country || '');
//     }, [country, region]);
//
//     const regionOptions = [
//         { label: 'West', value: 'west' },
//         { label: 'North', value: 'north' },
//         { label: 'South', value: 'south' },
//         { label: 'North-East', value: 'north-east' },
//         { label: 'Central', value: 'central' },
//         { label: 'East', value: 'east' },
//     ];
//
//     const regionToCities = {
//         west: [
//             { label: 'Mumbai', value: 'Mumbai' },
//             { label: 'Nagpur', value: 'Nagpur' },
//             { label: 'Jaipur', value: 'Jaipur' },
//             { label: 'Jodhpur', value: 'Jodhpur' },
//             { label: 'Goa', value: 'Goa' },
//         ],
//         north: [
//             { label: 'Dharamshala', value: 'Dharamshala' },
//             { label: 'Srinagar', value: 'Srinagar' },
//             { label: 'Amritsar', value: 'Amritsar' },
//             { label: 'Chandigarh', value: 'Chandigarh' },
//             { label: 'Panipat', value: 'Panipat' },
//             { label: 'Haridwar', value: 'Haridwar' },
//             { label: 'Faridabad', value: 'Faridabad' },
//             { label: 'Delhi', value: 'Delhi' },
//         ],
//         south: [
//             { label: 'Vishakhapatnam', value: 'Vishakhapatnam' },
//             { label: 'Benguluru', value: 'Benguluru' },
//             { label: 'Kochi', value: 'Kochi' },
//             { label: 'Chennai', value: 'Chennai' },
//             { label: 'Telengana', value: 'Telengana' },
//         ],
//         'north-east': [
//             { label: 'Ita Nagar', value: 'Ita Nagar' },
//             { label: 'Guwahati', value: 'Guwahati' },
//             { label: 'Imphal', value: 'Imphal' },
//             { label: 'Gangtok', value: 'Gangtok' },
//         ],
//         east: [
//             { label: 'Patna', value: 'Patna' },
//             { label: 'Prayagraj', value: 'Prayagraj' },
//             { label: 'West Bengal', value: 'West Bengal' },
//         ],
//     };
//
//     useEffect(() => {
//         if (regionValue && regionValue !== 'central') {
//             setCityOptions(regionToCities[regionValue] || []);
//         } else {
//             setCityOptions([]);
//             setCityValue(null);
//         }
//     }, [regionValue]);
//
//     useEffect(() => {
//         const generateRegistrationNumber = () => {
//             const prefix = (country || '').toLowerCase() === 'india'
//                 ? 'T10IN'
//                 : (country || '').toLowerCase() === 'dubai'
//                     ? 'T10UAE'
//                     : 'T10AE';
//             const random = Math.floor(100000 + Math.random() * 900000);
//             return `${prefix}${random}`;
//         };
//         setRegistrationNumber(generateRegistrationNumber());
//     }, [country]);
//
//     const handlePay = async () => {
//         if (!agree) {
//             Alert.alert('Terms Required', 'You must agree to the terms and conditions to proceed.');
//             return;
//         }
//
//         if (!dobDay || !dobMonth || !dobYear || isNaN(+dobDay) || isNaN(+dobMonth) || isNaN(+dobYear)) {
//             Alert.alert('Invalid DOB', 'Please enter a valid Date of Birth.');
//             return;
//         }
//
//         const dob = `${dobYear}-${dobMonth.padStart(2, '0')}-${dobDay.padStart(2, '0')}`;
//
//         const formData = {
//             Register_num: registrationNumber,
//             Full_Name: fullName,
//             DOB: dob,
//             Adhaar_num: aadhaar,
//             Email: email,
//             Phone_num: phone,
//             Player_type: playerType,
//             Region: regionValue,
//             city: cityValue,
//             Reffer_code: referralCode,
//             street_adress: street,
//             city_address: cityAddress,
//             Postal_code: postalCode,
//             state: stateAddress,
//             country: countryAddress,
//         };
//
//         try {
//             await databases.createDocument(DATABASE_ID, COLLECTION_ID, ID.unique(), formData);
//
//             if ((country || '').toLowerCase() === 'india') {
//                 await WebBrowser.openBrowserAsync(`https://rzp.io/rzp/P4WoMslG`);
//             } else if ((country || '').toLowerCase() === 'dubai') {
//                 const response = await fetch(`https://www.paypal.com/ncp/payment/N9NAN5GEJLB7J`, {
//                     method: 'POST',
//                     headers: { 'Content-Type': 'application/json' },
//                 });
//                 const { approvalUrl } = await response.json();
//                 await WebBrowser.openBrowserAsync(approvalUrl);
//             } else {
//                 Alert.alert('Unsupported Region', 'Payment is only supported for India and Dubai.');
//             }
//         } catch (error) {
//             console.error('Error submitting form:', error);
//             Alert.alert('Error', 'Failed to submit registration. Please try again.');
//         }
//     };
//
//     return (
//         <ImageBackground source={require('../../assets/images/bg.webp')} style={styles.background}>
//             <ScrollView contentContainerStyle={styles.container} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
//                 <TouchableOpacity onPress={() => router.back()}>
//                     <FontAwesome name="arrow-left" size={20} color="#fff" />
//                 </TouchableOpacity>
//
//                 <Text style={styles.title}>Register</Text>
//
//                 {/* Registration Number */}
//                 <Text style={styles.label}>REGISTRATION NUMBER</Text>
//                 <TextInput
//                     style={[styles.input, { backgroundColor: 'rgba(255,255,255,0.1)' }]}
//                     value={registrationNumber}
//                     editable={false}
//                     selectTextOnFocus={false}
//                     placeholderTextColor="#888"
//                 />
//
//                 <Text style={styles.label}>FULL NAME</Text>
//                 <TextInput style={styles.input} placeholder="Full Name" placeholderTextColor="#888" value={fullName} onChangeText={setFullName} />
//
//                 <Text style={styles.label}>DATE-OF-BIRTH</Text>
//                 <View style={styles.row}>
//                     <TextInput style={[styles.input, styles.dobInput]} placeholder="Date" placeholderTextColor="#888" keyboardType="numeric" value={dobDay} onChangeText={setDobDay} maxLength={2} />
//                     <TextInput style={[styles.input, styles.dobInput]} placeholder="Month" placeholderTextColor="#888" keyboardType="numeric" value={dobMonth} onChangeText={setDobMonth} maxLength={2} />
//                     <TextInput style={[styles.input, styles.dobInput]} placeholder="Year" placeholderTextColor="#888" keyboardType="numeric" value={dobYear} onChangeText={setDobYear} maxLength={4} />
//                 </View>
//
//                 <Text style={styles.label}>ADDRESS</Text>
//                 <TextInput style={styles.input} placeholder="Street Address" placeholderTextColor="#888" value={street} onChangeText={setStreet} />
//                 <View style={styles.row}>
//                     <TextInput style={[styles.input, styles.halfInput]} placeholder="City" placeholderTextColor="#888" value={cityAddress} onChangeText={setCityAddress} />
//                     <TextInput style={[styles.input, styles.halfInput]} value={region || ''} editable={false} placeholder="State" placeholderTextColor="#888" />
//                 </View>
//                 <View style={styles.row}>
//                     <TextInput style={[styles.input, styles.halfInput]} placeholder="Postal Code" placeholderTextColor="#888" value={postalCode} onChangeText={setPostalCode} />
//                     <TextInput style={[styles.input, styles.halfInput]} value={country || ''} editable={false} placeholder="Country" placeholderTextColor="#888" />
//                 </View>
//
//                 <Text style={styles.label}>ADHAAR CARD NUMBER (No Spaces)</Text>
//                 <TextInput style={styles.input} placeholder="XXXXXXXXXXXX" placeholderTextColor="#888" value={aadhaar} onChangeText={setAadhaar} keyboardType="numeric" />
//
//                 <View style={styles.row}>
//                     <TextInput style={[styles.input, styles.halfInput]} placeholder="Email ID" placeholderTextColor="#888" value={email} onChangeText={setEmail} />
//                     <TextInput style={[styles.input, styles.halfInput]} placeholder="Phone No." placeholderTextColor="#888" keyboardType="phone-pad" value={phone} onChangeText={setPhone} />
//                 </View>
//
//                 <Text style={styles.label}>PLAYER TYPE</Text>
//                 <View style={styles.row}>
//                     {['BATSMEN', 'BOWLER', 'ALL-ROUNDER'].map((type) => (
//                         <TouchableOpacity key={type} style={[styles.radioButton, playerType === type && styles.radioSelected]} onPress={() => setPlayerType(type)}>
//                             <Text style={[styles.radioText, playerType === type && { color: '#000' }]}>{type}</Text>
//                         </TouchableOpacity>
//                     ))}
//                 </View>
//
//                 <Text style={styles.label}>SELECT REGION</Text>
//                 <View style={{ zIndex: 1000 }}>
//                     <DropDownPicker
//                         open={openRegion}
//                         setOpen={setOpenRegion}
//                         value={regionValue}
//                         setValue={setRegionValue}
//                         items={regionOptions}
//                         placeholder="Select Region"
//                         style={styles.dropdown}
//                         dropDownContainerStyle={styles.dropdownContainer}
//                         textStyle={styles.dropdownText}
//                         placeholderStyle={styles.dropdownPlaceholder}
//                     />
//                 </View>
//
//                 {regionValue !== 'central' && cityOptions.length > 0 && (
//                     <>
//                         <Text style={styles.label}>SELECT CITY</Text>
//                         <View style={{ zIndex: 999 }}>
//                             <DropDownPicker
//                                 open={openCity}
//                                 setOpen={setOpenCity}
//                                 value={cityValue}
//                                 setValue={setCityValue}
//                                 items={cityOptions}
//                                 placeholder="Select City"
//                                 style={styles.dropdown}
//                                 dropDownContainerStyle={styles.dropdownContainer}
//                                 textStyle={styles.dropdownText}
//                                 placeholderStyle={styles.dropdownPlaceholder}
//                             />
//                         </View>
//                     </>
//                 )}
//
//                 <Text style={styles.label}>REFERRAL CODE (Optional)</Text>
//                 <TextInput style={styles.input} placeholder="Code" placeholderTextColor="#888" value={referralCode} onChangeText={setReferralCode} />
//
//                 <Text style={styles.label}>COMPETITION TERMS AND SERVICES</Text>
//                 <View style={styles.noteBox}>
//                     <Text style={styles.noteTitle}>NOTE :-</Text>
//                     <Text style={styles.noteText}>1. The registration fee for participation in the T10-STCL trials conducted by Significant Sports and Entertainment Pvt. Ltd. is a non-refundable trial fee of ₹699, plus 18% GST.</Text>
//                     <Text style={styles.noteText}>2. Once the payment is completed, please check your registered email ID for a copy of the registration form.</Text>
//                     <Text style={styles.noteText}>3. Trial details will be shared one week before the trials to your registered email ID.</Text>
//                 </View>
//
//                 <TouchableOpacity style={styles.checkboxRow} onPress={() => setAgree(!agree)}>
//                     <View style={[styles.checkbox, agree && styles.checkboxChecked]}>
//                         {agree && <Text style={styles.checkboxTick}>✓</Text>}
//                     </View>
//                     <Text style={styles.checkboxText}>I agree to the competition terms and conditions</Text>
//                 </TouchableOpacity>
//
//                 <Text style={styles.label}>REGISTRATION FEES</Text>
//                 <View style={styles.feeRow}>
//                     <Text style={styles.originalFee}>₹ 1094.84</Text>
//                     <Text style={styles.discountedFee}>₹ 842.82</Text>
//                 </View>
//
//                 <TouchableOpacity style={styles.payButton} onPress={handlePay}>
//                     <Text style={styles.payText}>Pay</Text>
//                 </TouchableOpacity>
//             </ScrollView>
//         </ImageBackground>
//     );
// };
//
// const styles = StyleSheet.create({
//     background: { flex: 1 },
//     container: { padding: 15, paddingBottom: 40 , marginTop:30,},
//     backButton: {
//         width: 32,
//         height: 32,
//         marginTop: 20,
//         justifyContent: 'center',
//         alignItems: 'center',
//         marginBottom: 10,
//     },
//     backText: { color: '#fff', fontSize: 24 },
//     title: { fontSize: 22, fontWeight: '700', color: '#fff', alignSelf: 'center', marginBottom: 20 },
//     label: { color: '#aaa', fontSize: 13, marginTop: 30, marginBottom: 5 },
//     input: {
//         backgroundColor: 'rgba(255, 255, 255, 0.05)',
//         borderRadius: 8,
//         color: '#fff',
//         padding: 15,
//         marginTop: 15,
//         fontSize: 14,
//         borderWidth: 1,
//         borderColor: 'rgba(255, 255, 255, 0.1)',
//     },
//     halfInput: { flex: 1, marginRight: 10 },
//     dobInput: { flex: 1, marginRight: 10 },
//     row: { flexDirection: 'row', justifyContent: 'space-between' },
//     radioButton: {
//         flex: 1,
//         marginRight: 10,
//         borderRadius: 20,
//         paddingVertical: 10,
//         backgroundColor: 'transparent',
//         borderWidth: 1,
//         borderColor: '#aaa',
//         alignItems: 'center',
//     },
//     radioSelected: { backgroundColor: '#FFD700', borderColor: '#FFD700' },
//     radioText: { color: '#fff', fontSize: 12 },
//     noteBox: {
//         backgroundColor: 'rgba(255, 255, 255, 0.05)',
//         borderRadius: 10,
//         padding: 12,
//         marginTop: 5,
//         borderWidth: 1,
//         borderColor: '#333',
//     },
//     noteTitle: { color: '#fff', fontWeight: 'bold', marginBottom: 10 },
//     noteText: { color: '#aaa', fontSize: 12, marginBottom: 10 },
//     checkboxRow: { flexDirection: 'row', alignItems: 'center', marginTop: 15 },
//     checkbox: {
//         width: 18,
//         height: 18,
//         borderRadius: 4,
//         borderWidth: 1,
//         borderColor: '#999',
//         justifyContent: 'center',
//         alignItems: 'center',
//         marginRight: 10,
//     },
//     feeRow: {
//         flexDirection: 'row',
//         alignItems: 'center',
//         gap: 10,
//         marginTop: 4,
//     },
//     originalFee: {
//         color: '#aaa',
//         fontSize: 16,
//         textDecorationLine: 'line-through',
//         marginRight: 10,
//     },
//     discountedFee: {
//         color: '#fff',
//         fontSize: 20,
//         fontWeight: 'bold',
//     },
//     checkboxChecked: { backgroundColor: '#FFD700', borderColor: '#FFD700' },
//     checkboxTick: { fontSize: 12, color: '#000' },
//     checkboxText: { color: '#ccc', fontSize: 13, flex: 1 },
//     feeAmount: { color: '#fff', fontSize: 20, fontWeight: 'bold', marginTop: 4 },
//     payButton: {
//         backgroundColor: '#FFBF00',
//         borderRadius: 10,
//         paddingVertical: 14,
//         alignItems: 'center',
//         marginTop: 20,
//         shadowColor: '#000',
//         shadowOpacity: 0.4,
//         shadowOffset: { width: 0, height: 2 },
//         shadowRadius: 4,
//         elevation: 3,
//     },
//     payText: { color: '#000', fontWeight: '700', fontSize: 16 },
//         dropdown: {
//     backgroundColor: 'rgba(255, 255, 255, 0.05)',
//         borderColor: 'rgba(255, 255, 255, 0.1)',
//         borderWidth: 1,
//         borderRadius: 8,
//         marginTop: 15,
//         paddingHorizontal: 10,
// },
// dropdownContainer: {
//     backgroundColor: 'rgba(0,0,0,1)',
//         borderColor: 'rgba(255, 255, 255, 0.1)',
//         borderWidth: 1,
//         marginTop:16,
//         borderRadius: 8,
// },
// dropdownText: {
//     color: '#fff',
//         fontSize: 14,
// },
// dropdownPlaceholder: {
//     color: '#999',
// },
// });

// export default RegisterScreen;


// import React, { useState, useEffect, useMemo } from 'react';
// import {
//     View,
//     Text,
//     TextInput,
//     ScrollView,
//     TouchableOpacity,
//     StyleSheet,
//     ImageBackground,
//     Alert,
// } from 'react-native';
// import { useRouter } from 'expo-router';
// import * as WebBrowser from 'expo-web-browser';
// import { FontAwesome } from '@expo/vector-icons';
// import DropDownPicker from 'react-native-dropdown-picker';
// import { useLocationStore } from '../../stores/locationStore';
// import { databases, DATABASE_ID, COLLECTION_ID } from '@/utils/appwrite-register-t10stcl';
// import { ID } from 'appwrite';
//
// const RegisterScreen = () => {
//     const [openRegion, setOpenRegion] = useState(false);
//     const [openCity, setOpenCity] = useState(false);
//
//     const [regionValue, setRegionValue] = useState(null);
//     const [cityValue, setCityValue] = useState(null);
//     const [cityOptions, setCityOptions] = useState([]);
//
//     const [registrationNumber, setRegistrationNumber] = useState('');
//     const [playerType, setPlayerType] = useState('');
//     const [agree, setAgree] = useState(false);
//
//     const [fullName, setFullName] = useState('');
//     const [dobDay, setDobDay] = useState('');
//     const [dobMonth, setDobMonth] = useState('');
//     const [dobYear, setDobYear] = useState('');
//
//     const [aadhaar, setAadhaar] = useState('');
//     const [email, setEmail] = useState('');
//     const [phone, setPhone] = useState('');
//     const [street, setStreet] = useState('');
//     const [cityAddress, setCityAddress] = useState('');
//     const [postalCode, setPostalCode] = useState('');
//     const [stateAddress, setStateAddress] = useState('');
//     const [countryAddress, setCountryAddress] = useState('');
//     const [referralCode, setReferralCode] = useState('');
//
//     const { country, region } = useLocationStore();
//     const router = useRouter();
//
//     useEffect(() => {
//         setStateAddress(region || '');
//         setCountryAddress(country || '');
//     }, [country, region]);
//
//     const isUAE = useMemo(() => {
//         const c = (country || '').toLowerCase();
//         return c === 'uae' || c === 'united arab emirates';
//     }, [country]);
//
//     const regionOptions = useMemo(() => {
//         if (isUAE) {
//             return [
//                 { label: 'Abu Dhabi', value: 'Abu Dhabi' },
//                 { label: 'Ajman', value: 'Ajman' },
//                 { label: 'Al Ain', value: 'Al Ain' },
//                 { label: 'Dubai', value: 'Dubai' },
//                 { label: 'Fujairah', value: 'Fujairah' },
//                 { label: 'Kalba', value: 'Kalba' },
//                 { label: 'Madinat Zayed', value: 'Madinat Zayed' },
//                 { label: 'Ras Al Khaiman', value: 'Ras Al Khaiman' },
//                 { label: 'Sharjah', value: 'Sharjah' },
//                 { label: 'Umm Al Quwain', value: 'Umm Al Quwain' },
//             ];
//         }
//
//         return [
//             { label: 'West', value: 'west' },
//             { label: 'North', value: 'north' },
//             { label: 'South', value: 'south' },
//             { label: 'North-East', value: 'north-east' },
//             { label: 'Central', value: 'central' },
//             { label: 'East', value: 'east' },
//         ];
//     }, [isUAE]);
//
//     const regionToCities = {
//         west: [
//             { label: 'Mumbai', value: 'Mumbai' },
//             { label: 'Nagpur', value: 'Nagpur' },
//             { label: 'Jaipur', value: 'Jaipur' },
//             { label: 'Jodhpur', value: 'Jodhpur' },
//             { label: 'Goa', value: 'Goa' },
//         ],
//         north: [
//             { label: 'Dharamshala', value: 'Dharamshala' },
//             { label: 'Srinagar', value: 'Srinagar' },
//             { label: 'Amritsar', value: 'Amritsar' },
//             { label: 'Chandigarh', value: 'Chandigarh' },
//             { label: 'Panipat', value: 'Panipat' },
//             { label: 'Haridwar', value: 'Haridwar' },
//             { label: 'Faridabad', value: 'Faridabad' },
//             { label: 'Delhi', value: 'Delhi' },
//         ],
//         south: [
//             { label: 'Vishakhapatnam', value: 'Vishakhapatnam' },
//             { label: 'Benguluru', value: 'Benguluru' },
//             { label: 'Kochi', value: 'Kochi' },
//             { label: 'Chennai', value: 'Chennai' },
//             { label: 'Telengana', value: 'Telengana' },
//         ],
//         'north-east': [
//             { label: 'Ita Nagar', value: 'Ita Nagar' },
//             { label: 'Guwahati', value: 'Guwahati' },
//             { label: 'Imphal', value: 'Imphal' },
//             { label: 'Gangtok', value: 'Gangtok' },
//         ],
//         east: [
//             { label: 'Patna', value: 'Patna' },
//             { label: 'Prayagraj', value: 'Prayagraj' },
//             { label: 'West Bengal', value: 'West Bengal' },
//         ],
//     };
//
//     useEffect(() => {
//         if (!isUAE && regionValue && regionValue !== 'central') {
//             setCityOptions(regionToCities[regionValue] || []);
//         } else {
//             setCityOptions([]);
//             setCityValue(null);
//         }
//     }, [regionValue, isUAE]);
//
//     useEffect(() => {
//         const generateRegistrationNumber = () => {
//             const prefix = (country || '').toLowerCase() === 'india'
//                 ? 'T10IN'
//                 : (country || '').toLowerCase() === 'uae' || (country || '').toLowerCase() === 'united arab emirates'
//                     ? 'T10UAE'
//                     : 'T10AE';
//             const random = Math.floor(100000 + Math.random() * 900000);
//             return `${prefix}${random}`;
//         };
//         setRegistrationNumber(generateRegistrationNumber());
//     }, [country]);
//
//     const handlePay = async () => {
//         if (!agree) {
//             Alert.alert('Terms Required', 'You must agree to the terms and conditions to proceed.');
//             return;
//         }
//
//         if (!dobDay || !dobMonth || !dobYear || isNaN(+dobDay) || isNaN(+dobMonth) || isNaN(+dobYear)) {
//             Alert.alert('Invalid DOB', 'Please enter a valid Date of Birth.');
//             return;
//         }
//
//         const dob = `${dobYear}-${dobMonth.padStart(2, '0')}-${dobDay.padStart(2, '0')}`;
//
//         const formData = {
//             Register_num: registrationNumber,
//             Full_Name: fullName,
//             DOB: dob,
//             Adhaar_num: aadhaar,
//             Email: email,
//             Phone_num: phone,
//             Player_type: playerType,
//             Region: regionValue,
//             city: cityValue,
//             Reffer_code: referralCode,
//             street_adress: street,
//             city_address: cityAddress,
//             Postal_code: postalCode,
//             state: stateAddress,
//             country: countryAddress,
//         };
//
//         try {
//             await databases.createDocument(DATABASE_ID, COLLECTION_ID, ID.unique(), formData);
//
//             if ((country || '').toLowerCase() === 'india') {
//                 await WebBrowser.openBrowserAsync(`https://rzp.io/rzp/P4WoMslG`);
//             } else if ((country || '').toLowerCase() === 'uae' || (country || '').toLowerCase() === 'united arab emirates') {
//                 const response = await fetch(`https://www.paypal.com/ncp/payment/N9NAN5GEJLB7J`, {
//                     method: 'POST',
//                     headers: { 'Content-Type': 'application/json' },
//                 });
//                 const { approvalUrl } = await response.json();
//                 await WebBrowser.openBrowserAsync(approvalUrl);
//             } else {
//                 Alert.alert('Unsupported Region', 'Payment is only supported for India and UAE.');
//             }
//         } catch (error) {
//             console.error('Error submitting form:', error);
//             Alert.alert('Error', 'Failed to submit registration. Please try again.');
//         }
//     };
//
//     return (
//         <ImageBackground source={require('../../assets/images/bg.webp')} style={styles.background}>
//             <ScrollView contentContainerStyle={styles.container} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
//                 <TouchableOpacity onPress={() => router.back()}>
//                     <FontAwesome name="arrow-left" size={20} color="#fff" />
//                 </TouchableOpacity>
//
//                 <Text style={styles.title}>Register</Text>
//
//                 <Text style={styles.label}>REGISTRATION NUMBER</Text>
//                 <TextInput style={[styles.input, { backgroundColor: 'rgba(255,255,255,0.1)' }]} value={registrationNumber} editable={false} placeholderTextColor="#888" />
//
//                 <Text style={styles.label}>FULL NAME</Text>
//                 <TextInput style={styles.input} placeholder="Full Name" placeholderTextColor="#888" value={fullName} onChangeText={setFullName} />
//
//                 <Text style={styles.label}>DATE-OF-BIRTH</Text>
//                 <View style={styles.row}>
//                     <TextInput style={[styles.input, styles.dobInput]} placeholder="Date" keyboardType="numeric" value={dobDay} onChangeText={setDobDay} maxLength={2}  placeholderTextColor="#888"/>
//                     <TextInput style={[styles.input, styles.dobInput]} placeholder="Month" keyboardType="numeric" value={dobMonth} onChangeText={setDobMonth} maxLength={2}  placeholderTextColor="#888"/>
//                     <TextInput style={[styles.input, styles.dobInput]} placeholder="Year" keyboardType="numeric" value={dobYear} onChangeText={setDobYear} maxLength={4}  placeholderTextColor="#888"/>
//                 </View>
//
//                 <Text style={styles.label}>ADDRESS</Text>
//                 <TextInput style={styles.input} placeholder="Street Address" placeholderTextColor="#888" value={street} onChangeText={setStreet} />
//                 <View style={styles.row}>
//                     <TextInput style={[styles.input, styles.halfInput]} placeholder="City" value={cityAddress} onChangeText={setCityAddress}  placeholderTextColor="#888"/>
//                     <TextInput style={[styles.input, styles.halfInput]} value={region || ''} editable={false} placeholder="State" />
//                 </View>
//                 <View style={styles.row}>
//                     <TextInput style={[styles.input, styles.halfInput]} placeholder="Postal Code" value={postalCode} onChangeText={setPostalCode}  placeholderTextColor="#888"/>
//                     <TextInput style={[styles.input, styles.halfInput]} value={country || ''} editable={false} placeholder="Country" />
//                 </View>
//
//                 <Text style={styles.label}>{isUAE ? 'EMIRATES ID' : 'ADHAAR CARD NUMBER (No Spaces)'}</Text>
//                 <TextInput style={styles.input} placeholder={isUAE ? 'Emirates ID' : 'Adhaar Card'} value={aadhaar} onChangeText={setAadhaar} keyboardType="numeric"  placeholderTextColor="#888"/>
//
//                 <View style={styles.row}>
//                     <TextInput style={[styles.input, styles.halfInput]} placeholder="Email ID" value={email} onChangeText={setEmail}  placeholderTextColor="#888"/>
//                     <TextInput style={[styles.input, styles.halfInput]} placeholder="Phone No." keyboardType="phone-pad" value={phone} onChangeText={setPhone}  placeholderTextColor="#888"/>
//                 </View>
//
//                 <Text style={styles.label}>PLAYER TYPE</Text>
//                 <View style={styles.row}>
//                     {['BATSMEN', 'BOWLER', 'ALL-ROUNDER'].map((type) => (
//                         <TouchableOpacity key={type} style={[styles.radioButton, playerType === type && styles.radioSelected]} onPress={() => setPlayerType(type)}>
//                             <Text style={[styles.radioText, playerType === type && { color: '#000' }]}>{type}</Text>
//                         </TouchableOpacity>
//                     ))}
//                 </View>
//
//                 <Text style={styles.label}>SELECT REGION</Text>
//                 <View style={{ zIndex: 1000 }}>
//                     <DropDownPicker
//                         open={openRegion}
//                         setOpen={setOpenRegion}
//                         value={regionValue}
//                         setValue={setRegionValue}
//                         items={regionOptions}
//                         placeholder="Select Region"
//                         style={styles.dropdown}
//                         dropDownContainerStyle={styles.dropdownContainer}
//                         textStyle={styles.dropdownText}
//                         placeholderStyle={styles.dropdownPlaceholder}
//                     />
//                 </View>
//
//                 {!isUAE && regionValue !== 'central' && cityOptions.length > 0 && (
//                     <>
//                         <Text style={styles.label}>SELECT CITY</Text>
//                         <View style={{ zIndex: 999 }}>
//                             <DropDownPicker
//                                 open={openCity}
//                                 setOpen={setOpenCity}
//                                 value={cityValue}
//                                 setValue={setCityValue}
//                                 items={cityOptions}
//                                 placeholder="Select City"
//                                 style={styles.dropdown}
//                                 dropDownContainerStyle={styles.dropdownContainer}
//                                 textStyle={styles.dropdownText}
//                                 placeholderStyle={styles.dropdownPlaceholder}
//                             />
//                         </View>
//                     </>
//                 )}
//
//                 <Text style={styles.label}>REFERRAL CODE (Optional)</Text>
//                 <TextInput style={styles.input} placeholder="Code" value={referralCode} onChangeText={setReferralCode} />
//                 <Text style={styles.label}>COMPETITION TERMS AND SERVICES</Text>
//                 <View style={styles.noteBox}>
//                     <Text style={styles.noteTitle}>NOTE :-</Text>
//                     <Text style={styles.noteText}>1. The registration fee for participation in the T10-STCL trials conducted by Significant Sports and Entertainment Pvt. Ltd. is a non-refundable trial fee of ₹699, plus 18% GST.</Text>
//                     <Text style={styles.noteText}>2. Once the payment is completed, please check your registered email ID for a copy of the registration form.</Text>
//                     <Text style={styles.noteText}>3. Trial details will be shared one week before the trials to your registered email ID.</Text>
//                 </View>
//
//                 <TouchableOpacity style={styles.checkboxRow} onPress={() => setAgree(!agree)}>
//                     <View style={[styles.checkbox, agree && styles.checkboxChecked]}>
//                         {agree && <Text style={styles.checkboxTick}>✓</Text>}
//                     </View>
//                     <Text style={styles.checkboxText}>I agree to the competition terms and conditions</Text>
//                 </TouchableOpacity>
//
//                 <Text style={styles.label}>REGISTRATION FEES</Text>
//                 <View style={styles.feeRow}>
//                     <Text style={styles.originalFee}>₹ 1094.84</Text>
//                     <Text style={styles.discountedFee}>₹ 842.82</Text>
//                 </View>
//
//                 <TouchableOpacity style={styles.payButton} onPress={handlePay}>
//                     <Text style={styles.payText}>Pay</Text>
//                 </TouchableOpacity>
//             </ScrollView>
//         </ImageBackground>
//     );
// };
//
//
// const styles = StyleSheet.create({
//     background: { flex: 1 },
//     container: { padding: 15, paddingBottom: 40 , marginTop:30,},
//     backButton: {
//         width: 32,
//         height: 32,
//         marginTop: 20,
//         justifyContent: 'center',
//         alignItems: 'center',
//         marginBottom: 10,
//     },
//     backText: { color: '#fff', fontSize: 24 },
//     title: { fontSize: 22, fontWeight: '700', color: '#fff', alignSelf: 'center', marginBottom: 20 },
//     label: { color: '#aaa', fontSize: 13, marginTop: 30, marginBottom: 5 },
//     input: {
//         backgroundColor: 'rgba(255, 255, 255, 0.05)',
//         borderRadius: 8,
//         color: '#fff',
//         padding: 15,
//         marginTop: 15,
//         fontSize: 14,
//         borderWidth: 1,
//         borderColor: 'rgba(255, 255, 255, 0.1)',
//     },
//     halfInput: { flex: 1, marginRight: 10 },
//     dobInput: { flex: 1, marginRight: 10 },
//     row: { flexDirection: 'row', justifyContent: 'space-between' },
//     radioButton: {
//         flex: 1,
//         marginRight: 10,
//         borderRadius: 20,
//         paddingVertical: 10,
//         backgroundColor: 'transparent',
//         borderWidth: 1,
//         borderColor: '#aaa',
//         alignItems: 'center',
//     },
//     radioSelected: { backgroundColor: '#FFD700', borderColor: '#FFD700' },
//     radioText: { color: '#fff', fontSize: 12 },
//     noteBox: {
//         backgroundColor: 'rgba(255, 255, 255, 0.05)',
//         borderRadius: 10,
//         padding: 12,
//         marginTop: 5,
//         borderWidth: 1,
//         borderColor: '#333',
//     },
//     noteTitle: { color: '#fff', fontWeight: 'bold', marginBottom: 10 },
//     noteText: { color: '#aaa', fontSize: 12, marginBottom: 10 },
//     checkboxRow: { flexDirection: 'row', alignItems: 'center', marginTop: 15 },
//     checkbox: {
//         width: 18,
//         height: 18,
//         borderRadius: 4,
//         borderWidth: 1,
//         borderColor: '#999',
//         justifyContent: 'center',
//         alignItems: 'center',
//         marginRight: 10,
//     },
//     feeRow: {
//         flexDirection: 'row',
//         alignItems: 'center',
//         gap: 10,
//         marginTop: 4,
//     },
//     originalFee: {
//         color: '#aaa',
//         fontSize: 16,
//         textDecorationLine: 'line-through',
//         marginRight: 10,
//     },
//     discountedFee: {
//         color: '#fff',
//         fontSize: 20,
//         fontWeight: 'bold',
//     },
//     checkboxChecked: { backgroundColor: '#FFD700', borderColor: '#FFD700' },
//     checkboxTick: { fontSize: 12, color: '#000' },
//     checkboxText: { color: '#ccc', fontSize: 13, flex: 1 },
//     feeAmount: { color: '#fff', fontSize: 20, fontWeight: 'bold', marginTop: 4 },
//     payButton: {
//         backgroundColor: '#FFBF00',
//         borderRadius: 10,
//         paddingVertical: 14,
//         alignItems: 'center',
//         marginTop: 20,
//         shadowColor: '#000',
//         shadowOpacity: 0.4,
//         shadowOffset: { width: 0, height: 2 },
//         shadowRadius: 4,
//         elevation: 3,
//     },
//     payText: { color: '#000', fontWeight: '700', fontSize: 16 },
//     dropdown: {
//         backgroundColor: 'rgba(255, 255, 255, 0.05)',
//         borderColor: 'rgba(255, 255, 255, 0.1)',
//         borderWidth: 1,
//         borderRadius: 8,
//         marginTop: 15,
//         paddingHorizontal: 10,
//     },
//     dropdownContainer: {
//         backgroundColor: 'rgba(0,0,0,1)',
//         borderColor: 'rgba(255, 255, 255, 0.1)',
//         borderWidth: 1,
//         marginTop:16,
//         borderRadius: 8,
//     },
//     dropdownText: {
//         color: '#fff',
//         fontSize: 14,
//     },
//     dropdownPlaceholder: {
//         color: '#999',
//     },
// });
//
// export default RegisterScreen;


// import React, { useState, useEffect, useMemo } from 'react';
// import {
//     View,
//     Text,
//     TextInput,
//     ScrollView,
//     TouchableOpacity,
//     StyleSheet,
//     ImageBackground,
//     Alert,
//     Platform,
// } from 'react-native';
// import { useRouter } from 'expo-router';
// import * as WebBrowser from 'expo-web-browser';
// import { FontAwesome } from '@expo/vector-icons';
// import DropDownPicker from 'react-native-dropdown-picker';
// import DateTimePicker from '@react-native-community/datetimepicker';
// import { useLocationStore } from '../../stores/locationStore';
// import { databases, DATABASE_ID, COLLECTION_ID } from '@/utils/appwrite-register-t10stcl';
// import { ID } from 'appwrite';
//
// const RegisterScreen = () => {
//     const [openRegion, setOpenRegion] = useState(false);
//     const [openCity, setOpenCity] = useState(false);
//
//     const [regionValue, setRegionValue] = useState(null);
//     const [cityValue, setCityValue] = useState(null);
//     const [cityOptions, setCityOptions] = useState([]);
//
//     const [registrationNumber, setRegistrationNumber] = useState('');
//     const [playerType, setPlayerType] = useState('');
//     const [agree, setAgree] = useState(false);
//
//     const [fullName, setFullName] = useState('');
//     const [dobDay, setDobDay] = useState('');
//     const [dobMonth, setDobMonth] = useState('');
//     const [dobYear, setDobYear] = useState('');
//
//     const [aadhaar, setAadhaar] = useState('');
//     const [email, setEmail] = useState('');
//     const [phone, setPhone] = useState('');
//     const [street, setStreet] = useState('');
//     const [cityAddress, setCityAddress] = useState('');
//     const [postalCode, setPostalCode] = useState('');
//     const [stateAddress, setStateAddress] = useState('');
//     const [countryAddress, setCountryAddress] = useState('');
//     const [referralCode, setReferralCode] = useState('');
//
//     const { country, region } = useLocationStore();
//     const router = useRouter();
//
//     const [showDatePicker, setShowDatePicker] = useState(false);
//     const [selectedDate, setSelectedDate] = useState<Date | null>(null);
//
//     useEffect(() => {
//         setStateAddress(region || '');
//         setCountryAddress(country || '');
//     }, [country, region]);
//
//     const isUAE = useMemo(() => {
//         const c = (country || '').toLowerCase();
//         return c === 'uae' || c === 'united arab emirates';
//     }, [country]);
//
//     const regionOptions = useMemo(() => {
//         if (isUAE) {
//             return [
//                 { label: 'Abu Dhabi', value: 'Abu Dhabi' },
//                 { label: 'Ajman', value: 'Ajman' },
//                 { label: 'Al Ain', value: 'Al Ain' },
//                 { label: 'Dubai', value: 'Dubai' },
//                 { label: 'Fujairah', value: 'Fujairah' },
//                 { label: 'Kalba', value: 'Kalba' },
//                 { label: 'Madinat Zayed', value: 'Madinat Zayed' },
//                 { label: 'Ras Al Khaiman', value: 'Ras Al Khaiman' },
//                 { label: 'Sharjah', value: 'Sharjah' },
//                 { label: 'Umm Al Quwain', value: 'Umm Al Quwain' },
//             ];
//         }
//
//         return [
//             { label: 'West', value: 'west' },
//             { label: 'North', value: 'north' },
//             { label: 'South', value: 'south' },
//             { label: 'North-East', value: 'north-east' },
//             { label: 'Central', value: 'central' },
//             { label: 'East', value: 'east' },
//         ];
//     }, [isUAE]);
//
//     const regionToCities = {
//         west: [
//             { label: 'Mumbai', value: 'Mumbai' },
//             { label: 'Nagpur', value: 'Nagpur' },
//             { label: 'Jaipur', value: 'Jaipur' },
//             { label: 'Jodhpur', value: 'Jodhpur' },
//             { label: 'Goa', value: 'Goa' },
//         ],
//         north: [
//             { label: 'Dharamshala', value: 'Dharamshala' },
//             { label: 'Srinagar', value: 'Srinagar' },
//             { label: 'Amritsar', value: 'Amritsar' },
//             { label: 'Chandigarh', value: 'Chandigarh' },
//             { label: 'Panipat', value: 'Panipat' },
//             { label: 'Haridwar', value: 'Haridwar' },
//             { label: 'Faridabad', value: 'Faridabad' },
//             { label: 'Delhi', value: 'Delhi' },
//         ],
//         south: [
//             { label: 'Vishakhapatnam', value: 'Vishakhapatnam' },
//             { label: 'Benguluru', value: 'Benguluru' },
//             { label: 'Kochi', value: 'Kochi' },
//             { label: 'Chennai', value: 'Chennai' },
//             { label: 'Telengana', value: 'Telengana' },
//         ],
//         'north-east': [
//             { label: 'Ita Nagar', value: 'Ita Nagar' },
//             { label: 'Guwahati', value: 'Guwahati' },
//             { label: 'Imphal', value: 'Imphal' },
//             { label: 'Gangtok', value: 'Gangtok' },
//         ],
//         east: [
//             { label: 'Patna', value: 'Patna' },
//             { label: 'Prayagraj', value: 'Prayagraj' },
//             { label: 'West Bengal', value: 'West Bengal' },
//         ],
//     };
//
//     useEffect(() => {
//         if (!isUAE && regionValue && regionValue !== 'central') {
//             setCityOptions(regionToCities[regionValue] || []);
//         } else {
//             setCityOptions([]);
//             setCityValue(null);
//         }
//     }, [regionValue, isUAE]);
//
//     useEffect(() => {
//         const generateRegistrationNumber = () => {
//             const prefix = (country || '').toLowerCase() === 'india'
//                 ? 'T10IN'
//                 : (country || '').toLowerCase() === 'uae' || (country || '').toLowerCase() === 'united arab emirates'
//                     ? 'T10UAE'
//                     : 'T10AE';
//             const random = Math.floor(100000 + Math.random() * 900000);
//             return `${prefix}${random}`;
//         };
//         setRegistrationNumber(generateRegistrationNumber());
//     }, [country]);
//
//     const handlePay = async () => {
//         if (!agree) {
//             Alert.alert('Terms Required', 'You must agree to the terms and conditions to proceed.');
//             return;
//         }
//
//         if (!dobDay || !dobMonth || !dobYear || isNaN(+dobDay) || isNaN(+dobMonth) || isNaN(+dobYear)) {
//             Alert.alert('Invalid DOB', 'Please enter a valid Date of Birth.');
//             return;
//         }
//
//         const dob = `${dobYear}-${dobMonth.padStart(2, '0')}-${dobDay.padStart(2, '0')}`;
//
//         const formData = {
//             Register_num: registrationNumber,
//             Full_Name: fullName,
//             DOB: dob,
//             Adhaar_num: aadhaar,
//             Email: email,
//             Phone_num: phone,
//             Player_type: playerType,
//             Region: regionValue,
//             city: cityValue,
//             Reffer_code: referralCode,
//             street_adress: street,
//             city_address: cityAddress,
//             Postal_code: postalCode,
//             state: stateAddress,
//             country: countryAddress,
//         };
//
//         try {
//             await databases.createDocument(DATABASE_ID, COLLECTION_ID, ID.unique(), formData);
//
//             if ((country || '').toLowerCase() === 'india') {
//                 await WebBrowser.openBrowserAsync(`https://rzp.io/rzp/P4WoMslG`);
//             } else if ((country || '').toLowerCase() === 'uae' || (country || '').toLowerCase() === 'united arab emirates') {
//                 const response = await fetch(`https://www.paypal.com/ncp/payment/N9NAN5GEJLB7J`, {
//                     method: 'POST',
//                     headers: { 'Content-Type': 'application/json' },
//                 });
//                 const { approvalUrl } = await response.json();
//                 await WebBrowser.openBrowserAsync(approvalUrl);
//             } else {
//                 Alert.alert('Unsupported Region', 'Payment is only supported for India and UAE.');
//             }
//         } catch (error) {
//             console.error('Error submitting form:', error);
//             Alert.alert('Error', 'Failed to submit registration. Please try again.');
//         }
//     };
//
//     return (
//         <ImageBackground source={require('../../assets/images/bg.webp')} style={styles.background}>
//             <ScrollView contentContainerStyle={styles.container} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
//                 <TouchableOpacity onPress={() => router.back()}>
//                     <FontAwesome name="arrow-left" size={20} color="#fff" />
//                 </TouchableOpacity>
//
//                 <Text style={styles.title}>Register</Text>
//
//                 <Text style={styles.label}>REGISTRATION NUMBER</Text>
//                 <TextInput style={[styles.input, { backgroundColor: 'rgba(255,255,255,0.1)' }]} value={registrationNumber} editable={false} placeholderTextColor="#888" />
//
//                 <Text style={styles.label}>FULL NAME</Text>
//                 <TextInput style={styles.input} placeholder="Full Name" placeholderTextColor="#888" value={fullName} onChangeText={setFullName} />
//
//
//                 <Text style={styles.label}>DATE-OF-BIRTH</Text>
//                 <TouchableOpacity onPress={() => setShowDatePicker(true)}>
//                     <View style={[styles.input, { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }]}>
//                         <Text style={{ color: dobDay ? '#fff' : '#888' }}>
//                             {dobDay && dobMonth && dobYear
//                                 ? `${dobDay.padStart(2, '0')}-${dobMonth.padStart(2, '0')}-${dobYear}`
//                                 : 'Select Date of Birth'}
//                         </Text>
//                         <FontAwesome name="calendar" size={18} color="#fff" />
//                     </View>
//                 </TouchableOpacity>
//
//                 {showDatePicker && (
//                     <DateTimePicker
//                         testID="dateTimePicker"
//                         value={selectedDate || new Date(2005, 0, 1)}
//                         mode="date"
//                         display={Platform.OS === 'ios' ? 'spinner' : 'default'}
//                         maximumDate={new Date()}
//                         onChange={(event, date) => {
//                             setShowDatePicker(false);
//                             if (date) {
//                                 const day = `${date.getDate()}`;
//                                 const month = `${date.getMonth() + 1}`;
//                                 const year = `${date.getFullYear()}`;
//
//                                 setSelectedDate(date);
//                                 setDobDay(day);
//                                 setDobMonth(month);
//                                 setDobYear(year);
//                             }
//                         }}
//                     />
//                 )}
//
//                 <Text style={styles.label}>ADDRESS</Text>
//                 <TextInput style={styles.input} placeholder="Street Address" placeholderTextColor="#888" value={street} onChangeText={setStreet} />
//                 <View style={styles.row}>
//                     <TextInput style={[styles.input, styles.halfInput]} placeholder="City" value={cityAddress} onChangeText={setCityAddress}  placeholderTextColor="#888"/>
//                     <TextInput style={[styles.input, styles.halfInput]} value={region || ''} editable={false} placeholder="State" />
//                 </View>
//                 <View style={styles.row}>
//                     <TextInput style={[styles.input, styles.halfInput]} placeholder="Postal Code" value={postalCode} onChangeText={setPostalCode}  placeholderTextColor="#888"/>
//                     <TextInput style={[styles.input, styles.halfInput]} value={country || ''} editable={false} placeholder="Country" />
//                 </View>
//
//                 <Text style={styles.label}>{isUAE ? 'EMIRATES ID' : 'ADHAAR CARD NUMBER (No Spaces)'}</Text>
//                 <TextInput style={styles.input} placeholder={isUAE ? 'Emirates ID' : 'Adhaar Card'} value={aadhaar} onChangeText={setAadhaar} keyboardType="numeric"  placeholderTextColor="#888"/>
//
//                 <View style={styles.row}>
//                     <TextInput style={[styles.input, styles.halfInput]} placeholder="Email ID" value={email} onChangeText={setEmail}  placeholderTextColor="#888"/>
//                     <TextInput style={[styles.input, styles.halfInput]} placeholder="Phone No." keyboardType="phone-pad" value={phone} onChangeText={setPhone}  placeholderTextColor="#888"/>
//                 </View>
//
//                 <Text style={styles.label}>PLAYER TYPE</Text>
//                 <View style={styles.row}>
//                     {['BATSMEN', 'BOWLER', 'ALL-ROUNDER'].map((type) => (
//                         <TouchableOpacity key={type} style={[styles.radioButton, playerType === type && styles.radioSelected]} onPress={() => setPlayerType(type)}>
//                             <Text style={[styles.radioText, playerType === type && { color: '#000' }]}>{type}</Text>
//                         </TouchableOpacity>
//                     ))}
//                 </View>
//
//                 <Text style={styles.label}>SELECT REGION</Text>
//                 <View style={{ zIndex: 1000 }}>
//                     <DropDownPicker
//                         open={openRegion}
//                         setOpen={setOpenRegion}
//                         value={regionValue}
//                         setValue={setRegionValue}
//                         items={regionOptions}
//                         placeholder="Select Region"
//                         style={styles.dropdown}
//                         dropDownContainerStyle={styles.dropdownContainer}
//                         textStyle={styles.dropdownText}
//                         placeholderStyle={styles.dropdownPlaceholder}
//                     />
//                 </View>
//
//                 {!isUAE && regionValue !== 'central' && cityOptions.length > 0 && (
//                     <>
//                         <Text style={styles.label}>SELECT CITY</Text>
//                         <View style={{ zIndex: 999 }}>
//                             <DropDownPicker
//                                 open={openCity}
//                                 setOpen={setOpenCity}
//                                 value={cityValue}
//                                 setValue={setCityValue}
//                                 items={cityOptions}
//                                 placeholder="Select City"
//                                 style={styles.dropdown}
//                                 dropDownContainerStyle={styles.dropdownContainer}
//                                 textStyle={styles.dropdownText}
//                                 placeholderStyle={styles.dropdownPlaceholder}
//                             />
//                         </View>
//                     </>
//                 )}
//
//                 <Text style={styles.label}>REFERRAL CODE (Optional)</Text>
//                 <TextInput style={styles.input} placeholder="Code" value={referralCode} onChangeText={setReferralCode} />
//                 <Text style={styles.label}>COMPETITION TERMS AND SERVICES</Text>
//                 <View style={styles.noteBox}>
//                     <Text style={styles.noteTitle}>NOTE :-</Text>
//                     <Text style={styles.noteText}>1. The registration fee for participation in the T10-STCL trials conducted by Significant Sports and Entertainment Pvt. Ltd. is a non-refundable trial fee of ₹699, plus 18% GST.</Text>
//                     <Text style={styles.noteText}>2. Once the payment is completed, please check your registered email ID for a copy of the registration form.</Text>
//                     <Text style={styles.noteText}>3. Trial details will be shared one week before the trials to your registered email ID.</Text>
//                 </View>
//
//                 <TouchableOpacity style={styles.checkboxRow} onPress={() => setAgree(!agree)}>
//                     <View style={[styles.checkbox, agree && styles.checkboxChecked]}>
//                         {agree && <Text style={styles.checkboxTick}>✓</Text>}
//                     </View>
//                     <Text style={styles.checkboxText}>I agree to the competition terms and conditions</Text>
//                 </TouchableOpacity>
//
//                 <Text style={styles.label}>REGISTRATION FEES</Text>
//                 <View style={styles.feeRow}>
//                     <Text style={styles.originalFee}>₹ 1094.84</Text>
//                     <Text style={styles.discountedFee}>₹ 842.82</Text>
//                 </View>
//
//                 <TouchableOpacity style={styles.payButton} onPress={handlePay}>
//                     <Text style={styles.payText}>Pay</Text>
//                 </TouchableOpacity>
//             </ScrollView>
//         </ImageBackground>
//     );
// };
//
// const styles = StyleSheet.create({
//     // Keep your original styles unchanged...
//     background: { flex: 1 },
//     container: { padding: 15, paddingBottom: 40 , marginTop:30,},
//     label: { color: '#aaa', fontSize: 13, marginTop: 30, marginBottom: 5 },
//     input: {
//         backgroundColor: 'rgba(255, 255, 255, 0.05)',
//         borderRadius: 8,
//         color: '#fff',
//         padding: 15,
//         marginTop: 15,
//         fontSize: 14,
//         borderWidth: 1,
//         borderColor: 'rgba(255, 255, 255, 0.1)',
//     },
//
//     backButton: {
//         width: 32,
//         height: 32,
//         marginTop: 20,
//         justifyContent: 'center',
//         alignItems: 'center',
//         marginBottom: 10,
//     },
//     backText: { color: '#fff', fontSize: 24 },
//     title: { fontSize: 22, fontWeight: '700', color: '#fff', alignSelf: 'center', marginBottom: 20 },
//     label: { color: '#aaa', fontSize: 13, marginTop: 30, marginBottom: 5 },
//     input: {
//         backgroundColor: 'rgba(255, 255, 255, 0.05)',
//         borderRadius: 8,
//         color: '#fff',
//         padding: 15,
//         marginTop: 15,
//         fontSize: 14,
//         borderWidth: 1,
//         borderColor: 'rgba(255, 255, 255, 0.1)',
//     },
//     halfInput: { flex: 1, marginRight: 10 },
//     dobInput: { flex: 1, marginRight: 10 },
//     row: { flexDirection: 'row', justifyContent: 'space-between' },
//     radioButton: {
//         flex: 1,
//         marginRight: 10,
//         borderRadius: 20,
//         paddingVertical: 10,
//         backgroundColor: 'transparent',
//         borderWidth: 1,
//         borderColor: '#aaa',
//         alignItems: 'center',
//     },
//     radioSelected: { backgroundColor: '#FFD700', borderColor: '#FFD700' },
//     radioText: { color: '#fff', fontSize: 12 },
//     noteBox: {
//         backgroundColor: 'rgba(255, 255, 255, 0.05)',
//         borderRadius: 10,
//         padding: 12,
//         marginTop: 5,
//         borderWidth: 1,
//         borderColor: '#333',
//     },
//     noteTitle: { color: '#fff', fontWeight: 'bold', marginBottom: 10 },
//     noteText: { color: '#aaa', fontSize: 12, marginBottom: 10 },
//     checkboxRow: { flexDirection: 'row', alignItems: 'center', marginTop: 15 },
//     checkbox: {
//         width: 18,
//         height: 18,
//         borderRadius: 4,
//         borderWidth: 1,
//         borderColor: '#999',
//         justifyContent: 'center',
//         alignItems: 'center',
//         marginRight: 10,
//     },
//     feeRow: {
//         flexDirection: 'row',
//         alignItems: 'center',
//         gap: 10,
//         marginTop: 4,
//     },
//     originalFee: {
//         color: '#aaa',
//         fontSize: 16,
//         textDecorationLine: 'line-through',
//         marginRight: 10,
//     },
//     discountedFee: {
//         color: '#fff',
//         fontSize: 20,
//         fontWeight: 'bold',
//     },
//     checkboxChecked: { backgroundColor: '#FFD700', borderColor: '#FFD700' },
//     checkboxTick: { fontSize: 12, color: '#000' },
//     checkboxText: { color: '#ccc', fontSize: 13, flex: 1 },
//     feeAmount: { color: '#fff', fontSize: 20, fontWeight: 'bold', marginTop: 4 },
//     payButton: {
//         backgroundColor: '#FFBF00',
//         borderRadius: 10,
//         paddingVertical: 14,
//         alignItems: 'center',
//         marginTop: 20,
//         shadowColor: '#000',
//         shadowOpacity: 0.4,
//         shadowOffset: { width: 0, height: 2 },
//         shadowRadius: 4,
//         elevation: 3,
//     },
//     payText: { color: '#000', fontWeight: '700', fontSize: 16 },
//     dropdown: {
//         backgroundColor: 'rgba(255, 255, 255, 0.05)',
//         borderColor: 'rgba(255, 255, 255, 0.1)',
//         borderWidth: 1,
//         borderRadius: 8,
//         marginTop: 15,
//         paddingHorizontal: 10,
//     },
//     dropdownContainer: {
//         backgroundColor: 'rgba(0,0,0,1)',
//         borderColor: 'rgba(255, 255, 255, 0.1)',
//         borderWidth: 1,
//         marginTop:16,
//         borderRadius: 8,
//     },
//     dropdownText: {
//         color: '#fff',
//         fontSize: 14,
//     },
//     dropdownPlaceholder: {
//         color: '#999',
//     },
// });
//
// export default RegisterScreen;


// import React, { useState, useEffect, useMemo } from 'react';
// import {
//     View,
//     Text,
//     TextInput,
//     ScrollView,
//     TouchableOpacity,
//     StyleSheet,
//     ImageBackground,
//     Alert,
//     Platform,
// } from 'react-native';
// import { useRouter } from 'expo-router';
// import * as WebBrowser from 'expo-web-browser';
// import { FontAwesome } from '@expo/vector-icons';
// import DropDownPicker from 'react-native-dropdown-picker';
// import DateTimePicker from '@react-native-community/datetimepicker';
// import { useLocationStore } from '../../stores/locationStore';
// import { databases, DATABASE_ID, COLLECTION_ID } from '@/utils/appwrite-register-t10stcl';
// import { ID } from 'appwrite';
//
// const RegisterScreen = () => {
//     const [openRegion, setOpenRegion] = useState(false);
//     const [openCity, setOpenCity] = useState(false);
//
//     const [regionValue, setRegionValue] = useState(null);
//     const [cityValue, setCityValue] = useState(null);
//     const [cityOptions, setCityOptions] = useState([]);
//
//     const [registrationNumber, setRegistrationNumber] = useState('');
//     const [playerType, setPlayerType] = useState('');
//     const [agree, setAgree] = useState(false);
//
//     const [fullName, setFullName] = useState('');
//     const [dobDay, setDobDay] = useState('');
//     const [dobMonth, setDobMonth] = useState('');
//     const [dobYear, setDobYear] = useState('');
//
//     const [aadhaar, setAadhaar] = useState('');
//     const [email, setEmail] = useState('');
//     const [phone, setPhone] = useState('');
//     const [street, setStreet] = useState('');
//     const [cityAddress, setCityAddress] = useState('');
//     const [postalCode, setPostalCode] = useState('');
//     const [stateAddress, setStateAddress] = useState('');
//     const [countryAddress, setCountryAddress] = useState('');
//     const [referralCode, setReferralCode] = useState('');
//
//     const { country, region } = useLocationStore();
//     const router = useRouter();
//
//     const [manualCountry, setManualCountry] = useState('');
//     const [manualRegion, setManualRegion] = useState('');
//
//     const isUnknownCountry = !country || country.toLowerCase() === 'unknown country';
//     const isUnknownRegion = !region || region.toLowerCase() === 'unknown region';
//
//     const [showDatePicker, setShowDatePicker] = useState(false);
//     const [selectedDate, setSelectedDate] = useState<Date | null>(null);
//
//     useEffect(() => {
//         if (!isUnknownRegion) setStateAddress(region);
//         if (!isUnknownCountry) setCountryAddress(country);
//     }, [country, region]);
//
//     const isUAE = useMemo(() => {
//         const resolvedCountry = isUnknownCountry ? manualCountry.toLowerCase() : (country || '').toLowerCase();
//         return resolvedCountry === 'uae' || resolvedCountry === 'united arab emirates';
//     }, [country, manualCountry, isUnknownCountry]);
//
//
//     const regionOptions = useMemo(() => {
//         if (isUAE) {
//             return [
//                 { label: 'Abu Dhabi', value: 'Abu Dhabi' },
//                 { label: 'Ajman', value: 'Ajman' },
//                 { label: 'Al Ain', value: 'Al Ain' },
//                 { label: 'Dubai', value: 'Dubai' },
//                 { label: 'Fujairah', value: 'Fujairah' },
//                 { label: 'Kalba', value: 'Kalba' },
//                 { label: 'Madinat Zayed', value: 'Madinat Zayed' },
//                 { label: 'Ras Al Khaiman', value: 'Ras Al Khaiman' },
//                 { label: 'Sharjah', value: 'Sharjah' },
//                 { label: 'Umm Al Quwain', value: 'Umm Al Quwain' },
//             ];
//         }
//
//         return [
//             { label: 'West', value: 'west' },
//             { label: 'North', value: 'north' },
//             { label: 'South', value: 'south' },
//             { label: 'North-East', value: 'north-east' },
//             { label: 'Central', value: 'central' },
//             { label: 'East', value: 'east' },
//         ];
//     }, [isUAE]);
//
//     const regionToCities = {
//         west: [
//             { label: 'Mumbai', value: 'Mumbai' },
//             { label: 'Nagpur', value: 'Nagpur' },
//             { label: 'Jaipur', value: 'Jaipur' },
//             { label: 'Jodhpur', value: 'Jodhpur' },
//             { label: 'Goa', value: 'Goa' },
//         ],
//         north: [
//             { label: 'Dharamshala', value: 'Dharamshala' },
//             { label: 'Srinagar', value: 'Srinagar' },
//             { label: 'Amritsar', value: 'Amritsar' },
//             { label: 'Chandigarh', value: 'Chandigarh' },
//             { label: 'Panipat', value: 'Panipat' },
//             { label: 'Haridwar', value: 'Haridwar' },
//             { label: 'Faridabad', value: 'Faridabad' },
//             { label: 'Delhi', value: 'Delhi' },
//         ],
//         south: [
//             { label: 'Vishakhapatnam', value: 'Vishakhapatnam' },
//             { label: 'Benguluru', value: 'Benguluru' },
//             { label: 'Kochi', value: 'Kochi' },
//             { label: 'Chennai', value: 'Chennai' },
//             { label: 'Telengana', value: 'Telengana' },
//         ],
//         'north-east': [
//             { label: 'Ita Nagar', value: 'Ita Nagar' },
//             { label: 'Guwahati', value: 'Guwahati' },
//             { label: 'Imphal', value: 'Imphal' },
//             { label: 'Gangtok', value: 'Gangtok' },
//         ],
//         east: [
//             { label: 'Patna', value: 'Patna' },
//             { label: 'Prayagraj', value: 'Prayagraj' },
//             { label: 'West Bengal', value: 'West Bengal' },
//         ],
//     };
//
//     useEffect(() => {
//         if (!isUAE && regionValue && regionValue !== 'central') {
//             setCityOptions(regionToCities[regionValue] || []);
//         } else {
//             setCityOptions([]);
//             setCityValue(null);
//         }
//     }, [regionValue, isUAE]);
//
//     useEffect(() => {
//         const resolvedCountry = isUnknownCountry ? manualCountry.toLowerCase() : (country || '').toLowerCase();
//
//         const generateRegistrationNumber = () => {
//             let prefix = 'T10AE';
//
//             if (resolvedCountry === 'india') {
//                 prefix = 'T10IN';
//             } else if (resolvedCountry === 'uae' || resolvedCountry === 'united arab emirates') {
//                 prefix = 'T10UAE';
//             }
//
//             const random = Math.floor(100000 + Math.random() * 900000);
//             return `${prefix}${random}`;
//         };
//
//         setRegistrationNumber(generateRegistrationNumber());
//     }, [country, manualCountry, isUnknownCountry]);
//
//
//     const handlePay = async () => {
//         if (!agree) {
//             Alert.alert('Terms Required', 'You must agree to the terms and conditions to proceed.');
//             return;
//         }
//
//         if (!dobDay || !dobMonth || !dobYear || isNaN(+dobDay) || isNaN(+dobMonth) || isNaN(+dobYear)) {
//             Alert.alert('Invalid DOB', 'Please enter a valid Date of Birth.');
//             return;
//         }
//
//         const dob = `${dobYear}-${dobMonth.padStart(2, '0')}-${dobDay.padStart(2, '0')}`;
//
//         const resolvedCountry = (isUnknownCountry ? manualCountry : countryAddress).toLowerCase();
//         const resolvedRegion = isUnknownRegion ? manualRegion : stateAddress;
//
//         if (!resolvedCountry || resolvedCountry === 'unknown country') {
//             Alert.alert('Invalid Country', 'Please enter a valid country name.');
//             return;
//         }
//
//         if (!resolvedRegion || resolvedRegion === 'unknown region') {
//             Alert.alert('Invalid Region', 'Please enter a valid region name.');
//             return;
//         }
//
//         const formData = {
//             Register_num: registrationNumber,
//             Full_Name: fullName,
//             DOB: dob,
//             Adhaar_num: aadhaar,
//             Email: email,
//             Phone_num: phone,
//             Player_type: playerType,
//             Region: regionValue,
//             city: cityValue,
//             Reffer_code: referralCode,
//             street_adress: street,
//             city_address: cityAddress,
//             Postal_code: postalCode,
//             state: resolvedRegion,
//             country: resolvedCountry,
//         };
//
//         try {
//             await databases.createDocument(DATABASE_ID, COLLECTION_ID, ID.unique(), formData);
//
//             if (resolvedCountry === 'india') {
//                 await WebBrowser.openBrowserAsync(`https://rzp.io/rzp/P4WoMslG`);
//             } else if (resolvedCountry === 'uae' || resolvedCountry === 'united arab emirates') {
//                 // const response = await fetch(`https://www.paypal.com/ncp/payment/N9NAN5GEJLB7J`, {
//                 //     method: 'POST',
//                 //     headers: { 'Content-Type': 'application/json' },
//                 // });
//                 // const { approvalUrl } = await response.json();
//                 // await WebBrowser.openBrowserAsync(approvalUrl);
//                 await WebBrowser.openBrowserAsync(`https://www.paypal.com/ncp/payment/N9NAN5GEJLB7J`);
//             } else {
//                 Alert.alert('Unsupported Region', 'Payment is only supported for India and UAE.');
//             }
//         } catch (error) {
//             console.error('Error submitting form:', error);
//             Alert.alert('Error', 'Failed to submit registration. Please try again.');
//         }
//     };
//
//
//     return (
//         // 🔽 SKIPPED: your JSX form remains the same except this part below 🔽
//         <ImageBackground source={require('../../assets/images/bg.webp')} style={styles.background}>
//             <ScrollView contentContainerStyle={styles.container} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
//                 <TouchableOpacity onPress={() => router.back()}>
//                     <FontAwesome name="arrow-left" size={20} color="#fff" />
//                 </TouchableOpacity>
//
//                 <Text style={styles.title}>Register</Text>
//
//                 <Text style={styles.label}>REGISTRATION NUMBER</Text>
//                 <TextInput style={[styles.input, { backgroundColor: 'rgba(255,255,255,0.1)' }]} value={registrationNumber} editable={false} placeholderTextColor="#888" />
//
//                 <Text style={styles.label}>FULL NAME</Text>
//                 <TextInput style={styles.input} placeholder="Full Name" placeholderTextColor="#888" value={fullName} onChangeText={setFullName} />
//
//
//                 <Text style={styles.label}>DATE-OF-BIRTH</Text>
//                 <TouchableOpacity onPress={() => setShowDatePicker(true)}>
//                     <View style={[styles.input, { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }]}>
//                         <Text style={{ color: dobDay ? '#fff' : '#888' }}>
//                             {dobDay && dobMonth && dobYear
//                                 ? `${dobDay.padStart(2, '0')}-${dobMonth.padStart(2, '0')}-${dobYear}`
//                                 : 'Select Date of Birth'}
//                         </Text>
//                         <FontAwesome name="calendar" size={18} color="#fff" />
//                     </View>
//                 </TouchableOpacity>
//
//                 {showDatePicker && (
//                     <DateTimePicker
//                         testID="dateTimePicker"
//                         value={selectedDate || new Date(2005, 0, 1)}
//                         mode="date"
//                         display={Platform.OS === 'ios' ? 'spinner' : 'default'}
//                         maximumDate={new Date()}
//                         onChange={(event, date) => {
//                             setShowDatePicker(false);
//                             if (date) {
//                                 const day = `${date.getDate()}`;
//                                 const month = `${date.getMonth() + 1}`;
//                                 const year = `${date.getFullYear()}`;
//
//                                 setSelectedDate(date);
//                                 setDobDay(day);
//                                 setDobMonth(month);
//                                 setDobYear(year);
//                             }
//                         }}
//                     />
//                 )}
//
//                 <Text style={styles.label}>ADDRESS</Text>
//                 <TextInput style={styles.input} placeholder="Street Address" placeholderTextColor="#888" value={street} onChangeText={setStreet} />
//                 <View style={styles.row}>
//                     <TextInput style={[styles.input, styles.halfInput]} placeholder="City" value={cityAddress} onChangeText={setCityAddress} placeholderTextColor="#888" />
//
//                     {isUnknownRegion ? (
//                         <TextInput
//                             style={[styles.input, styles.halfInput]}
//                             placeholder="State"
//                             placeholderTextColor="#888"
//                             value={manualRegion}
//                             onChangeText={setManualRegion}
//                         />
//                     ) : (
//                         <TextInput
//                             style={[styles.input, styles.halfInput]}
//                             value={region || ''}
//                             editable={false}
//                             placeholder="State"
//                         />
//                     )}
//                 </View>
//
//                 <View style={styles.row}>
//                     <TextInput
//                         style={[styles.input, styles.halfInput]}
//                         placeholder="Postal Code"
//                         value={postalCode}
//                         onChangeText={setPostalCode}
//                         placeholderTextColor="#888"
//                     />
//
//                     {isUnknownCountry ? (
//                         <TextInput
//                             style={[styles.input, styles.halfInput]}
//                             placeholder="Country"
//                             placeholderTextColor="#888"
//                             value={manualCountry}
//                             onChangeText={setManualCountry}
//                         />
//                     ) : (
//                         <TextInput
//                             style={[styles.input, styles.halfInput]}
//                             value={country || ''}
//                             editable={false}
//                             placeholder="Country"
//                         />
//                     )}
//                 </View>
//
//                 <Text style={styles.label}>{isUAE ? 'EMIRATES ID' : 'ADHAAR CARD NUMBER (No Spaces)'}</Text>
//                 <TextInput style={styles.input} placeholder={isUAE ? 'Emirates ID' : 'Adhaar Card'} value={aadhaar} onChangeText={setAadhaar} keyboardType="numeric"  placeholderTextColor="#888"/>
//
//                 <View style={styles.row}>
//                     <TextInput style={[styles.input, styles.halfInput]} placeholder="Email ID" value={email} onChangeText={setEmail}  placeholderTextColor="#888"/>
//                     <TextInput style={[styles.input, styles.halfInput]} placeholder="Phone No." keyboardType="phone-pad" value={phone} onChangeText={setPhone}  placeholderTextColor="#888"/>
//                 </View>
//
//                 <Text style={styles.label}>PLAYER TYPE</Text>
//                 <View style={styles.row}>
//                     {['BATSMEN', 'BOWLER', 'ALL-ROUNDER'].map((type) => (
//                         <TouchableOpacity key={type} style={[styles.radioButton, playerType === type && styles.radioSelected]} onPress={() => setPlayerType(type)}>
//                             <Text style={[styles.radioText, playerType === type && { color: '#000' }]}>{type}</Text>
//                         </TouchableOpacity>
//                     ))}
//                 </View>
//
//                 <Text style={styles.label}>SELECT REGION</Text>
//                 <View style={{ zIndex: 1000 }}>
//                     <DropDownPicker
//                         open={openRegion}
//                         setOpen={setOpenRegion}
//                         value={regionValue}
//                         setValue={setRegionValue}
//                         items={regionOptions}
//                         placeholder="Select Region"
//                         style={styles.dropdown}
//                         dropDownContainerStyle={styles.dropdownContainer}
//                         textStyle={styles.dropdownText}
//                         placeholderStyle={styles.dropdownPlaceholder}
//                     />
//                 </View>
//
//                 {!isUAE && regionValue !== 'central' && cityOptions.length > 0 && (
//                     <>
//                         <Text style={styles.label}>SELECT CITY</Text>
//                         <View style={{ zIndex: 999 }}>
//                             <DropDownPicker
//                                 open={openCity}
//                                 setOpen={setOpenCity}
//                                 value={cityValue}
//                                 setValue={setCityValue}
//                                 items={cityOptions}
//                                 placeholder="Select City"
//                                 style={styles.dropdown}
//                                 dropDownContainerStyle={styles.dropdownContainer}
//                                 textStyle={styles.dropdownText}
//                                 placeholderStyle={styles.dropdownPlaceholder}
//                             />
//                         </View>
//                     </>
//                 )}
//
//                 <Text style={styles.label}>REFERRAL CODE (Optional)</Text>
//                 <TextInput style={styles.input} placeholder="Code" value={referralCode} placeholderTextColor="#888" onChangeText={setReferralCode} />
//                 <Text style={styles.label}>COMPETITION TERMS AND SERVICES</Text>
//                 <View style={styles.noteBox}>
//                     <Text style={styles.noteTitle}>NOTE :-</Text>
//                     <Text style={styles.noteText}>1. The registration fee for participation in the T10-STCL trials conducted by Significant Sports and Entertainment Pvt. Ltd. is a non-refundable trial fee of ₹699, plus 18% GST.</Text>
//                     <Text style={styles.noteText}>2. Once the payment is completed, please check your registered email ID for a copy of the registration form.</Text>
//                     <Text style={styles.noteText}>3. Trial details will be shared one week before the trials to your registered email ID.</Text>
//                 </View>
//
//                 <TouchableOpacity style={styles.checkboxRow} onPress={() => setAgree(!agree)}>
//                     <View style={[styles.checkbox, agree && styles.checkboxChecked]}>
//                         {agree && <Text style={styles.checkboxTick}>✓</Text>}
//                     </View>
//                     <Text style={styles.checkboxText}>I agree to the competition terms and conditions</Text>
//                 </TouchableOpacity>
//
//                 <Text style={styles.label}>REGISTRATION FEES</Text>
//                 <View style={styles.feeRow}>
//                     <Text style={styles.originalFee}>₹ 1094.84</Text>
//                     <Text style={styles.discountedFee}>₹ 842.82</Text>
//                 </View>
//
//                 <TouchableOpacity style={styles.payButton} onPress={handlePay}>
//                     <Text style={styles.payText}>Pay</Text>
//                 </TouchableOpacity>
//             </ScrollView>
//         </ImageBackground>
// );
// };
//
// const styles = StyleSheet.create({
//     // Keep your original styles unchanged...
//     background: { flex: 1 },
//     container: { padding: 15, paddingBottom: 40 , marginTop:30,},
//     label: { color: '#aaa', fontSize: 13, marginTop: 30, marginBottom: 5 },
//     input: {
//         backgroundColor: 'rgba(255, 255, 255, 0.05)',
//         borderRadius: 8,
//         color: '#fff',
//         padding: 15,
//         marginTop: 15,
//         fontSize: 14,
//         borderWidth: 1,
//         borderColor: 'rgba(255, 255, 255, 0.1)',
//     },
//
//     backButton: {
//         width: 32,
//         height: 32,
//         marginTop: 20,
//         justifyContent: 'center',
//         alignItems: 'center',
//         marginBottom: 10,
//     },
//     backText: { color: '#fff', fontSize: 24 },
//     title: { fontSize: 22, fontWeight: '700', color: '#fff', alignSelf: 'center', marginBottom: 20 },
//     label: { color: '#aaa', fontSize: 13, marginTop: 30, marginBottom: 5 },
//     input: {
//         backgroundColor: 'rgba(255, 255, 255, 0.05)',
//         borderRadius: 8,
//         color: '#fff',
//         padding: 15,
//         marginTop: 15,
//         fontSize: 14,
//         borderWidth: 1,
//         borderColor: 'rgba(255, 255, 255, 0.1)',
//     },
//     halfInput: { flex: 1, marginRight: 10 },
//     dobInput: { flex: 1, marginRight: 10 },
//     row: { flexDirection: 'row', justifyContent: 'space-between' },
//     radioButton: {
//         flex: 1,
//         marginRight: 10,
//         borderRadius: 20,
//         paddingVertical: 10,
//         backgroundColor: 'transparent',
//         borderWidth: 1,
//         borderColor: '#aaa',
//         alignItems: 'center',
//     },
//     radioSelected: { backgroundColor: '#FFD700', borderColor: '#FFD700' },
//     radioText: { color: '#fff', fontSize: 12 },
//     noteBox: {
//         backgroundColor: 'rgba(255, 255, 255, 0.05)',
//         borderRadius: 10,
//         padding: 12,
//         marginTop: 5,
//         borderWidth: 1,
//         borderColor: '#333',
//     },
//     noteTitle: { color: '#fff', fontWeight: 'bold', marginBottom: 10 },
//     noteText: { color: '#aaa', fontSize: 12, marginBottom: 10 },
//     checkboxRow: { flexDirection: 'row', alignItems: 'center', marginTop: 15 },
//     checkbox: {
//         width: 18,
//         height: 18,
//         borderRadius: 4,
//         borderWidth: 1,
//         borderColor: '#999',
//         justifyContent: 'center',
//         alignItems: 'center',
//         marginRight: 10,
//     },
//     feeRow: {
//         flexDirection: 'row',
//         alignItems: 'center',
//         gap: 10,
//         marginTop: 4,
//     },
//     originalFee: {
//         color: '#aaa',
//         fontSize: 16,
//         textDecorationLine: 'line-through',
//         marginRight: 10,
//     },
//     discountedFee: {
//         color: '#fff',
//         fontSize: 20,
//         fontWeight: 'bold',
//     },
//     checkboxChecked: { backgroundColor: '#FFD700', borderColor: '#FFD700' },
//     checkboxTick: { fontSize: 12, color: '#000' },
//     checkboxText: { color: '#ccc', fontSize: 13, flex: 1 },
//     feeAmount: { color: '#fff', fontSize: 20, fontWeight: 'bold', marginTop: 4 },
//     payButton: {
//         backgroundColor: '#FFBF00',
//         borderRadius: 10,
//         paddingVertical: 14,
//         alignItems: 'center',
//         marginTop: 20,
//         shadowColor: '#000',
//         shadowOpacity: 0.4,
//         shadowOffset: { width: 0, height: 2 },
//         shadowRadius: 4,
//         elevation: 3,
//     },
//     payText: { color: '#000', fontWeight: '700', fontSize: 16 },
//     dropdown: {
//         backgroundColor: 'rgba(255, 255, 255, 0.05)',
//         borderColor: 'rgba(255, 255, 255, 0.1)',
//         borderWidth: 1,
//         borderRadius: 8,
//         marginTop: 15,
//         paddingHorizontal: 10,
//     },
//     dropdownContainer: {
//         backgroundColor: 'rgba(0,0,0,1)',
//         borderColor: 'rgba(255, 255, 255, 0.1)',
//         borderWidth: 1,
//         marginTop:16,
//         borderRadius: 8,
//     },
//     dropdownText: {
//         color: '#fff',
//         fontSize: 14,
//     },
//     dropdownPlaceholder: {
//         color: '#999',
//     },
// });
//
// export default RegisterScreen;








import React, { useState, useEffect, useMemo } from 'react';
import {
    View,
    Text,
    TextInput,
    ScrollView,
    TouchableOpacity,
    StyleSheet,
    ImageBackground,
    Alert,
    Platform,
} from 'react-native';
import { useRouter } from 'expo-router';
import * as WebBrowser from 'expo-web-browser';
import { FontAwesome } from '@expo/vector-icons';
import DropDownPicker from 'react-native-dropdown-picker';
import DateTimePicker from '@react-native-community/datetimepicker';
import { useLocationStore } from '../../stores/locationStore';
import { databases, DATABASE_ID, COLLECTION_ID } from '@/utils/appwrite-register-t10stcl';
import { ID } from 'appwrite';

const RegisterScreen = () => {
    const [openRegion, setOpenRegion] = useState(false);
    const [openCity, setOpenCity] = useState(false);

    const [regionValue, setRegionValue] = useState(null);
    const [cityValue, setCityValue] = useState(null);
    const [cityOptions, setCityOptions] = useState([]);

    const [registrationNumber, setRegistrationNumber] = useState('');
    const [playerType, setPlayerType] = useState('');
    const [agree, setAgree] = useState(false);

    const [fullName, setFullName] = useState('');
    const [dobDay, setDobDay] = useState('');
    const [dobMonth, setDobMonth] = useState('');
    const [dobYear, setDobYear] = useState('');

    const [aadhaar, setAadhaar] = useState('');
    const [email, setEmail] = useState('');
    const [phone, setPhone] = useState('');
    const [street, setStreet] = useState('');
    const [cityAddress, setCityAddress] = useState('');
    const [postalCode, setPostalCode] = useState('');
    const [stateAddress, setStateAddress] = useState('');
    const [countryAddress, setCountryAddress] = useState('');
    const [referralCode, setReferralCode] = useState('');

    const { country, region } = useLocationStore();
    const router = useRouter();

    const [manualCountry, setManualCountry] = useState('');
    const [manualRegion, setManualRegion] = useState('');

    const isUnknownCountry = !country || country.toLowerCase() === 'unknown country';
    const isUnknownRegion = !region || region.toLowerCase() === 'unknown region';

    const [showDatePicker, setShowDatePicker] = useState(false);
    const [selectedDate, setSelectedDate] = useState<Date | null>(null);

    useEffect(() => {
        if (!isUnknownRegion) setStateAddress(region);
        if (!isUnknownCountry) setCountryAddress(country);
    }, [country, region]);

    const isUAE = useMemo(() => {
        const resolvedCountry = isUnknownCountry ? manualCountry.toLowerCase() : (country || '').toLowerCase();
        return resolvedCountry === 'uae' || resolvedCountry === 'united arab emirates';
    }, [country, manualCountry, isUnknownCountry]);

    const isIndia = useMemo(() => {
        const resolvedCountry = isUnknownCountry ? manualCountry.toLowerCase() : (country || '').toLowerCase();
        return resolvedCountry === 'india';
    }, [country, manualCountry, isUnknownCountry]);

    const regionOptions = useMemo(() => {
        if (isUAE) {
            return [
                { label: 'Abu Dhabi', value: 'Abu Dhabi' },
                { label: 'Ajman', value: 'Ajman' },
                { label: 'Al Ain', value: 'Al Ain' },
                { label: 'Dubai', value: 'Dubai' },
                { label: 'Fujairah', value: 'Fujairah' },
                { label: 'Kalba', value: 'Kalba' },
                { label: 'Madinat Zayed', value: 'Madinat Zayed' },
                { label: 'Ras Al Khaiman', value: 'Ras Al Khaiman' },
                { label: 'Sharjah', value: 'Sharjah' },
                { label: 'Umm Al Quwain', value: 'Umm Al Quwain' },
            ];
        }

        return [
            { label: 'West', value: 'west' },
            { label: 'North', value: 'north' },
            { label: 'South', value: 'south' },
            { label: 'North-East', value: 'north-east' },
            { label: 'Central', value: 'central' },
            { label: 'East', value: 'east' },
        ];
    }, [isUAE]);

    const regionToCities = {
        west: [
            { label: 'Mumbai', value: 'Mumbai' },
            { label: 'Nagpur', value: 'Nagpur' },
            { label: 'Jaipur', value: 'Jaipur' },
            { label: 'Jodhpur', value: 'Jodhpur' },
            { label: 'Goa', value: 'Goa' },
        ],
        north: [
            { label: 'Dharamshala', value: 'Dharamshala' },
            { label: 'Srinagar', value: 'Srinagar' },
            { label: 'Amritsar', value: 'Amritsar' },
            { label: 'Chandigarh', value: 'Chandigarh' },
            { label: 'Panipat', value: 'Panipat' },
            { label: 'Haridwar', value: 'Haridwar' },
            { label: 'Faridabad', value: 'Faridabad' },
            { label: 'Delhi', value: 'Delhi' },
        ],
        south: [
            { label: 'Vishakhapatnam', value: 'Vishakhapatnam' },
            { label: 'Benguluru', value: 'Benguluru' },
            { label: 'Kochi', value: 'Kochi' },
            { label: 'Chennai', value: 'Chennai' },
            { label: 'Telengana', value: 'Telengana' },
        ],
        'north-east': [
            { label: 'Ita Nagar', value: 'Ita Nagar' },
            { label: 'Guwahati', value: 'Guwahati' },
            { label: 'Imphal', value: 'Imphal' },
            { label: 'Gangtok', value: 'Gangtok' },
        ],
        east: [
            { label: 'Patna', value: 'Patna' },
            { label: 'Prayagraj', value: 'Prayagraj' },
            { label: 'West Bengal', value: 'West Bengal' },
        ],
    };

    useEffect(() => {
        if (!isUAE && regionValue && regionValue !== 'central') {
            setCityOptions(regionToCities[regionValue] || []);
        } else {
            setCityOptions([]);
            setCityValue(null);
        }
    }, [regionValue, isUAE]);

    useEffect(() => {
        const resolvedCountry = isUnknownCountry ? manualCountry.toLowerCase() : (country || '').toLowerCase();

        const generateRegistrationNumber = () => {
            let prefix = 'T10AE';

            if (resolvedCountry === 'india') {
                prefix = 'T10IN';
            } else if (resolvedCountry === 'uae' || resolvedCountry === 'united arab emirates') {
                prefix = 'T10UAE';
            }

            const random = Math.floor(100000 + Math.random() * 900000);
            return `${prefix}${random}`;
        };

        setRegistrationNumber(generateRegistrationNumber());
    }, [country, manualCountry, isUnknownCountry]);

    const handlePay = async () => {
        if (isIndia) {
            await WebBrowser.openBrowserAsync('https://register.t10stcl.com');
            return;
        }

        if (!agree) {
            Alert.alert('Terms Required', 'You must agree to the terms and conditions to proceed.');
            return;
        }

        if (!dobDay || !dobMonth || !dobYear || isNaN(+dobDay) || isNaN(+dobMonth) || isNaN(+dobYear)) {
            Alert.alert('Invalid DOB', 'Please enter a valid Date of Birth.');
            return;
        }

        const dob = `${dobYear}-${dobMonth.padStart(2, '0')}-${dobDay.padStart(2, '0')}`;

        const resolvedCountry = (isUnknownCountry ? manualCountry : countryAddress).toLowerCase();
        const resolvedRegion = isUnknownRegion ? manualRegion : stateAddress;

        if (!resolvedCountry || resolvedCountry === 'unknown country') {
            Alert.alert('Invalid Country', 'Please enter a valid country name.');
            return;
        }

        if (!resolvedRegion || resolvedRegion === 'unknown region') {
            Alert.alert('Invalid Region', 'Please enter a valid region name.');
            return;
        }

        const formData = {
            Register_num: registrationNumber,
            Full_Name: fullName,
            DOB: dob,
            Adhaar_num: aadhaar,
            Email: email,
            Phone_num: phone,
            Player_type: playerType,
            Region: regionValue,
            city: cityValue,
            Reffer_code: referralCode,
            street_adress: street,
            city_address: cityAddress,
            Postal_code: postalCode,
            state: resolvedRegion,
            country: resolvedCountry,
        };

        try {
            await databases.createDocument(DATABASE_ID, COLLECTION_ID, ID.unique(), formData);

            if (resolvedCountry === 'india') {
                await WebBrowser.openBrowserAsync(`https://rzp.io/rzp/P4WoMslG`);
            } else if (resolvedCountry === 'uae' || resolvedCountry === 'united arab emirates') {
                await WebBrowser.openBrowserAsync(`https://www.paypal.com/ncp/payment/N9NAN5GEJLB7J`);
            } else {
                Alert.alert('Unsupported Region', 'Payment is only supported for India and UAE.');
            }
        } catch (error) {
            console.error('Error submitting form:', error);
            Alert.alert('Error', 'Failed to submit registration. Please try again.');
        }
    };

    const getInputStyle = () => {
        return isIndia ? [styles.input, styles.disabledInput] : styles.input;
    };

    return (
        <ImageBackground source={require('../../assets/images/bg.webp')} style={styles.background}>
            <ScrollView contentContainerStyle={styles.container} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
                <TouchableOpacity onPress={() => router.back()}>
                    <FontAwesome name="arrow-left" size={20} color="#fff" />
                </TouchableOpacity>

                <Text style={styles.title}>Register</Text>

                {isIndia && (
                    <View style={styles.indiaNotice}>
                        <Text style={styles.indiaNoticeText}>
                            For India registrations, please visit register.t10stcl.com
                        </Text>
                    </View>
                )}

                <Text style={styles.label}>REGISTRATION NUMBER</Text>
                <TextInput style={[styles.input, { backgroundColor: 'rgba(255,255,255,0.1)' }]} value={registrationNumber} editable={false} placeholderTextColor="#888" />

                <Text style={styles.label}>FULL NAME</Text>
                <TextInput
                    style={getInputStyle()}
                    placeholder="Full Name"
                    placeholderTextColor="#888"
                    value={fullName}
                    onChangeText={setFullName}
                    editable={!isIndia}
                />

                <Text style={styles.label}>DATE-OF-BIRTH</Text>
                <TouchableOpacity onPress={() => !isIndia && setShowDatePicker(true)}>
                    <View style={[getInputStyle(), { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }]}>
                        <Text style={{ color: dobDay ? '#fff' : '#888' }}>
                            {dobDay && dobMonth && dobYear
                                ? `${dobDay.padStart(2, '0')}-${dobMonth.padStart(2, '0')}-${dobYear}`
                                : 'Select Date of Birth'}
                        </Text>
                        <FontAwesome name="calendar" size={18} color={isIndia ? "#555" : "#fff"} />
                    </View>
                </TouchableOpacity>

                {showDatePicker && (
                    <DateTimePicker
                        testID="dateTimePicker"
                        value={selectedDate || new Date(2005, 0, 1)}
                        mode="date"
                        display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                        maximumDate={new Date()}
                        onChange={(event, date) => {
                            setShowDatePicker(false);
                            if (date) {
                                const day = `${date.getDate()}`;
                                const month = `${date.getMonth() + 1}`;
                                const year = `${date.getFullYear()}`;

                                setSelectedDate(date);
                                setDobDay(day);
                                setDobMonth(month);
                                setDobYear(year);
                            }
                        }}
                    />
                )}

                <Text style={styles.label}>ADDRESS</Text>
                <TextInput
                    style={getInputStyle()}
                    placeholder="Street Address"
                    placeholderTextColor="#888"
                    value={street}
                    onChangeText={setStreet}
                    editable={!isIndia}
                />
                <View style={styles.row}>
                    <TextInput
                        style={[getInputStyle(), styles.halfInput]}
                        placeholder="City"
                        value={cityAddress}
                        onChangeText={setCityAddress}
                        placeholderTextColor="#888"
                        editable={!isIndia}
                    />

                    {isUnknownRegion ? (
                        <TextInput
                            style={[getInputStyle(), styles.halfInput]}
                            placeholder="State"
                            placeholderTextColor="#888"
                            value={isIndia ? (region || '') : manualRegion}
                            onChangeText={setManualRegion}
                            editable={!isIndia}
                        />
                    ) : (
                        <TextInput
                            style={[getInputStyle(), styles.halfInput]}
                            value={region || ''}
                            editable={false}
                            placeholder="State"
                        />
                    )}
                </View>

                <View style={styles.row}>
                    <TextInput
                        style={[getInputStyle(), styles.halfInput]}
                        placeholder="Postal Code"
                        value={postalCode}
                        onChangeText={setPostalCode}
                        placeholderTextColor="#888"
                        editable={!isIndia}
                    />

                    {isUnknownCountry ? (
                        <TextInput
                            style={[getInputStyle(), styles.halfInput]}
                            placeholder="Country"
                            placeholderTextColor="#888"
                            value={isIndia ? (country || '') : manualCountry}
                            onChangeText={setManualCountry}
                            editable={!isIndia}
                        />
                    ) : (
                        <TextInput
                            style={[getInputStyle(), styles.halfInput]}
                            value={country || ''}
                            editable={false}
                            placeholder="Country"
                        />
                    )}
                </View>

                <Text style={styles.label}>{isUAE ? 'EMIRATES ID' : 'ADHAAR CARD NUMBER (No Spaces)'}</Text>
                <TextInput
                    style={getInputStyle()}
                    placeholder={isUAE ? 'Emirates ID' : 'Adhaar Card'}
                    value={aadhaar}
                    onChangeText={setAadhaar}
                    keyboardType="numeric"
                    placeholderTextColor="#888"
                    editable={!isIndia}
                />

                <View style={styles.row}>
                    <TextInput
                        style={[getInputStyle(), styles.halfInput]}
                        placeholder="Email ID"
                        value={email}
                        onChangeText={setEmail}
                        placeholderTextColor="#888"
                        editable={!isIndia}
                    />
                    <TextInput
                        style={[getInputStyle(), styles.halfInput]}
                        placeholder="Phone No."
                        keyboardType="phone-pad"
                        value={phone}
                        onChangeText={setPhone}
                        placeholderTextColor="#888"
                        editable={!isIndia}
                    />
                </View>

                <Text style={styles.label}>PLAYER TYPE</Text>
                <View style={styles.row}>
                    {['BATSMEN', 'BOWLER', 'ALL-ROUNDER'].map((type) => (
                        <TouchableOpacity
                            key={type}
                            style={[
                                styles.radioButton,
                                playerType === type && styles.radioSelected,
                                isIndia && styles.disabledRadioButton
                            ]}
                            onPress={() => !isIndia && setPlayerType(type)}
                            disabled={isIndia}
                        >
                            <Text style={[
                                styles.radioText,
                                playerType === type && { color: '#000' },
                                isIndia && { color: '#555' }
                            ]}>{type}</Text>
                        </TouchableOpacity>
                    ))}
                </View>

                <Text style={styles.label}>SELECT REGION</Text>
                <View style={{ zIndex: 1000 }}>
                    <DropDownPicker
                        open={openRegion}
                        setOpen={setOpenRegion}
                        value={regionValue}
                        setValue={setRegionValue}
                        items={regionOptions}
                        placeholder="Select Region"
                        style={isIndia ? [styles.dropdown, styles.disabledDropdown] : styles.dropdown}
                        dropDownContainerStyle={isIndia ? [styles.dropdownContainer, styles.disabledDropdownContainer] : styles.dropdownContainer}
                        textStyle={isIndia ? [styles.dropdownText, styles.disabledDropdownText] : styles.dropdownText}
                        placeholderStyle={isIndia ? [styles.dropdownPlaceholder, styles.disabledDropdownText] : styles.dropdownPlaceholder}
                        disabled={isIndia}
                    />
                </View>

                {!isUAE && regionValue !== 'central' && cityOptions.length > 0 && (
                    <>
                        <Text style={styles.label}>SELECT CITY</Text>
                        <View style={{ zIndex: 999 }}>
                            <DropDownPicker
                                open={openCity}
                                setOpen={setOpenCity}
                                value={cityValue}
                                setValue={setCityValue}
                                items={cityOptions}
                                placeholder="Select City"
                                style={isIndia ? [styles.dropdown, styles.disabledDropdown] : styles.dropdown}
                                dropDownContainerStyle={isIndia ? [styles.dropdownContainer, styles.disabledDropdownContainer] : styles.dropdownContainer}
                                textStyle={isIndia ? [styles.dropdownText, styles.disabledDropdownText] : styles.dropdownText}
                                placeholderStyle={isIndia ? [styles.dropdownPlaceholder, styles.disabledDropdownText] : styles.dropdownPlaceholder}
                                disabled={isIndia}
                            />
                        </View>
                    </>
                )}

                <Text style={styles.label}>REFERRAL CODE (Optional)</Text>
                <TextInput
                    style={getInputStyle()}
                    placeholder="Code"
                    value={referralCode}
                    placeholderTextColor="#888"
                    onChangeText={setReferralCode}
                    editable={!isIndia}
                />

                <Text style={styles.label}>COMPETITION TERMS AND SERVICES</Text>
                <View style={styles.noteBox}>
                    <Text style={styles.noteTitle}>NOTE :-</Text>
                    <Text style={styles.noteText}>1. The registration fee for participation in the T10-STCL trials conducted by Significant Sports and Entertainment Pvt. Ltd. is a non-refundable trial fee of ₹699, plus 18% GST.</Text>
                    <Text style={styles.noteText}>2. Once the payment is completed, please check your registered email ID for a copy of the registration form.</Text>
                    <Text style={styles.noteText}>3. Trial details will be shared one week before the trials to your registered email ID.</Text>
                </View>

                {!isIndia && (
                    <TouchableOpacity style={styles.checkboxRow} onPress={() => setAgree(!agree)}>
                        <View style={[styles.checkbox, agree && styles.checkboxChecked]}>
                            {agree && <Text style={styles.checkboxTick}>✓</Text>}
                        </View>
                        <Text style={styles.checkboxText}>I agree to the competition terms and conditions</Text>
                    </TouchableOpacity>
                )}

                {!isIndia && (
                    <>
                        <Text style={styles.label}>REGISTRATION FEES</Text>
                        <View style={styles.feeRow}>
                            <Text style={styles.originalFee}>₹ 1094.84</Text>
                            <Text style={styles.discountedFee}>₹ 842.82</Text>
                        </View>
                    </>
                )}

                <TouchableOpacity
                    style={[
                        styles.payButton,
                        isIndia && styles.registerButton
                    ]}
                    onPress={handlePay}
                >
                    <Text style={styles.payText}>
                        {isIndia ? 'Register at register.t10stcl.com' : 'Pay'}
                    </Text>
                </TouchableOpacity>
            </ScrollView>
        </ImageBackground>
    );
};

const styles = StyleSheet.create({
    background: { flex: 1 },
    container: { padding: 15, paddingBottom: 40, marginTop: 30 },
    title: { fontSize: 22, fontWeight: '700', color: '#fff', alignSelf: 'center', marginBottom: 20 },
    label: { color: '#aaa', fontSize: 13, marginTop: 30, marginBottom: 5 },
    input: {
        backgroundColor: 'rgba(255, 255, 255, 0.05)',
        borderRadius: 8,
        color: '#fff',
        padding: 15,
        marginTop: 15,
        fontSize: 14,
        borderWidth: 1,
        borderColor: 'rgba(255, 255, 255, 0.1)',
    },
    disabledInput: {
        backgroundColor: 'rgba(255, 255, 255, 0.02)',
        borderColor: 'rgba(255, 255, 255, 0.05)',
        color: '#555',
    },
    halfInput: { flex: 1, marginRight: 10 },
    row: { flexDirection: 'row', justifyContent: 'space-between' },
    radioButton: {
        flex: 1,
        marginRight: 10,
        borderRadius: 20,
        paddingVertical: 10,
        backgroundColor: 'transparent',
        borderWidth: 1,
        borderColor: '#aaa',
        alignItems: 'center',
    },
    disabledRadioButton: {
        borderColor: '#555',
    },
    radioSelected: { backgroundColor: '#FFD700', borderColor: '#FFD700' },
    radioText: { color: '#fff', fontSize: 12 },
    noteBox: {
        backgroundColor: 'rgba(255, 255, 255, 0.05)',
        borderRadius: 10,
        padding: 12,
        marginTop: 5,
        borderWidth: 1,
        borderColor: '#333',
    },
    noteTitle: { color: '#fff', fontWeight: 'bold', marginBottom: 10 },
    noteText: { color: '#aaa', fontSize: 12, marginBottom: 10 },
    checkboxRow: { flexDirection: 'row', alignItems: 'center', marginTop: 15 },
    checkbox: {
        width: 18,
        height: 18,
        borderRadius: 4,
        borderWidth: 1,
        borderColor: '#999',
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: 10,
    },
    feeRow: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 10,
        marginTop: 4,
    },
    originalFee: {
        color: '#aaa',
        fontSize: 16,
        textDecorationLine: 'line-through',
        marginRight: 10,
    },
    discountedFee: {
        color: '#fff',
        fontSize: 20,
        fontWeight: 'bold',
    },
    checkboxChecked: { backgroundColor: '#FFD700', borderColor: '#FFD700' },
    checkboxTick: { fontSize: 12, color: '#000' },
    checkboxText: { color: '#ccc', fontSize: 13, flex: 1 },
    payButton: {
        backgroundColor: '#FFBF00',
        borderRadius: 10,
        paddingVertical: 14,
        alignItems: 'center',
        marginTop: 20,
        shadowColor: '#000',
        shadowOpacity: 0.4,
        shadowOffset: { width: 0, height: 2 },
        shadowRadius: 4,
        elevation: 3,
    },
    registerButton: {
        backgroundColor: '#333',
    },
    payText: { color: '#000', fontWeight: '700', fontSize: 16 },
    dropdown: {
        backgroundColor: 'rgba(255, 255, 255, 0.05)',
        borderColor: 'rgba(255, 255, 255, 0.1)',
        borderWidth: 1,
        borderRadius: 8,
        marginTop: 15,
        paddingHorizontal: 10,
    },
    disabledDropdown: {
        backgroundColor: 'rgba(255, 255, 255, 0.02)',
        borderColor: 'rgba(255, 255, 255, 0.05)',
    },
    dropdownContainer: {
        backgroundColor: 'rgba(0,0,0,1)',
        borderColor: 'rgba(255, 255, 255, 0.1)',
        borderWidth: 1,
        marginTop: 16,
        borderRadius: 8,
    },
    disabledDropdownContainer: {
        backgroundColor: 'rgba(20,20,20,1)',
    },
    dropdownText: {
        color: '#fff',
        fontSize: 14,
    },
    disabledDropdownText: {
        color: '#555',
    },
    dropdownPlaceholder: {
        color: '#999',
    },
    indiaNotice: {
        backgroundColor: 'rgba(255, 0, 0, 0.2)',
        padding: 10,
        borderRadius: 5,
        marginBottom: 20,
        borderWidth: 1,
        borderColor: 'rgba(255, 0, 0, 0.5)',
    },
    indiaNoticeText: {
        color: '#fff',
        textAlign: 'center',
    },
});

export default RegisterScreen;









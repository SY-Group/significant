// // import React from 'react';
// // import {
// //     View,
// //     StyleSheet,
// //     Image,
// //     ImageBackground,
// //     TouchableWithoutFeedback,
// // } from 'react-native';
// // import { useRouter } from 'expo-router';
// //
// // const SplashScreen = () => {
// //     const router = useRouter();
// //
// //     const handlePress = () => {
// //         router.replace('../Splash-Screen/location');
// //     };
// //
// //     return (
// //         <TouchableWithoutFeedback onPress={handlePress}>
// //             <View style={styles.container}>
// //                 <ImageBackground
// //                     source={require('../../assets/images/bg.webp')} // use your background image path
// //                     style={styles.backgroundImage}
// //                     resizeMode="cover"
// //                 >
// //                     <View style={styles.logoContainer}>
// //                         <Image
// //                             source={require('../../assets/images/sg-logo.webp')} // use your logo image path
// //                             style={styles.logo}
// //                             resizeMode="contain"
// //                         />
// //                     </View>
// //                 </ImageBackground>
// //             </View>
// //         </TouchableWithoutFeedback>
// //     );
// // };
// //
// // export default SplashScreen;
// //
// // const styles = StyleSheet.create({
// //     container: {
// //         flex: 1,
// //     },
// //     backgroundImage: {
// //         flex: 1,
// //         justifyContent: 'center',
// //         alignItems: 'center',
// //     },
// //     logoContainer: {
// //         alignItems: 'center',
// //         justifyContent: 'center',
// //     },
// //     logo: {
// //         width: 200,
// //         height: 200,
// //     },
// // });
//
//


import React, { useEffect, useRef } from 'react';
import {
    View,
    StyleSheet,
    Image,
    ImageBackground,
    Animated,
} from 'react-native';
import { useRouter } from 'expo-router';

const SplashScreen = () => {
    const router = useRouter();

    const scaleAnim = useRef(new Animated.Value(0)).current;
    const opacityAnim = useRef(new Animated.Value(0)).current;

    useEffect(() => {
        // Start animation
        Animated.parallel([
            Animated.timing(scaleAnim, {
                toValue: 1,
                duration: 1200,
                useNativeDriver: true,
            }),
            Animated.timing(opacityAnim, {
                toValue: 1,
                duration: 1200,
                useNativeDriver: true,
            }),
        ]).start();

        // Auto redirect after 5 seconds
        const timeout = setTimeout(() => {
            router.replace('../Splash-Screen/location');
        }, 3000);

        return () => clearTimeout(timeout); // Cleanup on unmount
    }, []);

    return (
        <View style={styles.container}>
            <ImageBackground
                source={require('../../assets/images/bg.webp')}
                style={styles.backgroundImage}
                resizeMode="cover"
            >
                <Animated.View
                    style={[
                        styles.logoContainer,
                        {
                            transform: [{ scale: scaleAnim }],
                            opacity: opacityAnim,
                        },
                    ]}
                >
                    <Image
                        source={require('../../assets/images/sg-logo.webp')}
                        style={styles.logo}
                        resizeMode="contain"
                    />
                </Animated.View>
            </ImageBackground>
        </View>
    );
};

export default SplashScreen;

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    backgroundImage: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    logoContainer: {
        alignItems: 'center',
        justifyContent: 'center',
    },
    logo: {
        width: 200,
        height: 200,
    },
});

// screens/TestNotification.tsx
// import React from 'react';
// import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
// import { useUser } from '@clerk/clerk-expo';
// import { createNotification } from '../lib/createNotification';
//
// export default function TestNotificationScreen() {
//     const { user } = useUser();
//
//     const handleSendNotification = async () => {
//         if (!user?.id) return;
//         await createNotification(user.id, '🎉 You got selected!', 'Your audition video was shortlisted.');
//     };
//
//     return (
//         <View style={styles.container}>
//             <Text style={styles.heading}>Send Test Notification</Text>
//             <TouchableOpacity style={styles.button} onPress={handleSendNotification}>
//                 <Text style={styles.buttonText}>Send Notification</Text>
//             </TouchableOpacity>
//         </View>
//     );
// }
//
// const styles = StyleSheet.create({
//     container: { flex: 1, alignItems: 'center', justifyContent: 'center' },
//     heading: { fontSize: 20, marginBottom: 20 },
//     button: {
//         padding: 15,
//         backgroundColor: '#FACC15',
//         borderRadius: 10,
//     },
//     buttonText: {
//         fontWeight: 'bold',
//     },
// });


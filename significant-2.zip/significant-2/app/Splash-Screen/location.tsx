import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ActivityIndicator, Alert } from 'react-native';
import * as Location from 'expo-location';
import { useRouter } from 'expo-router';
import { useLocationStore } from '../../stores/locationStore';

const LocationScreen = () => {
    const [isLoading, setIsLoading] = useState(true);
    const router = useRouter();
    const setGlobalLocation = useLocationStore(state => state.setLocation);

    useEffect(() => {
        (async () => {
            try {
                const { status } = await Location.requestForegroundPermissionsAsync();

                if (status !== 'granted') {
                    console.log('📍 Location permission denied. Proceeding without location.');
                    setGlobalLocation('Unknown Country', 'Unknown Region');
                    router.replace('../Splash-Screen/welcome');
                    return;
                }

                const loc = await Location.getCurrentPositionAsync({});
                const geo = await Location.reverseGeocodeAsync({
                    latitude: loc.coords.latitude,
                    longitude: loc.coords.longitude,
                });

                if (geo.length > 0) {
                    const country = geo[0].country ?? 'Unknown Country';
                    const region = geo[0].region ?? 'Unknown Region';
                    setGlobalLocation(country, region);
                } else {
                    setGlobalLocation('Unknown Country', 'Unknown Region');
                }

                router.replace('../Splash-Screen/welcome');
            } catch (error) {
                console.error('❌ Location error:', error);
                setGlobalLocation('Unknown Country', 'Unknown Region');
                router.replace('../Splash-Screen/welcome');
            } finally {
                setIsLoading(false);
            }
        })();
    }, []);

    return (
        <View style={styles.container}>
            <ActivityIndicator size="large" color="#f90" />
            <Text style={styles.text}>Just a moment...</Text>
        </View>
    );
};

export default LocationScreen;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#121212',
        justifyContent: 'center',
        alignItems: 'center',
    },
    text: {
        marginTop: 16,
        color: '#fff',
        fontSize: 16,
    },
});

import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image, ImageBackground } from 'react-native';
import { useRouter } from 'expo-router';

export default function WelcomeScreen() {
    const router = useRouter();

    const handleGetStarted = () => {
        router.push('../Sign-in/sign-in-main-page');
    };

    return (
        <ImageBackground
            source={require('../../assets/images/b-w-bg.webp')} // Replace with your background image
            style={styles.background}
            resizeMode="cover"
        >
            <View style={styles.overlay} />

            {/* Logo and Title Section */}
            <View style={styles.logoContainer}>
                <Image
                    source={require('../../assets/images/sg-logo.webp')} // Replace with your logo image
                    style={styles.logo}
                    resizeMode="contain"
                />
                <Text style={styles.logoText}>
                    Signif
                    <Text style={styles.highlightedText}>icant</Text>
                </Text>
            </View>

            {/* Welcome Section */}
            <View style={styles.textContainer}>
                <Text style={styles.title}>Welcome to Significant</Text>
                <Text style={styles.subtitle}>Empowering Creativity, Elevating Experiences</Text>
            </View>

            {/* Pagination and Button Section */}
            <View style={styles.paginationContainer}>
                <View style={styles.paginationDotActive} />
                <View style={styles.paginationDot} />
                <View style={styles.paginationDot} />
            </View>

            <TouchableOpacity style={styles.button} onPress={handleGetStarted}>
                <Text style={styles.buttonText}>Get Started</Text>
            </TouchableOpacity>
        </ImageBackground>
    );
}


const styles = StyleSheet.create({
    background: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    overlay: {
        ...StyleSheet.absoluteFillObject,
        backgroundColor: 'rgba(0, 0, 0, 0.6)', // Dark overlay for better text visibility
    },
    logoContainer: {
        alignItems: 'center',
         // Adjust to match the spacing
    },
    logo: {
        width: 170, // Adjust the size of the logo
        height: 170,
        marginBottom: 10,
    },
    logoText: {
        fontSize: 36,
        fontWeight: 'bold',
        color: '#fff',
    },
    highlightedText: {
        color: '#f90', // Orange color for "icant"
    },
    textContainer: {
        alignItems: 'center',
        marginTop: 40, // Spacing between logo and text
    },
    title: {
        fontSize: 24,
        fontWeight: 'bold',
        color: '#fff',
    },
    subtitle: {
        fontSize: 14,
        color: '#ccc',
        marginTop: 10,
        textAlign: 'center',
    },
    paginationContainer: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 30,
    },
    paginationDot: {
        width: 10,
        height: 10,
        backgroundColor: '#fff',
        borderRadius: 5,
        marginHorizontal: 5,
        opacity: 0.4,
    },
    paginationDotActive: {
        width: 10,
        height: 10,
        backgroundColor: '#f90', // Orange color for active dot
        borderRadius: 5,
        marginHorizontal: 5,
    },
    button: {
        backgroundColor: '#f90',
        paddingVertical: 15,
        paddingHorizontal: 60,
        borderRadius: 30,
        marginTop: 30,
    },
    buttonText: {
        fontSize: 16,
        color: '#fff',
        fontWeight: 'bold',
    },
});

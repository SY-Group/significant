import React, { useEffect } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    Image,
    ImageBackground,
    BackHandler,
    Platform,
} from 'react-native';
import { FontAwesome } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useOAuth, useAuth } from '@clerk/clerk-expo';
import * as WebBrowser from 'expo-web-browser';
import { InteractionManager } from 'react-native';

// Complete auth session handling for Clerk
WebBrowser.maybeCompleteAuthSession();

export default function LoginScreen() {
    const router = useRouter();
    const { signOut } = useAuth();

    const { startOAuthFlow: googleSignIn } = useOAuth({ strategy: 'oauth_google' });
    const { startOAuthFlow: facebookSignIn } = useOAuth({ strategy: 'oauth_facebook' });
    const { startOAuthFlow: appleSignIn } = useOAuth({ strategy: 'oauth_apple' });

    const handleGoogleLogin = async () => {
        try {
            if (!googleSignIn) return;

            const { createdSessionId, setActive } = await googleSignIn();

            await setActive?.({ session: createdSessionId });

            InteractionManager.runAfterInteractions(() => {
                setTimeout(() => {
                    router.replace('/(tabs)/IP/IP-1');
                }, 300);
            });
        } catch (err) {
            console.error('Google sign-in error:', err);
        }
    };

    const handleFacebookLogin = async () => {
        try {
            if (!facebookSignIn) return;

            const { createdSessionId, setActive } = await facebookSignIn();

            await setActive?.({ session: createdSessionId });

            InteractionManager.runAfterInteractions(() => {
                setTimeout(() => {
                    router.replace('/(tabs)/IP/IP-1');
                }, 300);
            });
        } catch (err) {
            console.error('Facebook sign-in error:', err);
        }
    };

    const handleAppleLogin = async () => {
        try {
            if (!appleSignIn) return;

            const { createdSessionId, setActive } = await appleSignIn();

            await setActive?.({ session: createdSessionId });

            InteractionManager.runAfterInteractions(() => {
                setTimeout(() => {
                    router.replace('/(tabs)/IP/IP-1');
                }, 300);
            });
        } catch (err) {
            console.error('Apple sign-in error:', err);
        }
    };

    const handleLogin = () => {
        router.push('/Sign-in/sign-in-email');
    };

    const handleRegister = () => {
        router.push('/Sign-in/register');
    };

    useEffect(() => {
        const autoLogout = async () => {
            try {
                await signOut();
            } catch (err) {
                console.warn('Sign-out failed or no session to clear:', err);
            }
        };
        autoLogout();

        if (Platform.OS === 'android') {
            const backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
                if (router.canGoBack && router.canGoBack()) {
                    router.back();
                } else {
                    BackHandler.exitApp();
                }
                return true;
            });

            return () => backHandler.remove();
        }
    }, []);

    return (
        <ImageBackground
            source={require('../../assets/images/b-w-bg.webp')}
            style={styles.background}
            resizeMode="cover"
        >
            <View style={styles.overlay} />

            <View style={styles.logoContainer}>
                <Image
                    source={require('../../assets/images/sg-logo.webp')}
                    style={styles.logo}
                    resizeMode="contain"
                />
                <Text style={styles.logoText}>
                    Signif<Text style={styles.highlightedText}>icant</Text>
                </Text>
            </View>

            <Text style={styles.title}>Welcome Back</Text>

            {/* Facebook Login */}
            <TouchableOpacity style={styles.socialButton} onPress={handleFacebookLogin}>
                <FontAwesome name="facebook" size={20} color="#fff" />
                <Text style={styles.socialButtonText}>Continue with Facebook</Text>
            </TouchableOpacity>

            {/* Google Login */}
            <TouchableOpacity style={styles.socialButton} onPress={handleGoogleLogin}>
                <FontAwesome name="google" size={20} color="#fff" />
                <Text style={styles.socialButtonText}>Continue with Google</Text>
            </TouchableOpacity>

            {/* Apple Login - iOS only */}
            {Platform.OS === 'ios' && (
                <TouchableOpacity style={styles.socialButton} onPress={handleAppleLogin}>
                    <FontAwesome name="apple" size={20} color="#fff" />
                    <Text style={styles.socialButtonText}>Continue with Apple ID</Text>
                </TouchableOpacity>
            )}

            {/* Divider */}
            <View style={styles.divider}>
                <Text style={styles.dividerText}>or</Text>
            </View>

            {/* Password Login */}
            <TouchableOpacity style={styles.passwordButton} onPress={handleLogin}>
                <Text style={styles.passwordButtonText}>Log in with password</Text>
            </TouchableOpacity>

            {/* Register */}
            <Text style={styles.footerText}>
                Don’t have an account?{' '}
                <Text style={styles.registerText} onPress={handleRegister}>
                    Register
                </Text>
            </Text>
        </ImageBackground>
    );
}

const styles = StyleSheet.create({
    background: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    overlay: {
        ...StyleSheet.absoluteFillObject,
        backgroundColor: 'rgba(0, 0, 0, 0.6)',
    },
    logoContainer: {
        alignItems: 'center',
        marginBottom: 10,
    },
    logo: {
        width: 170,
        height: 170,
        marginBottom: 10,
    },
    logoText: {
        fontSize: 36,
        fontWeight: 'bold',
        color: '#fff',
    },
    highlightedText: {
        color: '#f90',
    },
    title: {
        fontSize: 25,
        fontWeight: 'bold',
        color: '#fff',
        marginBottom: 30,
    },
    socialButton: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#333',
        paddingVertical: 15,
        paddingHorizontal: 20,
        borderRadius: 10,
        marginVertical: 10,
        width: '80%',
        justifyContent: 'center',
    },
    socialButtonText: {
        color: '#fff',
        fontSize: 16,
        fontWeight: 'bold',
        marginLeft: 10,
    },
    divider: {
        flexDirection: 'row',
        alignItems: 'center',
        marginVertical: 20,
    },
    dividerText: {
        color: '#aaa',
        fontSize: 16,
        textAlign: 'center',
    },
    passwordButton: {
        backgroundColor: '#f90',
        paddingVertical: 15,
        borderRadius: 30,
        width: '80%',
        alignItems: 'center',
        marginBottom: 20,
    },
    passwordButtonText: {
        color: '#fff',
        fontSize: 16,
        fontWeight: 'bold',
    },
    footerText: {
        color: '#fff',
        textAlign: 'center',
    },
    registerText: {
        color: '#f90',
        fontWeight: 'bold',
    },
});


















// import React, { useEffect } from 'react';
// import {
//     View,
//     Text,
//     StyleSheet,
//     TouchableOpacity,
//     Image,
//     ImageBackground,
//     BackHandler,
//     Platform,
// } from 'react-native';
// import { FontAwesome } from '@expo/vector-icons';
// import { useRouter } from 'expo-router';
// import { useOAuth, useAuth } from '@clerk/clerk-expo';
// import * as WebBrowser from 'expo-web-browser';
// import { InteractionManager } from 'react-native';
//
//
// // Clerk Auth session handling
// WebBrowser.maybeCompleteAuthSession();
//
// export default function LoginScreen() {
//     const router = useRouter();
//     const { signOut } = useAuth();
//
//     const { startOAuthFlow: googleSignIn } = useOAuth({ strategy: 'oauth_google' });
//     const { startOAuthFlow: facebookSignIn } = useOAuth({ strategy: 'oauth_facebook' });
//
//     // ✅ Your custom redirect URL
//     const redirectUrl = 'https://clerk.significantsports.in/v1/oauth_callback';
//
//     const handleGoogleLogin = async () => {
//         try {
//             if (!googleSignIn) return;
//
//             const { createdSessionId, setActive } = await googleSignIn({ redirectUrl });
//
//             await setActive?.({ session: createdSessionId });
//
//             InteractionManager.runAfterInteractions(() => {
//                 setTimeout(() => {
//                     router.replace('/(tabs)/IP/IP-1');
//                 }, 300);
//             });
//         } catch (err) {
//             console.error('Google sign-in error:', err);
//         }
//     };
//
//     const handleFacebookLogin = async () => {
//         try {
//             if (!facebookSignIn) return;
//
//             const { createdSessionId, setActive } = await facebookSignIn({ redirectUrl });
//
//             await setActive?.({ session: createdSessionId });
//
//             InteractionManager.runAfterInteractions(() => {
//                 setTimeout(() => {
//                     router.replace('/(tabs)/IP/IP-1');
//                 }, 300);
//             });
//         } catch (err) {
//             console.error('Facebook sign-in error:', err);
//         }
//     };
//
//     const handleLogin = () => {
//         router.push('/Sign-in/sign-in-email');
//     };
//
//     const handleRegister = () => {
//         router.push('/Sign-in/register');
//     };
//
//     useEffect(() => {
//         const autoLogout = async () => {
//             try {
//                 await signOut();
//             } catch (err) {
//                 console.warn('Sign-out failed or no session to clear:', err);
//             }
//         };
//         autoLogout();
//
//         if (Platform.OS === 'android') {
//             const backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
//                 if (router.canGoBack && router.canGoBack()) {
//                     router.back();
//                 } else {
//                     BackHandler.exitApp();
//                 }
//                 return true;
//             });
//
//             return () => backHandler.remove();
//         }
//     }, []);
//
//     return (
//         <ImageBackground
//             source={require('../../assets/images/b-w-bg.webp')}
//             style={styles.background}
//             resizeMode="cover"
//         >
//             <View style={styles.overlay} />
//
//             {/* Logo */}
//             <View style={styles.logoContainer}>
//                 <Image
//                     source={require('../../assets/images/sg-logo.webp')}
//                     style={styles.logo}
//                     resizeMode="contain"
//                 />
//                 <Text style={styles.logoText}>
//                     Signif<Text style={styles.highlightedText}>icant</Text>
//                 </Text>
//             </View>
//
//             {/* Title */}
//             <Text style={styles.title}>Welcome Back</Text>
//
//             {/* Facebook Login */}
//             <TouchableOpacity style={styles.socialButton} onPress={handleFacebookLogin}>
//                 <FontAwesome name="facebook" size={20} color="#fff" />
//                 <Text style={styles.socialButtonText}>Continue with Facebook</Text>
//             </TouchableOpacity>
//
//             {/* Google Login */}
//             <TouchableOpacity style={styles.socialButton} onPress={handleGoogleLogin}>
//                 <FontAwesome name="google" size={20} color="#fff" />
//                 <Text style={styles.socialButtonText}>Continue with Google</Text>
//             </TouchableOpacity>
//
//             {/* Divider */}
//             <View style={styles.divider}>
//                 <Text style={styles.dividerText}>or</Text>
//             </View>
//
//             {/* Password Login */}
//             <TouchableOpacity style={styles.passwordButton} onPress={handleLogin}>
//                 <Text style={styles.passwordButtonText}>Log in with password</Text>
//             </TouchableOpacity>
//
//             {/* Register */}
//             <Text style={styles.footerText}>
//                 Don’t have an account?{' '}
//                 <Text style={styles.registerText} onPress={handleRegister}>
//                     Register
//                 </Text>
//             </Text>
//         </ImageBackground>
//     );
// }
//
// const styles = StyleSheet.create({
//     background: {
//         flex: 1,
//         justifyContent: 'center',
//         alignItems: 'center',
//     },
//     overlay: {
//         ...StyleSheet.absoluteFillObject,
//         backgroundColor: 'rgba(0, 0, 0, 0.6)',
//     },
//     logoContainer: {
//         alignItems: 'center',
//         marginBottom: 10,
//     },
//     logo: {
//         width: 170,
//         height: 170,
//         marginBottom: 10,
//     },
//     logoText: {
//         fontSize: 36,
//         fontWeight: 'bold',
//         color: '#fff',
//     },
//     highlightedText: {
//         color: '#f90',
//     },
//     title: {
//         fontSize: 25,
//         fontWeight: 'bold',
//         color: '#fff',
//         marginBottom: 30,
//     },
//     socialButton: {
//         flexDirection: 'row',
//         alignItems: 'center',
//         backgroundColor: '#333',
//         paddingVertical: 15,
//         paddingHorizontal: 20,
//         borderRadius: 10,
//         marginVertical: 10,
//         width: '80%',
//         justifyContent: 'center',
//     },
//     socialButtonText: {
//         color: '#fff',
//         fontSize: 16,
//         fontWeight: 'bold',
//         marginLeft: 10,
//     },
//     divider: {
//         flexDirection: 'row',
//         alignItems: 'center',
//         marginVertical: 20,
//     },
//     dividerText: {
//         color: '#aaa',
//         fontSize: 16,
//         textAlign: 'center',
//     },
//     passwordButton: {
//         backgroundColor: '#f90',
//         paddingVertical: 15,
//         borderRadius: 30,
//         width: '80%',
//         alignItems: 'center',
//         marginBottom: 20,
//     },
//     passwordButtonText: {
//         color: '#fff',
//         fontSize: 16,
//         fontWeight: 'bold',
//     },
//     footerText: {
//         color: '#fff',
//         textAlign: 'center',
//     },
//     registerText: {
//         color: '#f90',
//         fontWeight: 'bold',
//     },
// });





// import React, { useEffect } from 'react';
// import {
//     View,
//     Text,
//     StyleSheet,
//     TouchableOpacity,
//     Image,
//     ImageBackground,
//     BackHandler,
//     Platform,
//     Alert,
// } from 'react-native';
// import { FontAwesome } from '@expo/vector-icons';
// import { useRouter } from 'expo-router';
// import { useOAuth, useAuth } from '@clerk/clerk-expo';
// import * as WebBrowser from 'expo-web-browser';
// import { InteractionManager } from 'react-native';
// import { registerForPushNotificationsAsync } from '../lib/notifications';
// import { Client, Databases, ID, Query } from 'appwrite';
//
// WebBrowser.maybeCompleteAuthSession();
//
// // 🔗 Appwrite setup
// const client = new Client()
//     .setEndpoint('https://fra.cloud.appwrite.io/v1') // ✅ your Appwrite endpoint
//     .setProject('67cdd84d0009a5120c76'); // ✅ your project ID
//
// const databases = new Databases(client);
//
// // 🔒 Save token to Appwrite DB
// async function saveExpoPushToken(email: string, token: string) {
//     try {
//         const result = await databases.listDocuments('67cdd942003adadc8498', 'users', [
//             Query.equal('email', email),
//         ]);
//
//         if (result.documents.length > 0) {
//             await databases.updateDocument('67cdd942003adadc8498', 'users', result.documents[0].$id, {
//                 expoPushToken: token,
//             });
//         } else {
//             await databases.createDocument('67cdd942003adadc8498', 'users', ID.unique(), {
//                 email,
//                 expoPushToken: token,
//             });
//         }
//     } catch (err) {
//         console.error('Appwrite token save error:', err);
//         Alert.alert('Error', 'Failed to save push token to Appwrite.');
//     }
// }
//
// export default function LoginScreen() {
//     const router = useRouter();
//     const { signOut, getToken } = useAuth();
//
//     const { startOAuthFlow: googleSignIn } = useOAuth({ strategy: 'oauth_google' });
//     const { startOAuthFlow: facebookSignIn } = useOAuth({ strategy: 'oauth_facebook' });
//
//     const handleGoogleLogin = async () => {
//         try {
//             if (!googleSignIn) return;
//
//             const { createdSessionId, setActive } = await googleSignIn();
//             await setActive?.({ session: createdSessionId });
//
//             const token = await registerForPushNotificationsAsync();
//
//             const clerkToken = await getToken();
//             const decoded: any = JSON.parse(atob(clerkToken?.split('.')[1] || '{}'));
//             const email = decoded?.email;
//
//             if (token && email) {
//                 await saveExpoPushToken(email, token);
//             }
//
//             InteractionManager.runAfterInteractions(() => {
//                 setTimeout(() => {
//                     router.replace('/IP/IP-1');
//                 }, 300);
//             });
//         } catch (err) {
//             console.error('Google sign-in error:', err);
//             Alert.alert('Login Error', 'Could not sign in with Google');
//         }
//     };
//
//     const handleFacebookLogin = async () => {
//         try {
//             if (!facebookSignIn) return;
//
//             const { createdSessionId, setActive } = await facebookSignIn();
//             await setActive?.({ session: createdSessionId });
//
//             const token = await registerForPushNotificationsAsync();
//
//             const clerkToken = await getToken({ template: 'integration_firebase' });
//             const decoded: any = JSON.parse(atob(clerkToken?.split('.')[1] || '{}'));
//             const email = decoded?.email;
//
//             if (token && email) {
//                 await saveExpoPushToken(email, token);
//             }
//
//             InteractionManager.runAfterInteractions(() => {
//                 setTimeout(() => {
//                     router.replace('/IP/IP-1');
//                 }, 300);
//             });
//         } catch (err) {
//             console.error('Facebook sign-in error:', err);
//             Alert.alert('Login Error', 'Could not sign in with Facebook');
//         }
//     };
//
//     const handleLogin = () => router.push('/Sign-in/sign-in-email');
//     const handleRegister = () => router.push('/Sign-in/register');
//
//     useEffect(() => {
//         const autoLogout = async () => {
//             try {
//                 await signOut();
//             } catch (err) {
//                 console.warn('Sign-out failed:', err);
//             }
//         };
//         autoLogout();
//
//         if (Platform.OS === 'android') {
//             const backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
//                 if (router.canGoBack && router.canGoBack()) {
//                     router.back();
//                 } else {
//                     BackHandler.exitApp();
//                 }
//                 return true;
//             });
//
//             return () => backHandler.remove();
//         }
//     }, []);
//
//     return (
//         <ImageBackground
//             source={require('../../assets/images/b-w-bg.webp')}
//             style={styles.background}
//             resizeMode="cover"
//         >
//             <View style={styles.overlay} />
//
//             <View style={styles.logoContainer}>
//                 <Image source={require('../../assets/images/sg-logo.webp')} style={styles.logo} resizeMode="contain" />
//                 <Text style={styles.logoText}>
//                     Signif<Text style={styles.highlightedText}>icant</Text>
//                 </Text>
//             </View>
//
//             <Text style={styles.title}>Welcome Back</Text>
//
//             <TouchableOpacity style={styles.socialButton} onPress={handleFacebookLogin}>
//                 <FontAwesome name="facebook" size={20} color="#fff" />
//                 <Text style={styles.socialButtonText}>Continue with Facebook</Text>
//             </TouchableOpacity>
//
//             <TouchableOpacity style={styles.socialButton} onPress={handleGoogleLogin}>
//                 <FontAwesome name="google" size={20} color="#fff" />
//                 <Text style={styles.socialButtonText}>Continue with Google</Text>
//             </TouchableOpacity>
//
//             <View style={styles.divider}>
//                 <Text style={styles.dividerText}>or</Text>
//             </View>
//
//             <TouchableOpacity style={styles.passwordButton} onPress={handleLogin}>
//                 <Text style={styles.passwordButtonText}>Log in with password</Text>
//             </TouchableOpacity>
//
//             <Text style={styles.footerText}>
//                 Don’t have an account?{' '}
//                 <Text style={styles.registerText} onPress={handleRegister}>
//                     Register
//                 </Text>
//             </Text>
//         </ImageBackground>
//     );
// }
//
// const styles = StyleSheet.create({
//     background: {
//         flex: 1,
//         justifyContent: 'center',
//         alignItems: 'center',
//     },
//     overlay: {
//         ...StyleSheet.absoluteFillObject,
//         backgroundColor: 'rgba(0, 0, 0, 0.6)',
//     },
//     logoContainer: {
//         alignItems: 'center',
//         marginBottom: 10,
//     },
//     logo: {
//         width: 170,
//         height: 170,
//         marginBottom: 10,
//     },
//     logoText: {
//         fontSize: 36,
//         fontWeight: 'bold',
//         color: '#fff',
//     },
//     highlightedText: {
//         color: '#f90',
//     },
//     title: {
//         fontSize: 25,
//         fontWeight: 'bold',
//         color: '#fff',
//         marginBottom: 30,
//     },
//     socialButton: {
//         flexDirection: 'row',
//         alignItems: 'center',
//         backgroundColor: '#333',
//         paddingVertical: 15,
//         paddingHorizontal: 20,
//         borderRadius: 10,
//         marginVertical: 10,
//         width: '80%',
//         justifyContent: 'center',
//     },
//     socialButtonText: {
//         color: '#fff',
//         fontSize: 16,
//         fontWeight: 'bold',
//         marginLeft: 10,
//     },
//     divider: {
//         flexDirection: 'row',
//         alignItems: 'center',
//         marginVertical: 20,
//     },
//     dividerText: {
//         color: '#aaa',
//         fontSize: 16,
//         textAlign: 'center',
//     },
//     passwordButton: {
//         backgroundColor: '#f90',
//         paddingVertical: 15,
//         borderRadius: 30,
//         width: '80%',
//         alignItems: 'center',
//         marginBottom: 20,
//     },
//     passwordButtonText: {
//         color: '#fff',
//         fontSize: 16,
//         fontWeight: 'bold',
//     },
//     footerText: {
//         color: '#fff',
//         textAlign: 'center',
//     },
//     registerText: {
//         color: '#f90',
//         fontWeight: 'bold',
//     },
// });




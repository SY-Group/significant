// import React, { useState } from 'react';
// import {
//     View,
//     Text,
//     StyleSheet,
//     TouchableOpacity,
//     TextInput,
//     Image,
//     ImageBackground,
//     Pressable,
//     Alert,
//     InteractionManager,
// } from 'react-native';
// import { FontAwesome, Feather } from '@expo/vector-icons';
// import { useRouter } from 'expo-router';
// import { useSignIn, useOAuth } from '@clerk/clerk-expo';
//
// export default function LoginScreen() {
//     const router = useRouter();
//     const { signIn, setActive, isLoaded } = useSignIn();
//
//     const { startOAuthFlow: googleSignIn } = useOAuth({ strategy: 'oauth_google' });
//     const { startOAuthFlow: facebookSignIn } = useOAuth({ strategy: 'oauth_facebook' });
//
//     const [email, setEmail] = useState('');
//     const [password, setPassword] = useState('');
//     const [showPassword, setShowPassword] = useState(false);
//     const [isChecked, setIsChecked] = useState(false);
//
//     const handleClerkSignIn = async () => {
//         if (!isLoaded) return;
//
//         try {
//             const result = await signIn.create({
//                 identifier: email,
//                 password,
//             });
//
//             await setActive({ session: result.createdSessionId });
//             Alert.alert('Success', 'Signed in successfully!');
//             router.push('/(tabs)/IP/IP-1');
//         } catch (err: any) {
//             console.log('Sign-in error:', err);
//             Alert.alert('Sign-in failed', err.errors?.[0]?.message || err.message);
//         }
//     };
//
//     const handleGoogleLogin = async () => {
//         try {
//             if (!googleSignIn) return;
//
//             const { createdSessionId, setActive } = await googleSignIn();
//             await setActive?.({ session: createdSessionId });
//
//             InteractionManager.runAfterInteractions(() => {
//                 setTimeout(() => {
//                     router.replace('/IP/IP-1');
//                 }, 300);
//             });
//         } catch (err) {
//             console.error('Google sign-in error:', err);
//             Alert.alert('Google sign-in failed', err.message);
//         }
//     };
//
//     const handleFacebookLogin = async () => {
//         try {
//             if (!facebookSignIn) return;
//
//             const { createdSessionId, setActive } = await facebookSignIn();
//             await setActive?.({ session: createdSessionId });
//             router.replace('/IP/IP-1');
//         } catch (err) {
//             console.error('Facebook sign-in error:', err);
//             Alert.alert('Facebook sign-in failed', err.message);
//         }
//     };
//
//     const handleRegister = () => router.push('../Sign-in/register');
//     const handlefogetpass = () => router.push('../forget-pass/Forget-Password');
//
//     return (
//         <ImageBackground
//             source={require('../../assets/images/b-w-bg.webp')}
//             style={styles.background}
//             resizeMode="cover"
//         >
//             <View style={styles.overlay} />
//
//             <View style={styles.logoContainer}>
//                 <Image
//                     source={require('../../assets/images/sg-logo.webp')}
//                     style={styles.logo}
//                     resizeMode="contain"
//                 />
//                 <Text style={styles.logoText}>
//                     Signif<Text style={styles.highlightedText}>icant</Text>
//                 </Text>
//             </View>
//
//             <Text style={styles.title}>Login to Your Account</Text>
//
//             {/* Email Input */}
//             <View style={styles.inputContainer}>
//                 <FontAwesome name="envelope" size={20} color="#fff" />
//                 <TextInput
//                     placeholder="Email"
//                     placeholderTextColor="#aaa"
//                     style={styles.input}
//                     autoCapitalize="none"
//                     keyboardType="email-address"
//                     value={email}
//                     onChangeText={setEmail}
//                 />
//             </View>
//
//             {/* Password Input */}
//             <View style={styles.inputContainer}>
//                 <Feather name="lock" size={20} color="#fff" />
//                 <TextInput
//                     placeholder="Password"
//                     placeholderTextColor="#aaa"
//                     style={styles.input}
//                     secureTextEntry={!showPassword}
//                     value={password}
//                     onChangeText={setPassword}
//                 />
//                 <Pressable onPress={() => setShowPassword(!showPassword)}>
//                     <Feather name={showPassword ? 'eye-off' : 'eye'} size={20} color="#aaa" />
//                 </Pressable>
//             </View>
//
//             {/* Options */}
//             <View style={styles.optionsContainer}>
//                 <View style={styles.rememberMeContainer}>
//                     <Pressable
//                         style={[styles.checkboxBase, isChecked && styles.checkboxChecked]}
//                         onPress={() => setIsChecked(!isChecked)}
//                     >
//                         {isChecked && <FontAwesome name="check" size={14} color="#fff" />}
//                     </Pressable>
//                     <Text style={styles.rememberMeText}>Remember me</Text>
//                 </View>
//                 <TouchableOpacity onPress={handlefogetpass}>
//                     <Text style={styles.forgotPasswordText}>Forgot password?</Text>
//                 </TouchableOpacity>
//             </View>
//
//             {/* Sign In */}
//             <TouchableOpacity style={styles.signInButton} onPress={handleClerkSignIn}>
//                 <Text style={styles.signInButtonText}>Sign in</Text>
//             </TouchableOpacity>
//
//             {/* Divider */}
//             <View style={styles.divider}>
//                 <Text style={styles.dividerText}>or continue with</Text>
//             </View>
//
//             {/* Social Logins */}
//             <View style={styles.socialContainer}>
//                 <TouchableOpacity style={styles.socialButton} onPress={handleFacebookLogin}>
//                     <FontAwesome name="facebook" size={24} color="#fff" />
//                 </TouchableOpacity>
//                 <TouchableOpacity style={styles.socialButton} onPress={handleGoogleLogin}>
//                     <FontAwesome name="google" size={24} color="#fff" />
//                 </TouchableOpacity>
//             </View>
//
//             <Text style={styles.footerText}>
//                 Don’t have an account?{' '}
//                 <Text style={styles.registerText} onPress={handleRegister}>
//                     Register
//                 </Text>
//             </Text>
//         </ImageBackground>
//     );
// }
//
// const styles = StyleSheet.create({
//     background: {
//         flex: 1,
//         justifyContent: 'center',
//         alignItems: 'center',
//     },
//     overlay: {
//         ...StyleSheet.absoluteFillObject,
//         backgroundColor: 'rgba(0, 0, 0, 0.6)',
//     },
//     logoContainer: {
//         alignItems: 'center',
//         marginTop: 0,
//         marginBottom: 10,
//     },
//     logo: {
//         width: 170,
//         height: 170,
//         marginBottom: 10,
//     },
//     logoText: {
//         fontSize: 36,
//         fontWeight: 'bold',
//         color: '#fff',
//     },
//     highlightedText: {
//         color: '#f90',
//     },
//     title: {
//         fontSize: 22,
//         fontWeight: 'bold',
//         color: '#fff',
//         marginBottom: 20,
//         textAlign: 'center',
//     },
//     inputContainer: {
//         flexDirection: 'row',
//         alignItems: 'center',
//         backgroundColor: 'rgba(255, 255, 255, 0.2)',
//         borderRadius: 10,
//         paddingHorizontal: 15,
//         marginVertical: 4,
//         width: '90%',
//         height: 50,
//     },
//     input: {
//         flex: 1,
//         color: '#fff',
//         paddingLeft: 10,
//         height: '100%',
//     },
//     optionsContainer: {
//         flexDirection: 'row',
//         justifyContent: 'space-between',
//         alignItems: 'center',
//         width: '90%',
//         marginVertical: 10,
//     },
//     rememberMeContainer: {
//         flexDirection: 'row',
//         alignItems: 'center',
//     },
//     checkboxBase: {
//         width: 20,
//         height: 20,
//         borderRadius: 3,
//         borderWidth: 1,
//         borderColor: '#aaa',
//         justifyContent: 'center',
//         alignItems: 'center',
//         marginRight: 8,
//     },
//     checkboxChecked: {
//         backgroundColor: '#f90',
//         borderColor: '#f90',
//     },
//     rememberMeText: {
//         color: '#aaa',
//     },
//     forgotPasswordText: {
//         color: '#f90',
//     },
//     signInButton: {
//         backgroundColor: '#f90',
//         paddingVertical: 15,
//         borderRadius: 30,
//         alignItems: 'center',
//         width: '90%',
//         marginVertical: 20,
//     },
//     signInButtonText: {
//         color: '#fff',
//         fontWeight: 'bold',
//         fontSize: 16,
//     },
//     divider: {
//         flexDirection: 'row',
//         alignItems: 'center',
//         marginVertical: 20,
//     },
//     dividerText: {
//         color: '#aaa',
//         textAlign: 'center',
//     },
//     socialContainer: {
//         flexDirection: 'row',
//         justifyContent: 'center',
//         marginVertical: 10,
//     },
//     socialButton: {
//         backgroundColor: '#333',
//         width: 60,
//         height: 60,
//         justifyContent: 'center',
//         alignItems: 'center',
//         borderRadius: 50,
//         marginHorizontal: 10,
//     },
//     footerText: {
//         color: '#fff',
//         textAlign: 'center',
//         marginTop: 20,
//     },
//     registerText: {
//         color: '#f90',
//         fontWeight: 'bold',
//     },
// });


// import React, { useState } from 'react';
// import {
//     View,
//     Text,
//     StyleSheet,
//     TouchableOpacity,
//     TextInput,
//     Image,
//     ImageBackground,
//     Pressable,
//     Alert,
//     InteractionManager,
// } from 'react-native';
// import { FontAwesome, Feather } from '@expo/vector-icons';
// import { useRouter } from 'expo-router';
// import { useOAuth } from '@clerk/clerk-expo';
// import { Client, Account } from 'appwrite';
// import { useUserStore } from '@/app/lib/stores/userStore';
//
// export default function LoginScreen() {
//     const router = useRouter();
//     const { startOAuthFlow: googleSignIn } = useOAuth({ strategy: 'oauth_google' });
//     const { startOAuthFlow: facebookSignIn } = useOAuth({ strategy: 'oauth_facebook' });
//
//     const [email, setEmail] = useState('');
//     const [password, setPassword] = useState('');
//     const [showPassword, setShowPassword] = useState(false);
//     const [isChecked, setIsChecked] = useState(false);
//
//     const setAppwriteUserId = useUserStore((state) => state.setAppwriteUserId);
//
//     const handleEmailPasswordSignIn = async () => {
//         try {
//             const client = new Client();
//             client
//                 .setEndpoint('https://fra.cloud.appwrite.io/v1') // your Appwrite endpoint
//                 .setProject('67b885c3001537c4d7cf'); // your Appwrite project ID
//
//             const account = new Account(client);
//
//             try {
//                 await account.deleteSession('current');
//             } catch {
//                 console.log('No active Appwrite session. Proceeding...');
//             }
//
//             await account.createEmailPasswordSession(email, password);
//             const userInfo = await account.get();
//             setAppwriteUserId(userInfo.$id);
//             console.log('Appwrite user ID:', userInfo.$id);
//
//             Alert.alert('Success', 'Signed in successfully!');
//             router.push('/(tabs)/IP/IP-1');
//         } catch (error: any) {
//             console.log('Appwrite sign-in error:', error);
//             Alert.alert('Sign-in failed', error.message);
//         }
//     };
//
//     const handleGoogleLogin = async () => {
//         try {
//             const { createdSessionId, setActive } = await googleSignIn();
//             await setActive?.({ session: createdSessionId });
//
//             InteractionManager.runAfterInteractions(() => {
//                 setTimeout(() => {
//                     router.replace('/IP/IP-1');
//                 }, 300);
//             });
//         } catch (err) {
//             console.error('Google sign-in error:', err);
//             Alert.alert('Google sign-in failed', err.message);
//         }
//     };
//
//     const handleFacebookLogin = async () => {
//         try {
//             const { createdSessionId, setActive } = await facebookSignIn();
//             await setActive?.({ session: createdSessionId });
//             router.replace('/IP/IP-1');
//         } catch (err) {
//             console.error('Facebook sign-in error:', err);
//             Alert.alert('Facebook sign-in failed', err.message);
//         }
//     };
//
//     const handleRegister = () => router.push('../Sign-in/register');
//     const handlefogetpass = () => router.push('../forget-pass/Forget-Password');
//
//     return (
//         <ImageBackground
//             source={require('../../assets/images/b-w-bg.webp')}
//             style={styles.background}
//             resizeMode="cover"
//         >
//             <View style={styles.overlay} />
//             <View style={styles.logoContainer}>
//                 <Image
//                     source={require('../../assets/images/sg-logo.webp')}
//                     style={styles.logo}
//                     resizeMode="contain"
//                 />
//                 <Text style={styles.logoText}>
//                     Signif<Text style={styles.highlightedText}>icant</Text>
//                 </Text>
//             </View>
//
//             <Text style={styles.title}>Login to Your Account</Text>
//
//             <View style={styles.inputContainer}>
//                 <FontAwesome name="envelope" size={20} color="#fff" />
//                 <TextInput
//                     placeholder="Email"
//                     placeholderTextColor="#aaa"
//                     style={styles.input}
//                     autoCapitalize="none"
//                     keyboardType="email-address"
//                     value={email}
//                     onChangeText={setEmail}
//                 />
//             </View>
//
//             <View style={styles.inputContainer}>
//                 <Feather name="lock" size={20} color="#fff" />
//                 <TextInput
//                     placeholder="Password"
//                     placeholderTextColor="#aaa"
//                     style={styles.input}
//                     secureTextEntry={!showPassword}
//                     value={password}
//                     onChangeText={setPassword}
//                 />
//                 <Pressable onPress={() => setShowPassword(!showPassword)}>
//                     <Feather name={showPassword ? 'eye-off' : 'eye'} size={20} color="#aaa" />
//                 </Pressable>
//             </View>
//
//             <View style={styles.optionsContainer}>
//                 <View style={styles.rememberMeContainer}>
//                     <Pressable
//                         style={[styles.checkboxBase, isChecked && styles.checkboxChecked]}
//                         onPress={() => setIsChecked(!isChecked)}
//                     >
//                         {isChecked && <FontAwesome name="check" size={14} color="#fff" />}
//                     </Pressable>
//                     <Text style={styles.rememberMeText}>Remember me</Text>
//                 </View>
//                 <TouchableOpacity onPress={handlefogetpass}>
//                     <Text style={styles.forgotPasswordText}>Forgot password?</Text>
//                 </TouchableOpacity>
//             </View>
//
//             <TouchableOpacity style={styles.signInButton} onPress={handleEmailPasswordSignIn}>
//                 <Text style={styles.signInButtonText}>Sign in</Text>
//             </TouchableOpacity>
//
//             <View style={styles.divider}>
//                 <Text style={styles.dividerText}>or continue with</Text>
//             </View>
//
//             <View style={styles.socialContainer}>
//                 <TouchableOpacity style={styles.socialButton} onPress={handleFacebookLogin}>
//                     <FontAwesome name="facebook" size={24} color="#fff" />
//                 </TouchableOpacity>
//                 <TouchableOpacity style={styles.socialButton} onPress={handleGoogleLogin}>
//                     <FontAwesome name="google" size={24} color="#fff" />
//                 </TouchableOpacity>
//             </View>
//
//             <Text style={styles.footerText}>
//                 Don’t have an account?{' '}
//                 <Text style={styles.registerText} onPress={handleRegister}>
//                     Register
//                 </Text>
//             </Text>
//         </ImageBackground>
//     );
// }
//
// const styles = StyleSheet.create({
//     background: {
//         flex: 1,
//         justifyContent: 'center',
//         alignItems: 'center',
//     },
//     overlay: {
//         ...StyleSheet.absoluteFillObject,
//         backgroundColor: 'rgba(0, 0, 0, 0.6)',
//     },
//     logoContainer: {
//         alignItems: 'center',
//         marginTop: 0,
//         marginBottom: 10,
//     },
//     logo: {
//         width: 170,
//         height: 170,
//         marginBottom: 10,
//     },
//     logoText: {
//         fontSize: 36,
//         fontWeight: 'bold',
//         color: '#fff',
//     },
//     highlightedText: {
//         color: '#f90',
//     },
//     title: {
//         fontSize: 22,
//         fontWeight: 'bold',
//         color: '#fff',
//         marginBottom: 20,
//         textAlign: 'center',
//     },
//     providerToggle: {
//         flexDirection: 'row',
//         marginBottom: 15,
//     },
//     providerButton: {
//         backgroundColor: 'rgba(255,255,255,0.2)',
//         paddingVertical: 8,
//         paddingHorizontal: 15,
//         borderRadius: 20,
//         marginHorizontal: 5,
//     },
//     providerButtonSelected: {
//         backgroundColor: '#f90',
//     },
//     providerButtonText: {
//         color: '#fff',
//         fontWeight: 'bold',
//     },
//     inputContainer: {
//         flexDirection: 'row',
//         alignItems: 'center',
//         backgroundColor: 'rgba(255, 255, 255, 0.2)',
//         borderRadius: 10,
//         paddingHorizontal: 15,
//         marginVertical: 4,
//         width: '90%',
//         height: 50,
//     },
//     input: {
//         flex: 1,
//         color: '#fff',
//         paddingLeft: 10,
//         height: '100%',
//     },
//     optionsContainer: {
//         flexDirection: 'row',
//         justifyContent: 'space-between',
//         alignItems: 'center',
//         width: '90%',
//         marginVertical: 10,
//     },
//     rememberMeContainer: {
//         flexDirection: 'row',
//         alignItems: 'center',
//     },
//     checkboxBase: {
//         width: 20,
//         height: 20,
//         borderRadius: 3,
//         borderWidth: 1,
//         borderColor: '#aaa',
//         justifyContent: 'center',
//         alignItems: 'center',
//         marginRight: 8,
//     },
//     checkboxChecked: {
//         backgroundColor: '#f90',
//         borderColor: '#f90',
//     },
//     rememberMeText: {
//         color: '#aaa',
//     },
//     forgotPasswordText: {
//         color: '#f90',
//     },
//     signInButton: {
//         backgroundColor: '#f90',
//         paddingVertical: 15,
//         borderRadius: 30,
//         alignItems: 'center',
//         width: '90%',
//         marginVertical: 20,
//     },
//     signInButtonText: {
//         color: '#fff',
//         fontWeight: 'bold',
//         fontSize: 16,
//     },
//     divider: {
//         flexDirection: 'row',
//         alignItems: 'center',
//         marginVertical: 20,
//     },
//     dividerText: {
//         color: '#aaa',
//         textAlign: 'center',
//     },
//     socialContainer: {
//         flexDirection: 'row',
//         justifyContent: 'center',
//         marginVertical: 10,
//     },
//     socialButton: {
//         backgroundColor: '#333',
//         width: 60,
//         height: 60,
//         justifyContent: 'center',
//         alignItems: 'center',
//         borderRadius: 50,
//         marginHorizontal: 10,
//     },
//     footerText: {
//         color: '#fff',
//         textAlign: 'center',
//         marginTop: 20,
//     },
//     registerText: {
//         color: '#f90',
//         fontWeight: 'bold',
//     },
// });



import React, { useState } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    TextInput,
    Image,
    ImageBackground,
    Pressable,
    Alert,
    InteractionManager,
    Platform,
} from 'react-native';
import { FontAwesome, Feather } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useOAuth } from '@clerk/clerk-expo';
import { Client, Account, Databases, Query } from 'appwrite';
import { useUserStore } from '@/app/lib/stores/userStore';

export default function LoginScreen() {
    const router = useRouter();

    const { startOAuthFlow: googleSignIn } = useOAuth({ strategy: 'oauth_google' });
    const { startOAuthFlow: facebookSignIn } = useOAuth({ strategy: 'oauth_facebook' });
    const { startOAuthFlow: appleSignIn } = useOAuth({ strategy: 'oauth_apple' }); // <-- Apple

    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [isChecked, setIsChecked] = useState(false);

    const setAppwriteUserId = useUserStore((state) => state.setAppwriteUserId);

    const handleEmailPasswordSignIn = async () => {
        try {
            const client = new Client()
                .setEndpoint('https://fra.cloud.appwrite.io/v1')
                .setProject('67b885c3001537c4d7cf');

            const account = new Account(client);
            const databases = new Databases(client);

            try {
                await account.deleteSession('current');
            } catch {
                console.log('No active Appwrite session. Proceeding...');
            }

            await account.createEmailPasswordSession(email, password);
            const userInfo = await account.get();
            const userId = userInfo.$id;

            const result = await databases.listDocuments(
                '67b890b100131eecc7d6',
                '686a4213001eece8341d',
                [Query.equal('user_id', [userId])]
            );

            if (result.total === 0) {
                await account.deleteSession('current');
                Alert.alert('Access Denied', 'You are not registered for this app.');
                return;
            }

            setAppwriteUserId(userId);
            console.log('Appwrite user ID:', userId);
            Alert.alert('Success', 'Signed in successfully!');
            router.push('/(tabs)/IP/IP-1');
        } catch (error: any) {
            console.log('Appwrite sign-in error:', error);
            Alert.alert('Sign-in failed', error.message);
        }
    };

    const handleGoogleLogin = async () => {
        try {
            const { createdSessionId, setActive } = await googleSignIn();
            await setActive?.({ session: createdSessionId });
            InteractionManager.runAfterInteractions(() => {
                setTimeout(() => {
                    router.replace('/(tabs)/IP/IP-1');
                }, 300);
            });
        } catch (err) {
            console.error('Google sign-in error:', err);
            Alert.alert('Google sign-in failed', err.message);
        }
    };

    const handleFacebookLogin = async () => {
        try {
            const { createdSessionId, setActive } = await facebookSignIn();
            await setActive?.({ session: createdSessionId });
            router.replace('/(tabs)/IP/IP-1');
        } catch (err) {
            console.error('Facebook sign-in error:', err);
            Alert.alert('Facebook sign-in failed', err.message);
        }
    };

    const handleAppleLogin = async () => {
        try {
            const { createdSessionId, setActive } = await appleSignIn();
            await setActive?.({ session: createdSessionId });
            InteractionManager.runAfterInteractions(() => {
                setTimeout(() => {
                    router.replace('/(tabs)/IP/IP-1');
                }, 300);
            });
        } catch (err) {
            console.error('Apple sign-in error:', err);
            Alert.alert('Apple sign-in failed', err.message);
        }
    };

    const handleRegister = () => router.push('../Sign-in/register');
    const handlefogetpass = () => router.push('../forget-pass/Forget-Password');

    return (
        <ImageBackground
            source={require('../../assets/images/b-w-bg.webp')}
            style={styles.background}
            resizeMode="cover"
        >
            <View style={styles.overlay} />

            <View style={styles.logoContainer}>
                <Image
                    source={require('../../assets/images/sg-logo.webp')}
                    style={styles.logo}
                    resizeMode="contain"
                />
                <Text style={styles.logoText}>
                    Signif<Text style={styles.highlightedText}>icant</Text>
                </Text>
            </View>

            <Text style={styles.title}>Login to Your Account</Text>

            <View style={styles.inputContainer}>
                <FontAwesome name="envelope" size={20} color="#fff" />
                <TextInput
                    placeholder="Email"
                    placeholderTextColor="#aaa"
                    style={styles.input}
                    autoCapitalize="none"
                    keyboardType="email-address"
                    value={email}
                    onChangeText={setEmail}
                />
            </View>

            <View style={styles.inputContainer}>
                <Feather name="lock" size={20} color="#fff" />
                <TextInput
                    placeholder="Password"
                    placeholderTextColor="#aaa"
                    style={styles.input}
                    secureTextEntry={!showPassword}
                    value={password}
                    onChangeText={setPassword}
                />
                <Pressable onPress={() => setShowPassword(!showPassword)}>
                    <Feather name={showPassword ? 'eye-off' : 'eye'} size={20} color="#aaa" />
                </Pressable>
            </View>

            <View style={styles.optionsContainer}>
                <View style={styles.rememberMeContainer}>
                    <Pressable
                        style={[styles.checkboxBase, isChecked && styles.checkboxChecked]}
                        onPress={() => setIsChecked(!isChecked)}
                    >
                        {isChecked && <FontAwesome name="check" size={14} color="#fff" />}
                    </Pressable>
                    <Text style={styles.rememberMeText}>Remember me</Text>
                </View>
                <TouchableOpacity onPress={handlefogetpass}>
                    <Text style={styles.forgotPasswordText}>Forgot password?</Text>
                </TouchableOpacity>
            </View>

            <TouchableOpacity style={styles.signInButton} onPress={handleEmailPasswordSignIn}>
                <Text style={styles.signInButtonText}>Sign in</Text>
            </TouchableOpacity>

            <View style={styles.divider}>
                <Text style={styles.dividerText}>or continue with</Text>
            </View>

            <View style={styles.socialContainer}>
                <TouchableOpacity style={styles.socialButton} onPress={handleFacebookLogin}>
                    <FontAwesome name="facebook" size={24} color="#fff" />
                </TouchableOpacity>

                <TouchableOpacity style={styles.socialButton} onPress={handleGoogleLogin}>
                    <FontAwesome name="google" size={24} color="#fff" />
                </TouchableOpacity>

                {/* Apple Login button - iOS only */}
                {Platform.OS === 'ios' && (
                    <TouchableOpacity style={styles.socialButton} onPress={handleAppleLogin}>
                        <FontAwesome name="apple" size={24} color="#fff" />
                    </TouchableOpacity>
                )}
            </View>

            <Text style={styles.footerText}>
                Don’t have an account?{' '}
                <Text style={styles.registerText} onPress={handleRegister}>
                    Register
                </Text>
            </Text>
        </ImageBackground>
    );
}

const styles = StyleSheet.create({
    background: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    overlay: {
        ...StyleSheet.absoluteFillObject,
        backgroundColor: 'rgba(0, 0, 0, 0.6)',
    },
    logoContainer: {
        alignItems: 'center',
        marginTop: 0,
        marginBottom: 10,
    },
    logo: {
        width: 170,
        height: 170,
        marginBottom: 10,
    },
    logoText: {
        fontSize: 36,
        fontWeight: 'bold',
        color: '#fff',
    },
    highlightedText: {
        color: '#f90',
    },
    title: {
        fontSize: 22,
        fontWeight: 'bold',
        color: '#fff',
        marginBottom: 20,
        textAlign: 'center',
    },
    inputContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: 'rgba(255, 255, 255, 0.2)',
        borderRadius: 10,
        paddingHorizontal: 15,
        marginVertical: 4,
        width: '90%',
        height: 50,
    },
    input: {
        flex: 1,
        color: '#fff',
        paddingLeft: 10,
        height: '100%',
    },
    optionsContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        width: '90%',
        marginVertical: 10,
    },
    rememberMeContainer: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    checkboxBase: {
        width: 20,
        height: 20,
        borderRadius: 3,
        borderWidth: 1,
        borderColor: '#aaa',
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: 8,
    },
    checkboxChecked: {
        backgroundColor: '#f90',
        borderColor: '#f90',
    },
    rememberMeText: {
        color: '#aaa',
    },
    forgotPasswordText: {
        color: '#f90',
    },
    signInButton: {
        backgroundColor: '#f90',
        paddingVertical: 15,
        borderRadius: 30,
        alignItems: 'center',
        width: '90%',
        marginVertical: 20,
    },
    signInButtonText: {
        color: '#fff',
        fontWeight: 'bold',
        fontSize: 16,
    },
    divider: {
        flexDirection: 'row',
        alignItems: 'center',
        marginVertical: 20,
    },
    dividerText: {
        color: '#aaa',
        textAlign: 'center',
    },
    socialContainer: {
        flexDirection: 'row',
        justifyContent: 'center',
        marginVertical: 10,
    },
    socialButton: {
        backgroundColor: '#333',
        width: 60,
        height: 60,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 50,
        marginHorizontal: 10,
    },
    footerText: {
        color: '#fff',
        textAlign: 'center',
        marginTop: 20,
    },
    registerText: {
        color: '#f90',
        fontWeight: 'bold',
    },
});





























// import React, { useState } from 'react';
// import {
//     View,
//     Text,
//     StyleSheet,
//     TouchableOpacity,
//     TextInput,
//     Image,
//     ImageBackground,
//     Pressable,
// } from 'react-native';
// import { FontAwesome, Feather } from '@expo/vector-icons';
// import { useRouter } from "expo-router";
//
// import { account, databases } from '../../utils/appwrite'; // ✅ Import Appwrite
//
// const DATABASE_ID = '67b890b100131eecc7d6';
// const COLLECTION_ID = '67cdd942003adadc8498';
//
// export default function LoginScreen() {
//     const router = useRouter();
//     const [email, setEmail] = useState('');
//     const [password, setPassword] = useState('');
//     const [isChecked, setIsChecked] = useState(false);
//
//     const handleRegister = () => {
//         router.push('../Sign-in/register');
//     };
//
//     const handlefogetpass = () => {
//         router.push('../forget-pass/Forget-Password');
//     };
//
//     const handleSignIn = async () => {
//         try {
//             const session = await account.createEmailSession(email, password);
//
//             const user = await account.get();
//
//             try {
//                 // Try fetching existing user document
//                 const response = await databases.getDocument(
//                     DATABASE_ID,
//                     COLLECTION_ID,
//                     user.$id
//                 );
//                 console.log('User data:', response);
//             } catch (error) {
//                 // If document doesn't exist, create it
//                 await databases.createDocument(
//                     DATABASE_ID,
//                     COLLECTION_ID,
//                     user.$id,
//                     {
//                         email: user.email,
//                         name: user.name || '',
//                         createdAt: new Date().toISOString(),
//                     }
//                 );
//                 console.log('New user document created');
//             }
//
//             router.push('../IP/IP-1');
//         } catch (error: any) {
//             console.error('Login failed:', error);
//             alert('Login failed: ' + (error?.message || 'Unknown error'));
//         }
//     };
//
//     return (
//         <ImageBackground
//             source={require('../../assets/images/b-w-bg.webp')}
//             style={styles.background}
//             resizeMode="cover"
//         >
//             <View style={styles.overlay} />
//
//             {/* Logo Section */}
//             <View style={styles.logoContainer}>
//                 <Image
//                     source={require('../../assets/images/sg-logo.webp')}
//                     style={styles.logo}
//                     resizeMode="contain"
//                 />
//                 <Text style={styles.logoText}>
//                     Signif
//                     <Text style={styles.highlightedText}>icant</Text>
//                 </Text>
//             </View>
//
//             {/* Title */}
//             <Text style={styles.title}>Login to Your Account</Text>
//
//             {/* Input Fields */}
//             <View style={styles.inputContainer}>
//                 <FontAwesome name="envelope" size={20} color="#fff" />
//                 <TextInput
//                     placeholder="Email"
//                     placeholderTextColor="#aaa"
//                     style={styles.input}
//                     value={email}
//                     onChangeText={setEmail}
//                 />
//             </View>
//             <View style={styles.inputContainer}>
//                 <Feather name="lock" size={20} color="#fff" />
//                 <TextInput
//                     placeholder="Password"
//                     placeholderTextColor="#aaa"
//                     style={styles.input}
//                     secureTextEntry
//                     value={password}
//                     onChangeText={setPassword}
//                 />
//                 <Feather name="eye" size={20} color="#aaa" />
//             </View>
//
//             {/* Remember Me and Forgot Password */}
//             <View style={styles.optionsContainer}>
//                 <View style={styles.rememberMeContainer}>
//                     <Pressable
//                         style={[styles.checkboxBase, isChecked && styles.checkboxChecked]}
//                         onPress={() => setIsChecked(!isChecked)}
//                     >
//                         {isChecked && <FontAwesome name="check" size={14} color="#fff" />}
//                     </Pressable>
//                     <Text style={styles.rememberMeText}>Remember me</Text>
//                 </View>
//                 <TouchableOpacity>
//                     <Text style={styles.forgotPasswordText} onPress={handlefogetpass}>Forgot password?</Text>
//                 </TouchableOpacity>
//             </View>
//
//             {/* Sign In Button */}
//             <TouchableOpacity style={styles.signInButton} onPress={handleSignIn}>
//                 <Text style={styles.signInButtonText}>Sign in</Text>
//             </TouchableOpacity>
//
//             {/* Divider */}
//             <View style={styles.divider}>
//                 <Text style={styles.dividerText}>or continue with</Text>
//             </View>
//
//             {/* Social Login Buttons */}
//             <View style={styles.socialContainer}>
//                 <TouchableOpacity style={styles.socialButton}>
//                     <FontAwesome name="facebook" size={24} color="#fff" />
//                 </TouchableOpacity>
//                 <TouchableOpacity style={styles.socialButton}>
//                     <FontAwesome name="google" size={24} color="#fff" />
//                 </TouchableOpacity>
//             </View>
//
//             {/* Footer */}
//             <Text style={styles.footerText}>
//                 Don’t have an account?{' '}
//                 <Text style={styles.registerText} onPress={handleRegister}>Register</Text>
//             </Text>
//         </ImageBackground>
//     );
// }
//
// const styles = StyleSheet.create({
//     background: {
//         flex: 1,
//         justifyContent: 'center',
//         alignItems: 'center',
//     },
//     overlay: {
//         ...StyleSheet.absoluteFillObject,
//         backgroundColor: 'rgba(0, 0, 0, 0.6)',
//     },
//     logoContainer: {
//         alignItems: 'center',
//         marginTop: 0,
//         marginBottom: 10,
//     },
//     logo: {
//         width: 170,
//         height: 170,
//         marginBottom: 10,
//     },
//     logoText: {
//         fontSize: 36,
//         fontWeight: 'bold',
//         color: '#fff',
//     },
//     highlightedText: {
//         color: '#f90',
//     },
//     title: {
//         fontSize: 22,
//         fontWeight: 'bold',
//         color: '#fff',
//         marginBottom: 20,
//         textAlign: 'center',
//     },
//     inputContainer: {
//         flexDirection: 'row',
//         alignItems: 'center',
//         backgroundColor: 'rgba(255, 255, 255, 0.2)',
//         borderRadius: 10,
//         paddingHorizontal: 15,
//         marginVertical: 4,
//         width: '90%',
//         height: 50,
//     },
//     input: {
//         flex: 1,
//         color: '#fff',
//         paddingLeft: 10,
//         height: '100%',
//     },
//     optionsContainer: {
//         flexDirection: 'row',
//         justifyContent: 'space-between',
//         alignItems: 'center',
//         width: '90%',
//         marginVertical: 10,
//     },
//     rememberMeContainer: {
//         flexDirection: 'row',
//         alignItems: 'center',
//     },
//     checkboxBase: {
//         width: 20,
//         height: 20,
//         borderRadius: 3,
//         borderWidth: 1,
//         borderColor: '#aaa',
//         justifyContent: 'center',
//         alignItems: 'center',
//         marginRight: 8,
//     },
//     checkboxChecked: {
//         backgroundColor: '#f90',
//         borderColor: '#f90',
//     },
//     rememberMeText: {
//         color: '#aaa',
//     },
//     forgotPasswordText: {
//         color: '#f90',
//     },
//     signInButton: {
//         backgroundColor: '#f90',
//         paddingVertical: 15,
//         borderRadius: 30,
//         alignItems: 'center',
//         width: '90%',
//         marginVertical: 20,
//     },
//     signInButtonText: {
//         color: '#fff',
//         fontWeight: 'bold',
//         fontSize: 16,
//     },
//     divider: {
//         flexDirection: 'row',
//         alignItems: 'center',
//         marginVertical: 20,
//     },
//     dividerText: {
//         color: '#aaa',
//         textAlign: 'center',
//     },
//     socialContainer: {
//         flexDirection: 'row',
//         justifyContent: 'center',
//         marginVertical: 10,
//     },
//     socialButton: {
//         backgroundColor: '#333',
//         width: 60,
//         height: 60,
//         justifyContent: 'center',
//         alignItems: 'center',
//         borderRadius: 50,
//         marginHorizontal: 10,
//     },
//     footerText: {
//         color: '#fff',
//         textAlign: 'center',
//         marginTop: 20,
//     },
//     registerText: {
//         color: '#f90',
//         fontWeight: 'bold',
//     },
// });

// import React from 'react';
// import {
//     View,
//     Text,
//     TextInput,
//     TouchableOpacity,
//     StyleSheet,
//     ImageBackground,
//     Image,
// } from 'react-native';
// import { FontAwesome, Feather } from '@expo/vector-icons';
// import {useRouter} from "expo-router";
//
// export default function RegisterScreen() {
//     const router = useRouter();
//
//     const handlehome = () => {
//         router.push('../IP/IP-1');
//     };
//
//     const handleLogin = () => {
//         router.push('../Sign-in/sign-in-email');
//     }
//     return (
//         <ImageBackground
//             source={require('../../assets/images/b-w-bg.webp')} // Replace with your background image
//             style={styles.background}
//             resizeMode="cover"
//         >
//             <View style={styles.overlay} />
//             <View style={styles.container}>
//                 {/* Logo Section */}
//                 <View style={styles.logoContainer}>
//                     <Image
//                         source={require('../../assets/images/sg-logo.webp')} // Replace with your logo image
//                         style={styles.logoImage}
//                         resizeMode="contain"
//                     />
//                     <Text style={styles.logoText}>
//                         Signif
//                         <Text style={styles.highlightedText}>icant</Text>
//                     </Text>
//                 </View>
//
//                 {/* Title */}
//                 <Text style={styles.title}>Register Your Account</Text>
//
//                 {/* Input Fields */}
//                 {[
//                     { placeholder: 'Your Name', icon: 'user' },
//                     { placeholder: 'Date of Birth', icon: 'calendar' },
//                     { placeholder: 'Email', icon: 'envelope' },
//                     { placeholder: 'Phone Number', icon: 'phone' },
//                     { placeholder: 'Password', icon: 'lock', secure: true },
//                     { placeholder: 'Confirm Password', icon: 'lock', secure: true },
//                 ].map((field, index) => (
//                     <View key={index} style={styles.inputContainer}>
//                         <FontAwesome name={field.icon} size={20} color="#fff" />
//                         <TextInput
//                             placeholder={field.placeholder}
//                             placeholderTextColor="#aaa"
//                             style={styles.input}
//                             secureTextEntry={field.secure || false}
//                         />
//                     </View>
//                 ))}
//
//                 {/* Sign Up Button */}
//                 <TouchableOpacity style={styles.signUpButton} onPress={handlehome}>
//                     <Text style={styles.signUpButtonText}>Sign Up</Text>
//                 </TouchableOpacity>
//
//                 {/* Social Media Section */}
//                 {/*<Text style={styles.orText}>or continue with</Text>*/}
//                 {/*<View style={styles.socialContainer}>*/}
//                 {/*    <TouchableOpacity style={styles.socialButton}>*/}
//                 {/*        <FontAwesome name="facebook" size={24} color="#fff" />*/}
//                 {/*    </TouchableOpacity>*/}
//                 {/*    <TouchableOpacity style={styles.socialButton}>*/}
//                 {/*        <FontAwesome name="google" size={24} color="#fff" />*/}
//                 {/*    </TouchableOpacity>*/}
//                 {/*</View>*/}
//
//                 {/* Footer */}
//                 <Text style={styles.footerText}>
//                     Already have an account?{' '}
//                     <Text style={styles.loginText} onPress={handleLogin}>Login</Text>
//                 </Text>
//             </View>
//         </ImageBackground>
//     );
// }
//
// const styles = StyleSheet.create({
//     background: {
//         flex: 1,
//         justifyContent: 'center',
//         alignItems: 'center',
//     },
//     overlay: {
//         ...StyleSheet.absoluteFillObject,
//         backgroundColor: 'rgba(0, 0, 0, 0.6)',
//     },
//     container: {
//         paddingVertical: 20,
//         width: '90%',
//         borderRadius: 15,
//     },
//     logoContainer: {
//         alignItems: 'center',
//         marginBottom: 10,
//         marginTop:20,
//          // Add space from the top
//     },
//     logoImage: {
//         width: 100,
//         height: 100,
//         marginBottom: 10,
//     },
//     logoText: {
//         fontSize: 36,
//         fontWeight: 'bold',
//         color: '#fff',
//     },
//     highlightedText: {
//         color: '#f90',
//     },
//     title: {
//         fontSize: 22,
//         fontWeight: 'bold',
//         color: '#fff',
//         textAlign: 'center',
//         marginBottom: 20,
//     },
//     inputContainer: {
//         flexDirection: 'row',
//         alignItems: 'center',
//         backgroundColor: 'rgba(255, 255, 255, 0.2)',
//         borderRadius: 10,
//         paddingHorizontal: 15,
//         marginVertical: 4,
//     },
//     input: {
//         flex: 1,
//         color: '#fff',
//         paddingLeft: 10,
//         height: 50,
//     },
//     signUpButton: {
//         backgroundColor: '#f90',
//         padding: 15,
//         borderRadius: 30,
//         alignItems: 'center',
//         marginVertical: 20,
//     },
//     signUpButtonText: {
//         color: '#fff',
//         fontWeight: 'bold',
//         fontSize: 16,
//     },
//     orText: {
//         color: '#aaa',
//         textAlign: 'center',
//         marginVertical: 10,
//     },
//     socialContainer: {
//         flexDirection: 'row',
//         justifyContent: 'center',
//         marginVertical: 5,
//     },
//     socialButton: {
//         backgroundColor: '#333',
//         width: 60,
//         height: 60,
//         justifyContent: 'center',
//         alignItems: 'center',
//         borderRadius: 50,
//         marginHorizontal: 10,
//     },
//     footerText: {
//         color: '#fff',
//         textAlign: 'center',
//         marginTop: 0,
//
//     },
//     loginText: {
//         color: '#f90',
//         fontWeight: 'bold',
//     },
// });



// import React, { useState } from 'react';
// import {
//     View, Text, TextInput, TouchableOpacity,
//     StyleSheet, ImageBackground, Image, Alert,
// } from 'react-native';
// import { FontAwesome } from '@expo/vector-icons';
// import { useRouter } from "expo-router";
// import { account, databases, ID } from '@/utils/appwrite-register-user'; // Adjust path to your appwrite config
//
// export default function RegisterScreen() {
//     const router = useRouter();
//
//     const [form, setForm] = useState({
//         name: '',
//         dob: '',
//         email: '',
//         phone: '',
//         password: '',
//         confirmPassword: '',
//     });
//
//     const handleInputChange = (key, value) => {
//         setForm({ ...form, [key]: value });
//     };
//
//     const handleSignUp = async () => {
//         const { name, dob, email, phone, password, confirmPassword } = form;
//
//         if (!name || !dob || !email || !phone || !password || !confirmPassword) {
//             Alert.alert("All fields are required");
//             return;
//         }
//
//         if (password !== confirmPassword) {
//             Alert.alert("Passwords do not match");
//             return;
//         }
//
//         try {
//             // 1. Create Appwrite Auth user
//             const user = await account.create(ID.unique(), email, password, name);
//
//             // 2. Store extra details in database
//             await databases.createDocument(
//                 '67b890b100131eecc7d6',          // Replace with your DB ID
//                 '686a4213001eece8341d',        // Replace with your Collection ID
//                 ID.unique(),
//                 {
//                     name,
//                     DOB: dob,
//                     email,
//                     phone,
//                     password,
//                     user_id: user.$id, // Optional: reference to auth user
//                 }
//             );
//
//             Alert.alert("Registration successful!");
//             router.push('../IP/IP-1');
//
//         } catch (error) {
//             console.error("Registration error:", error);
//             Alert.alert("Registration failed", error?.message || "Something went wrong");
//         }
//     };
//
//     const handleLogin = () => {
//         router.push('../Sign-in/sign-in-email');
//     };
//
//     return (
//         <ImageBackground
//             source={require('../../assets/images/b-w-bg.webp')}
//             style={styles.background}
//             resizeMode="cover"
//         >
//             <View style={styles.overlay} />
//             <View style={styles.container}>
//                 <View style={styles.logoContainer}>
//                     <Image
//                         source={require('../../assets/images/sg-logo.webp')}
//                         style={styles.logoImage}
//                         resizeMode="contain"
//                     />
//                     <Text style={styles.logoText}>
//                         Signif<Text style={styles.highlightedText}>icant</Text>
//                     </Text>
//                 </View>
//
//                 <Text style={styles.title}>Register Your Account</Text>
//
//                 {/* Input Fields */}
//                 {[
//                     { key: 'name', placeholder: 'Your Name', icon: 'user' },
//                     { key: 'dob', placeholder: 'Date of Birth', icon: 'calendar' },
//                     { key: 'email', placeholder: 'Email', icon: 'envelope' },
//                     { key: 'phone', placeholder: 'Phone Number', icon: 'phone' },
//                     { key: 'password', placeholder: 'Password', icon: 'lock', secure: true },
//                     { key: 'confirmPassword', placeholder: 'Confirm Password', icon: 'lock', secure: true },
//                 ].map((field, index) => (
//                     <View key={index} style={styles.inputContainer}>
//                         <FontAwesome name={field.icon} size={20} color="#fff" />
//                         <TextInput
//                             placeholder={field.placeholder}
//                             placeholderTextColor="#aaa"
//                             style={styles.input}
//                             secureTextEntry={field.secure || false}
//                             onChangeText={(value) => handleInputChange(field.key, value)}
//                             value={form[field.key]}
//                         />
//                     </View>
//                 ))}
//
//                 {/* Sign Up Button */}
//                 <TouchableOpacity style={styles.signUpButton} onPress={handleSignUp}>
//                     <Text style={styles.signUpButtonText}>Sign Up</Text>
//                 </TouchableOpacity>
//
//                 {/* Footer */}
//                 <Text style={styles.footerText}>
//                     Already have an account?{' '}
//                     <Text style={styles.loginText} onPress={handleLogin}>Login</Text>
//                 </Text>
//             </View>
//         </ImageBackground>
//     );
// }
//
// const styles = StyleSheet.create({
//     // (your existing styles)
//     background: {
//         flex: 1,
//         justifyContent: 'center',
//         alignItems: 'center',
//     },
//     overlay: {
//         ...StyleSheet.absoluteFillObject,
//         backgroundColor: 'rgba(0, 0, 0, 0.6)',
//     },
//     container: {
//         paddingVertical: 20,
//         width: '90%',
//         borderRadius: 15,
//     },
//     logoContainer: {
//         alignItems: 'center',
//         marginBottom: 10,
//         marginTop: 20,
//     },
//     logoImage: {
//         width: 100,
//         height: 100,
//         marginBottom: 10,
//     },
//     logoText: {
//         fontSize: 36,
//         fontWeight: 'bold',
//         color: '#fff',
//     },
//     highlightedText: {
//         color: '#f90',
//     },
//     title: {
//         fontSize: 22,
//         fontWeight: 'bold',
//         color: '#fff',
//         textAlign: 'center',
//         marginBottom: 20,
//     },
//     inputContainer: {
//         flexDirection: 'row',
//         alignItems: 'center',
//         backgroundColor: 'rgba(255, 255, 255, 0.2)',
//         borderRadius: 10,
//         paddingHorizontal: 15,
//         marginVertical: 4,
//     },
//     input: {
//         flex: 1,
//         color: '#fff',
//         paddingLeft: 10,
//         height: 50,
//     },
//     signUpButton: {
//         backgroundColor: '#f90',
//         padding: 15,
//         borderRadius: 30,
//         alignItems: 'center',
//         marginVertical: 20,
//     },
//     signUpButtonText: {
//         color: '#fff',
//         fontWeight: 'bold',
//         fontSize: 16,
//     },
//     footerText: {
//         color: '#fff',
//         textAlign: 'center',
//         marginTop: 0,
//     },
//     loginText: {
//         color: '#f90',
//         fontWeight: 'bold',
//     },
// });



import React, { useState } from 'react';
import {
    View, Text, TextInput, TouchableOpacity,
    StyleSheet, ImageBackground, Image, Alert,
    Platform, TouchableWithoutFeedback,
} from 'react-native';
import { FontAwesome } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import DateTimePicker from '@react-native-community/datetimepicker';
import { account, databases, ID } from '@/utils/appwrite-register-user';
import { useUserStore } from '@/app/lib/stores/userStore';

export default function RegisterScreen() {
    const router = useRouter();
    const { setAppwriteUserId } = useUserStore();

    const [form, setForm] = useState({
        name: '',
        dob: '',
        email: '',
        phone: '',
        password: '',
        confirmPassword: '',
    });

    const [showDatePicker, setShowDatePicker] = useState(false);

    const handleInputChange = (key: string, value: string) => {
        setForm({ ...form, [key]: value });
    };

    const handleDateChange = (event: any, selectedDate?: Date) => {
        setShowDatePicker(Platform.OS === 'ios');
        if (selectedDate) {
            const formattedDate = selectedDate.toISOString().split('T')[0];
            setForm({ ...form, dob: formattedDate });
        }
    };

    const handleSignUp = async () => {
        const { name, dob, email, phone, password, confirmPassword } = form;

        if (!name || !dob || !email || !phone || !password || !confirmPassword) {
            Alert.alert('All fields are required');
            return;
        }

        if (password !== confirmPassword) {
            Alert.alert('Passwords do not match');
            return;
        }

        try {
            const user = await account.create(ID.unique(), email, password, name);
            setAppwriteUserId(user.$id);

            await databases.createDocument(
                '67b890b100131eecc7d6', // your DB ID
                '686a4213001eece8341d', // your collection ID
                ID.unique(),
                {
                    name,
                    DOB: dob,
                    email,
                    phone,
                    password,
                    user_id: user.$id,
                }
            );

            Alert.alert('Registration successful!');
            router.push('../IP/IP-1');
        } catch (error: any) {
            console.error('Registration error:', error);
            Alert.alert('Registration failed', error?.message || 'Something went wrong');
        }
    };

    const handleLogin = () => {
        router.push('../Sign-in/sign-in-email');
    };

    return (
        <ImageBackground
            source={require('../../assets/images/b-w-bg.webp')}
            style={styles.background}
            resizeMode="cover"
        >
            <View style={styles.overlay} />
            <View style={styles.container}>
                <View style={styles.logoContainer}>
                    <Image
                        source={require('../../assets/images/sg-logo.webp')}
                        style={styles.logoImage}
                        resizeMode="contain"
                    />
                    <Text style={styles.logoText}>
                        Signif<Text style={styles.highlightedText}>icant</Text>
                    </Text>
                </View>

                <Text style={styles.title}>Register Your Account</Text>

                {/* Name */}
                <View style={styles.inputContainer}>
                    <FontAwesome name="user" size={20} color="#fff" />
                    <TextInput
                        placeholder="Your Name"
                        placeholderTextColor="#aaa"
                        style={styles.input}
                        onChangeText={(value) => handleInputChange('name', value)}
                        value={form.name}
                    />
                </View>

                {/* DOB */}
                <TouchableWithoutFeedback onPress={() => setShowDatePicker(true)}>
                    <View style={styles.inputContainer}>
                        <FontAwesome name="calendar" size={20} color="#fff" />
                        <Text style={[styles.input, {
                            paddingTop: Platform.OS === 'android' ? 16 : 16,
                            color: form.dob ? '#fff' : '#aaa'
                        }]}>
                            {form.dob || 'Date of Birth'}
                        </Text>
                    </View>
                </TouchableWithoutFeedback>
                {showDatePicker && (
                    <DateTimePicker
                        value={form.dob ? new Date(form.dob) : new Date()}
                        mode="date"
                        display="default"
                        maximumDate={new Date()}
                        onChange={handleDateChange}
                    />
                )}

                {/* Email */}
                <View style={styles.inputContainer}>
                    <FontAwesome name="envelope" size={20} color="#fff" />
                    <TextInput
                        placeholder="Email"
                        placeholderTextColor="#aaa"
                        style={styles.input}
                        keyboardType="email-address"
                        onChangeText={(value) => handleInputChange('email', value)}
                        value={form.email}
                    />
                </View>

                {/* Phone */}
                <View style={styles.inputContainer}>
                    <FontAwesome name="phone" size={20} color="#fff" />
                    <TextInput
                        placeholder="Phone Number"
                        placeholderTextColor="#aaa"
                        style={styles.input}
                        keyboardType="phone-pad"
                        onChangeText={(value) => handleInputChange('phone', value)}
                        value={form.phone}
                    />
                </View>

                {/* Password */}
                <View style={styles.inputContainer}>
                    <FontAwesome name="lock" size={20} color="#fff" />
                    <TextInput
                        placeholder="Password"
                        placeholderTextColor="#aaa"
                        style={styles.input}
                        secureTextEntry
                        onChangeText={(value) => handleInputChange('password', value)}
                        value={form.password}
                    />
                </View>

                {/* Confirm Password */}
                <View style={styles.inputContainer}>
                    <FontAwesome name="lock" size={20} color="#fff" />
                    <TextInput
                        placeholder="Confirm Password"
                        placeholderTextColor="#aaa"
                        style={styles.input}
                        secureTextEntry
                        onChangeText={(value) => handleInputChange('confirmPassword', value)}
                        value={form.confirmPassword}
                    />
                </View>

                <TouchableOpacity style={styles.signUpButton} onPress={handleSignUp}>
                    <Text style={styles.signUpButtonText}>Sign Up</Text>
                </TouchableOpacity>

                <Text style={styles.footerText}>
                    Already have an account? <Text style={styles.loginText} onPress={handleLogin}>Login</Text>
                </Text>
            </View>
        </ImageBackground>
    );
}

const styles = StyleSheet.create({
    background: { flex: 1, justifyContent: 'center', alignItems: 'center' },
    overlay: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0, 0, 0, 0.6)' },
    container: { paddingVertical: 20, width: '90%', borderRadius: 15 },
    logoContainer: { alignItems: 'center', marginBottom: 10 },
    logoImage: { width: 100, height: 100, marginBottom: 10 },
    logoText: { fontSize: 36, fontWeight: 'bold', color: '#fff' },
    highlightedText: { color: '#f90' },
    title: { fontSize: 22, fontWeight: 'bold', color: '#fff', textAlign: 'center', marginBottom: 20 },
    inputContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: 'rgba(255, 255, 255, 0.2)',
        borderRadius: 10,
        paddingHorizontal: 15,
        marginVertical: 4,
        height: 50,
    },
    input: {
        flex: 1,
        color: '#fff',
        paddingLeft: 10,
        height: 50,
    },
    signUpButton: {
        backgroundColor: '#f90',
        padding: 15,
        borderRadius: 30,
        alignItems: 'center',
        marginVertical: 20,
    },
    signUpButtonText: {
        color: '#fff',
        fontWeight: 'bold',
        fontSize: 16,
    },
    footerText: {
        color: '#fff',
        textAlign: 'center',
        marginTop: 0,
    },
    loginText: {
        color: '#f90',
        fontWeight: 'bold',
    },
});




// import React, { useState } from 'react';
// import {
//     View,
//     Text,
//     StyleSheet,
//     FlatList,
//     Image,
//     Pressable,
//     Animated,
// } from 'react-native';
// import { useRouter } from 'expo-router';
//
// // Card component
// const IPCard = ({ item }) => {
//     const router = useRouter();
//     const scaleAnim = useState(new Animated.Value(1))[0];
//
//     const handlePressIn = () => {
//         Animated.spring(scaleAnim, {
//             toValue: 0.96,
//             useNativeDriver: true,
//         }).start();
//     };
//
//     const handlePressOut = () => {
//         Animated.spring(scaleAnim, {
//             toValue: 1,
//             friction: 3,
//             tension: 40,
//             useNativeDriver: true,
//         }).start();
//     };
//
//     const handlePress = () => {
//         if (item.title === "T10–STCL") {
//             router.push('../(tabs)/App');
//         }
//     };
//
//     return (
//         <Pressable
//             onPressIn={handlePressIn}
//             onPressOut={handlePressOut}
//             onPress={handlePress}
//             android_ripple={{ color: '#444', borderless: false }}
//             style={{ borderRadius: 12, marginBottom: 20 }}
//         >
//             <Animated.View style={[styles.card, { transform: [{ scale: scaleAnim }] }]}>
//                 <Image source={item.image} style={styles.cardImage} />
//                 <View style={styles.cardContent}>
//                     <Text style={styles.cardTitle}>{item.title}</Text>
//                     <Text style={styles.cardDescription}>{item.description}</Text>
//                     <Text style={styles.cardTagline}>{item.tagline}</Text>
//                 </View>
//             </Animated.View>
//         </Pressable>
//     );
// };
//
// export default function IntellectualPropertiesScreen() {
//     const [activeTab, setActiveTab] = useState("Sports");
//     const router = useRouter();
//
//     const handleIP = () => {
//         router.push('../IP/IP-2');
//     };
//
//     const data = [
//         {
//             id: "1",
//             title: "T10–STCL",
//             description: "T10 Super Tennis Cricket League",
//             tagline: "Fast, Fierce, Unstoppable Cricket Action!",
//             image: require('../../assets/images/t10stcl-card.webp'),
//         },
//         {
//             id: "2",
//             title: "GL-60",
//             description: "Global Legends 60",
//             tagline: "Fast, Fierce, Unstoppable Cricket Action!",
//             image: require('../../assets/images/global-legends-card.webp'),
//         },
//         {
//             id: "3",
//             title: "Gaya Gladiators",
//             description: "Bihar Tennis Cricket League",
//             tagline: "Fast, Fierce, Unstoppable Cricket Action!",
//             image: require('../../assets/images/gaya-gladiators-card.webp'),
//         },
//     ];
//
//     return (
//         <View style={styles.container}>
//             <Text style={styles.title}>Intellectual Properties</Text>
//
//             {/* Tabs */}
//             <View style={styles.tabsContainer}>
//                 <Pressable
//                     style={[styles.tabButton, activeTab === "Sports" && styles.activeTab]}
//                     onPress={() => setActiveTab("Sports")}
//                 >
//                     <Text style={[styles.tabText, activeTab === "Sports" && styles.activeTabText]}>
//                         Sports
//                     </Text>
//                 </Pressable>
//                 <Pressable
//                     style={[styles.tabButton, activeTab === "Entertainment" && styles.activeTab]}
//                     onPress={handleIP}
//                 >
//                     <Text
//                         style={[
//                             styles.tabText,
//                             activeTab === "Entertainment" && styles.activeTabText,
//                         ]}
//                     >
//                         Entertainment
//                     </Text>
//                 </Pressable>
//             </View>
//
//             {/* List */}
//             <FlatList
//                 data={data}
//                 renderItem={({ item }) => <IPCard item={item} />}
//                 keyExtractor={(item) => item.id}
//                 contentContainerStyle={styles.listContainer}
//             />
//         </View>
//     );
// }
//
// const styles = StyleSheet.create({
//     container: {
//         flex: 1,
//         backgroundColor: '#121212',
//         paddingVertical:50,
//     },
//     title: {
//         fontSize: 20,
//         fontWeight: 'bold',
//         color: '#fff',
//         textAlign: 'center',
//         marginBottom:50,
//     },
//     tabsContainer: {
//         flexDirection: 'row',
//         justifyContent: 'center',
//         marginBottom: 20,
//     },
//     tabButton: {
//         paddingVertical: 15,
//         paddingHorizontal: 20,
//         borderRadius: 5,
//         width:'44%',
//         backgroundColor: '#1E1E1E',
//         marginHorizontal: 4,
//     },
//     activeTab: {
//         backgroundColor: '#333',
//     },
//     tabText: {
//         fontSize: 14,
//         alignSelf: 'center',
//         color: '#fff',
//     },
//     activeTabText: {
//         color: '#fff',
//         fontWeight: 'bold',
//     },
//     listContainer: {
//         paddingHorizontal: 20,
//         paddingBottom: 100,
//     },
//     card: {
//         flexDirection: 'row',
//         backgroundColor: '#2c2c2c',
//         borderRadius: 12,
//         padding: 20,
//         elevation: 3,
//         shadowColor: '#000',
//         shadowOffset: { width: 0, height: 2 },
//         shadowOpacity: 0.3,
//         shadowRadius: 4,
//     },
//     cardImage: {
//         width: 80,
//         height: 80,
//         borderRadius: 10,
//     },
//     cardContent: {
//         marginLeft: 20,
//     },
//     cardTitle: {
//         fontSize: 18,
//         fontWeight: 'bold',
//         color: '#fff',
//     },
//     cardDescription: {
//         fontSize: 15,
//         color: '#aaa',
//         marginTop: 5,
//         width: 200,
//     },
//     cardTagline: {
//         fontSize: 14,
//         color: '#f90',
//         marginTop: 5,
//         width: 200,
//     },
// });

import React, { useEffect, useRef, useState } from 'react';
import {
    View,
    Text,
    StyleSheet,
    FlatList,
    Image,
    Pressable,
    TouchableOpacity,
    Animated,
} from 'react-native';
import { useRouter } from 'expo-router';
import { useUser } from '@clerk/clerk-expo';
import { useUserContext } from '@/context/UserContext';

const IPCard = ({ item, onPress }) => {
    const scaleAnim = useRef(new Animated.Value(1)).current;
    const blinkAnim = useRef(new Animated.Value(1)).current;

    const handlePressIn = () => {
        Animated.spring(scaleAnim, {
            toValue: 0.96,
            useNativeDriver: true,
        }).start();
    };

    const handlePressOut = () => {
        Animated.spring(scaleAnim, {
            toValue: 1,
            friction: 3,
            tension: 40,
            useNativeDriver: true,
        }).start();
    };

    // Blinking animation for Register Now button
    useEffect(() => {
        Animated.loop(
            Animated.sequence([
                Animated.timing(blinkAnim, {
                    toValue: 0.3,
                    duration: 500,
                    useNativeDriver: true,
                }),
                Animated.timing(blinkAnim, {
                    toValue: 1,
                    duration: 500,
                    useNativeDriver: true,
                }),
            ])
        ).start();
    }, []);

    return (
        <Pressable
            onPressIn={handlePressIn}
            onPressOut={handlePressOut}
            onPress={onPress}
            android_ripple={{ color: '#444', borderless: false }}
            style={{ borderRadius: 12, marginBottom: 20 }}
        >
            <Animated.View style={[styles.card, { transform: [{ scale: scaleAnim }] }]}>
                <Text style={styles.cardTitle}>{item.title}</Text>
                <Image source={item.image} style={styles.cardImage} />

                <Animated.View style={[styles.registerButton, { opacity: blinkAnim }]}>
                    <Text style={styles.registerButtonText}>Register Now</Text>
                </Animated.View>
            </Animated.View>
        </Pressable>
    );
};

export default function IPUnifiedScreen() {
    const [activeTab, setActiveTab] = useState('Sports');
    const router = useRouter();
    const { user, isLoaded } = useUser();
    const { setEmail } = useUserContext();

    useEffect(() => {
        if (isLoaded && user?.primaryEmailAddress?.emailAddress) {
            setEmail(user.primaryEmailAddress.emailAddress);
        }
    }, [isLoaded, user]);

    const sportsData = [
        {
            id: '1',
            title: 'T10–STCL',
            description: 'T10 Super Tennis Cricket League',
            tagline: 'Fast, Fierce, Unstoppable Cricket Action!',
            image: require('@/assets/images/t10stcl-card.webp'),
        },
    ];

    const entertainmentData = [
        {
            id: '1',
            title: 'I am Dance',
            image: require('@/assets/images/i-am-dance-card.webp'),
        },
    ];

    const handleCardPress = (title: string) => {
        switch (title) {
            case 'T10–STCL':
                router.push('../../Register-t10stcl/register-t10stcl');
                break;
            case 'I am Dance':
                router.push('../../Register-IamDance/Register-IAD');
                break;
        }
    };

    return (
        <View style={styles.container}>
            <Text style={styles.title}>Intellectual Properties</Text>

            {/* Tabs */}
            <View style={styles.tabsContainer}>
                <Pressable
                    style={[styles.tabButton, activeTab === 'Sports' && styles.activeTab]}
                    onPress={() => setActiveTab('Sports')}
                >
                    <Text style={[styles.tabText, activeTab === 'Sports' && styles.activeTabText]}>
                        Sports
                    </Text>
                </Pressable>
                <Pressable
                    style={[styles.tabButton, activeTab === 'Entertainment' && styles.activeTab]}
                    onPress={() => setActiveTab('Entertainment')}
                >
                    <Text
                        style={[styles.tabText, activeTab === 'Entertainment' && styles.activeTabText]}
                    >
                        Entertainment
                    </Text>
                </Pressable>
            </View>

            {/* Card List */}
            <FlatList
                data={activeTab === 'Sports' ? sportsData : entertainmentData}
                renderItem={({ item }) => (
                    <IPCard item={item} onPress={() => handleCardPress(item.title)} />
                )}
                keyExtractor={(item) => item.id}
                contentContainerStyle={styles.listContainer}
            />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#121212',
        paddingVertical: 50,
    },
    title: {
        fontSize: 20,
        fontWeight: 'bold',
        color: '#fff',
        textAlign: 'center',
        marginBottom: 50,
    },
    tabsContainer: {
        flexDirection: 'row',
        justifyContent: 'center',
        marginBottom: 20,
    },
    tabButton: {
        paddingVertical: 15,
        paddingHorizontal: 20,
        borderRadius: 5,
        width: '44%',
        backgroundColor: '#1E1E1E',
        marginHorizontal: 4,
    },
    activeTab: {
        backgroundColor: '#333',
    },
    tabText: {
        fontSize: 14,
        alignSelf: 'center',
        color: '#fff',
    },
    activeTabText: {
        color: '#fff',
        fontWeight: 'bold',
    },
    listContainer: {
        paddingHorizontal: 20,
        paddingBottom: 100,
    },
    card: {
        backgroundColor: '#2c2c2c',
        borderRadius: 12,
        padding: 20,
        elevation: 3,
        alignItems: 'center',
        height: 600,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.3,
        shadowRadius: 4,
    },
    cardImage: {
        width: 310,
        height: 350,
        borderRadius: 10,
    },
    cardTitle: {
        fontSize: 30,
        marginBottom: 20,
        marginTop: 20,
        fontWeight: 'bold',
        color: '#fff',
    },
    registerButton: {
        backgroundColor: '#F5A623',
        width: '100%',
        paddingVertical: 20,
        marginTop: 40,
        paddingHorizontal: 30,
        borderRadius: 8,
    },
    registerButtonText: {
        color: '#121212',
        alignSelf: 'center',
        fontWeight: 'bold',
        fontSize: 20,
    },
});




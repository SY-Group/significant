// import React from "react";
// import {
//     View,
//     Text,
//     StyleSheet,
//     TouchableOpacity,
//     Image,
// } from "react-native";
// import { FontAwesome, Feather } from "@expo/vector-icons";
// import { useRouter } from "expo-router";
//
// export default function MyAccountScreen() {
//     const menuItems = [
//         { id: 1, title: "Profile", icon: "user" },
//         { id: 2, title: "Password", icon: "lock" },
//         // { id: 3, title: "My Cards", icon: "credit-card" },
//         { id: 3, title: "Language", icon: "globe" },
//         { id: 4, title: "Invite Friends", icon: "users" },
//         // { id: 6, title: "Help", icon: "info-circle" },
//         // { id: 7, title: "Setting", icon: "cog" },
//     ];
//
//     const router = useRouter();
//
//     const handleprofile = () => {
//         router.push('../profile/Profile');
//     };
//
//     const handlepass = () => {
//         router.push('../forget-pass/Pass-filled');
//     };
//
//     return (
//         <View style={styles.container}>
//             {/* Header */}
//             <View style={styles.header}>
//                 <TouchableOpacity>
//                     <FontAwesome name="arrow-left" size={20} color="#fff" />
//                 </TouchableOpacity>
//                 <Text style={styles.headerTitle}>My Account</Text>
//             </View>
//
//             {/* Profile Picture */}
//             <View style={styles.profileContainer}>
//                 <View style={styles.profileCircle}>
//                     <TouchableOpacity style={styles.cameraButton}>
//                         <FontAwesome name="camera" size={14} color="#fff" />
//                     </TouchableOpacity>
//                 </View>
//             </View>
//
//             {/* Menu Items */}
//             <View style={styles.menuContainer}>
//                 {menuItems.map((item) => {
//                     let onPressHandler;
//                     if (item.title === "Profile") {
//                         onPressHandler = handleprofile;
//                     } else if (item.title === "Password") {
//                         onPressHandler = handlepass;
//                     }
//
//                     return (
//                         <TouchableOpacity
//                             key={item.id}
//                             style={styles.menuItem}
//                             onPress={onPressHandler}
//                         >
//                             <View style={styles.menuItemContent}>
//                                 <FontAwesome name={item.icon} size={18} color="#fff" />
//                                 <Text style={styles.menuItemText}>{item.title}</Text>
//                             </View>
//                             <Feather name="chevron-right" size={20} color="#fff" />
//                         </TouchableOpacity>
//                     );
//                 })}
//             </View>
//
//             {/* Logout Button */}
//             <TouchableOpacity style={styles.logoutButton}>
//                 <Text style={styles.logoutButtonText}>Log out</Text>
//                 <Feather name="log-out" size={18} color="#fff" />
//             </TouchableOpacity>
//         </View>
//     );
// }
//
// const styles = StyleSheet.create({
//     container: {
//         flex: 1,
//         backgroundColor: "#121212",
//         paddingHorizontal: 20,
//         paddingTop: 40,
//     },
//     header: {
//         flexDirection: "row",
//         alignItems: "center",
//         marginBottom: 20,
//     },
//     headerTitle: {
//         fontSize: 20,
//         fontWeight: "bold",
//         color: "#fff",
//         marginLeft: 10,
//     },
//     profileContainer: {
//         alignItems: "center",
//         marginVertical: 20,
//     },
//     profileCircle: {
//         width: 80,
//         height: 80,
//         borderRadius: 40,
//         borderWidth: 1,
//         borderColor: "#fff",
//         justifyContent: "center",
//         alignItems: "center",
//     },
//     cameraButton: {
//         position: "absolute",
//         bottom: 0,
//         right: -10,
//         backgroundColor: "#f90",
//         borderRadius: 20,
//         padding: 5,
//     },
//     menuContainer: {
//         marginTop: 20,
//     },
//     menuItem: {
//         flexDirection: "row",
//         justifyContent: "space-between",
//         alignItems: "center",
//         backgroundColor: "#2c2c2c",
//         borderRadius: 12,
//         paddingVertical: 15,
//         paddingHorizontal: 20,
//         marginBottom: 15,
//     },
//     menuItemContent: {
//         flexDirection: "row",
//         alignItems: "center",
//     },
//     menuItemText: {
//         fontSize: 16,
//         color: "#fff",
//         marginLeft: 15,
//     },
//     logoutButton: {
//         flexDirection: "row",
//         alignItems: "center",
//         justifyContent: "center",
//         backgroundColor: "#f90",
//         paddingVertical: 15,
//         borderRadius: 30,
//         marginTop: 30,
//     },
//     logoutButtonText: {
//         fontSize: 16,
//         color: "#fff",
//         fontWeight: "bold",
//         marginRight: 10,
//     },
// });


// import React from "react";
// import {
//     View,
//     Text,
//     StyleSheet,
//     TouchableOpacity,
//     Image,
// } from "react-native";
// import { FontAwesome, Feather } from "@expo/vector-icons";
// import { useRouter } from "expo-router";
// import { useAuth } from "@clerk/clerk-expo";
// import {useUserContext} from "@/context/UserContext";
//
// export default function MyAccountScreen() {
//     const router = useRouter();
//     const { signOut } = useAuth();
//     const { profileImage } = useUserContext();
//
//     const menuItems = [
//         { id: 1, title: "Profile", icon: "user" },
//         { id: 2, title: "Password", icon: "lock" },
//         { id: 3, title: "Language", icon: "globe" },
//         // { id: 4, title: "Invite Friends", icon: "users" },
//     ];
//
//     const handleprofile = () => {
//         router.push("../profile/Profile");
//     };
//
//     const handlepass = () => {
//         router.push("../forget-pass/Pass-filled");
//     };
//
//     const handleLogout = async () => {
//         try {
//             await signOut();
//             router.replace("../Sign-in/sign-in-email"); // Update this path if your welcome screen route is different
//         } catch (error) {
//             console.error("Logout failed:", error);
//         }
//     };
//
//     return (
//         <View style={styles.container}>
//             {/* Header */}
//             <View style={styles.header}>
//                 <TouchableOpacity onPress={() => router.back()} >
//                     <FontAwesome name="arrow-left" size={20} color="#fff" />
//                 </TouchableOpacity>
//                 <Text style={styles.headerTitle}>My Account</Text>
//             </View>
//
//             {/* Profile Picture */}
//             <View style={styles.profileContainer}>
//                 <View style={styles.profileCircle}>
//                     {/*<TouchableOpacity style={styles.cameraButton}>*/}
//                     {/*    <FontAwesome name="camera" size={14} color="#fff" />*/}
//                     {/*</TouchableOpacity>*/}
//                     {profileImage ? (
//                         <Image source={{ uri: profileImage }} style={{ width: 100, height: 100, borderRadius: 50 }} />
//                     ) : (
//                         <FontAwesome name="camera" size={50} color="#777"/>
//                     )}
//                 </View>
//             </View>
//
//             {/* Menu Items */}
//             <View style={styles.menuContainer}>
//                 {menuItems.map((item) => {
//                     let onPressHandler;
//                     if (item.title === "Profile") {
//                         onPressHandler = handleprofile;
//                     } else if (item.title === "Password") {
//                         onPressHandler = handlepass;
//                     }
//
//                     return (
//                         <TouchableOpacity
//                             key={item.id}
//                             style={styles.menuItem}
//                             onPress={onPressHandler}
//                         >
//                             <View style={styles.menuItemContent}>
//                                 <FontAwesome name ={item.icon} size={18} color="#fff" />
//                                 <Text style={styles.menuItemText}>{item.title}</Text>
//                             </View>
//                             <Feather name="chevron-right" size={20} color="#fff" />
//                         </TouchableOpacity>
//                     );
//                 })}
//             </View>
//
//             {/* Logout Button */}
//             <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
//                 <Text style={styles.logoutButtonText}>Log out</Text>
//                 <Feather name="log-out" size={18} color="#fff" />
//             </TouchableOpacity>
//         </View>
//     );
// }
//
// const styles = StyleSheet.create({
//     container: {
//         flex: 1,
//         backgroundColor: "#121212",
//         paddingHorizontal: 20,
//         paddingTop: 40,
//     },
//     header: {
//         flexDirection: "row",
//         alignItems: "center",
//         marginBottom: 20,
//     },
//     headerTitle: {
//         fontSize: 20,
//         fontWeight: "bold",
//         color: "#fff",
//         marginLeft: 10,
//     },
//     profileContainer: {
//         alignItems: "center",
//         marginVertical: 20,
//     },
//     profileCircle: {
//         width: 80,
//         height: 80,
//         borderRadius: 40,
//         borderWidth: 1,
//         borderColor: "#fff",
//         justifyContent: "center",
//         alignItems: "center",
//     },
//     cameraButton: {
//         position: "absolute",
//         bottom: 0,
//         right: -10,
//         backgroundColor: "#f90",
//         borderRadius: 20,
//         padding: 5,
//     },
//     menuContainer: {
//         marginTop: 20,
//     },
//     menuItem: {
//         flexDirection: "row",
//         justifyContent: "space-between",
//         alignItems: "center",
//         backgroundColor: "#2c2c2c",
//         borderRadius: 12,
//         paddingVertical: 15,
//         paddingHorizontal: 20,
//         marginBottom: 15,
//     },
//     menuItemContent: {
//         flexDirection: "row",
//         alignItems: "center",
//     },
//     menuItemText: {
//         fontSize: 16,
//         color: "#fff",
//         marginLeft: 15,
//     },
//     logoutButton: {
//         flexDirection: "row",
//         alignItems: "center",
//         justifyContent: "center",
//         backgroundColor: "#f90",
//         paddingVertical: 15,
//         borderRadius: 30,
//         marginTop: 30,
//     },
//     logoutButtonText: {
//         fontSize: 16,
//         color: "#fff",
//         fontWeight: "bold",
//         marginRight: 10,
//     },
// });


import React from "react";
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    Image,
    Alert,
} from "react-native";
import { FontAwesome, Feather } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { useAuth } from "@clerk/clerk-expo";
import { useUserContext } from "@/context/UserContext";
import { Client, Databases, Query } from "appwrite";
import { useUserStore } from "@/app/lib/stores/userStore"; // ✅ Zustand store

export default function MyAccountScreen() {
    const router = useRouter();
    const { signOut } = useAuth();
    const { profileImage } = useUserContext();

    const { appwriteUserId } = useUserStore(); // ✅ Zustand value

    const menuItems = [
        { id: 1, title: "Profile", icon: "user" },
        { id: 2, title: "Password", icon: "lock" },
        { id: 3, title: "Language", icon: "globe" },
    ];

    const handleprofile = () => router.push("../profile/Profile");
    const handlepass = () => router.push("../forget-pass/Pass-filled");

    const handleLogout = async () => {
        try {
            await signOut();
            router.replace("../Sign-in/sign-in-email");
        } catch (error) {
            console.error("Logout failed:", error);
        }
    };

    const handleDeleteAccount = async () => {
        Alert.alert(
            "Delete Account",
            "Are you sure you want to delete your account? This action cannot be undone.",
            [
                { text: "Cancel", style: "cancel" },
                {
                    text: "Delete",
                    style: "destructive",
                    onPress: async () => {
                        try {
                            console.log("Appwrite User ID from Zustand:", appwriteUserId);

                            if (!appwriteUserId) {
                                Alert.alert("Error", "Appwrite user ID not found.");
                                return;
                            }

                            const client = new Client()
                                .setEndpoint("https://fra.cloud.appwrite.io/v1") // ✅ Replace if needed
                                .setProject("67b885c3001537c4d7cf"); // ✅ Replace if needed

                            const databases = new Databases(client);

                            const response = await databases.listDocuments(
                                "67b890b100131eecc7d6", // ✅ DB ID
                                "686a4213001eece8341d", // ✅ Collection ID
                                [Query.equal("user_id", [appwriteUserId])]
                            );

                            if (response.total > 0) {
                                const docId = response.documents[0].$id;

                                await databases.deleteDocument(
                                    "67b890b100131eecc7d6",
                                    "686a4213001eece8341d",
                                    docId
                                );

                                await signOut();
                                router.replace("../Sign-in/sign-in-email");
                            } else {
                                Alert.alert("Error", "User record not found.");
                            }
                        } catch (error) {
                            console.error("Account deletion failed:", error);
                            Alert.alert("Error", "Failed to delete account.");
                        }
                    },
                },
            ]
        );
    };

    return (
        <View style={styles.container}>
            <View style={styles.header}>
                <TouchableOpacity onPress={() => router.back()}>
                    <FontAwesome name="arrow-left" size={20} color="#fff" />
                </TouchableOpacity>
                <Text style={styles.headerTitle}>My Account</Text>
            </View>

            <View style={styles.profileContainer}>
                <View style={styles.profileCircle}>
                    {profileImage ? (
                        <Image
                            source={{ uri: profileImage }}
                            style={{ width: 100, height: 100, borderRadius: 50 }}
                        />
                    ) : (
                        <FontAwesome name="camera" size={50} color="#777" />
                    )}
                </View>
            </View>

            <View style={styles.menuContainer}>
                {menuItems.map((item) => {
                    let onPressHandler;
                    if (item.title === "Profile") onPressHandler = handleprofile;
                    else if (item.title === "Password") onPressHandler = handlepass;

                    return (
                        <TouchableOpacity
                            key={item.id}
                            style={styles.menuItem}
                            onPress={onPressHandler}
                        >
                            <View style={styles.menuItemContent}>
                                <FontAwesome name={item.icon} size={18} color="#fff" />
                                <Text style={styles.menuItemText}>{item.title}</Text>
                            </View>
                            <Feather name="chevron-right" size={20} color="#fff" />
                        </TouchableOpacity>
                    );
                })}
            </View>

            <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
                <Text style={styles.logoutButtonText}>Log out</Text>
                <Feather name="log-out" size={18} color="#fff" />
            </TouchableOpacity>

            <TouchableOpacity style={styles.deleteButton} onPress={handleDeleteAccount}>
                <Text style={styles.deleteButtonText}>Delete Account</Text>
                <Feather name="trash-2" size={18} color="#fff" />
            </TouchableOpacity>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#121212",
        paddingHorizontal: 20,
        paddingTop: 40,
    },
    header: {
        flexDirection: "row",
        alignItems: "center",
        marginBottom: 20,
    },
    headerTitle: {
        fontSize: 20,
        fontWeight: "bold",
        color: "#fff",
        marginLeft: 10,
    },
    profileContainer: {
        alignItems: "center",
        marginVertical: 20,
    },
    profileCircle: {
        width: 80,
        height: 80,
        borderRadius: 40,
        borderWidth: 1,
        borderColor: "#fff",
        justifyContent: "center",
        alignItems: "center",
    },
    menuContainer: {
        marginTop: 20,
    },
    menuItem: {
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        backgroundColor: "#2c2c2c",
        borderRadius: 12,
        paddingVertical: 15,
        paddingHorizontal: 20,
        marginBottom: 15,
    },
    menuItemContent: {
        flexDirection: "row",
        alignItems: "center",
    },
    menuItemText: {
        fontSize: 16,
        color: "#fff",
        marginLeft: 15,
    },
    logoutButton: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: "#f90",
        paddingVertical: 15,
        borderRadius: 30,
        marginTop: 30,
    },
    logoutButtonText: {
        fontSize: 16,
        color: "#fff",
        fontWeight: "bold",
        marginRight: 10,
    },
    deleteButton: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: "#cc0000",
        paddingVertical: 15,
        borderRadius: 30,
        marginTop: 15,
    },
    deleteButtonText: {
        fontSize: 16,
        color: "#fff",
        fontWeight: "bold",
        marginRight: 10,
    },
});



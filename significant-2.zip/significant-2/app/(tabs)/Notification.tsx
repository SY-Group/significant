// import React from 'react';
// import {
//     View,
//     Text,
//     StyleSheet,
//     TouchableOpacity,
//     FlatList,
//     Image,
//     SafeAreaView,
//     ImageBackground,
// } from 'react-native';
// import Icon from 'react-native-vector-icons/Feather';
// import {router} from "expo-router";
// import {FontAwesome} from "@expo/vector-icons";
//
// const notifications = [
//     {
//         id: '1',
//         title: 'Trial Dates',
//         message: 'The Trial Dates for your Selection is announced. Check the mail for further details',
//         time: 'Now',
//         icon: require('../../assets/images/t10stcl-card.webp'), // replace with your icon
//     },
// ];
//
// const NotificationScreen = () => {
//     const renderNotification = ({ item }) => (
//         <View style={styles.notificationCard}>
//             <View style={styles.notificationHeader}>
//                 <View style={styles.dot} />
//                 <Image source={item.icon} style={styles.icon} />
//                 <View style={styles.notificationTextContainer}>
//                     <Text style={styles.notificationTitle}>{item.title}</Text>
//                     <Text style={styles.notificationMessage}>{item.message}</Text>
//                 </View>
//                 <Text style={styles.timeText}>{item.time}</Text>
//             </View>
//         </View>
//     );
//
//     return (
//         <SafeAreaView style={styles.container}>
//             <ImageBackground
//                 source={require('../../assets/images/bg.webp')} // replace with your background image path
//                 style={styles.backgroundImage}
//             >
//                 {/* Header */}
//                 <View style={styles.headerContainer}>
//                     <TouchableOpacity onPress={() => router.back()} >
//                         <FontAwesome name="arrow-left" size={20} color="#fff" />
//                     </TouchableOpacity>
//                     <Text style={styles.headerTitle}>Notifications</Text>
//                     <View style={{ width: 24 }} />
//                 </View>
//
//                 {/* Action Buttons */}
//                 <View style={styles.actionButtonsContainer}>
//                     <TouchableOpacity style={styles.actionButton}>
//                         <Text style={styles.actionText}>Mark All Read</Text>
//                     </TouchableOpacity>
//                     <TouchableOpacity style={styles.actionButton}>
//                         <Text style={styles.actionText}>Clear All</Text>
//                     </TouchableOpacity>
//                 </View>
//
//                 {/* Notification List */}
//                 <FlatList
//                     data={notifications}
//                     renderItem={renderNotification}
//                     keyExtractor={(item) => item.id}
//                     contentContainerStyle={styles.notificationList}
//                 />
//             </ImageBackground>
//         </SafeAreaView>
//     );
// };
//
// export default NotificationScreen;
//
// const styles = StyleSheet.create({
//     container: {
//         flex: 1,
//     },
//     backgroundImage: {
//         flex: 1,
//         resizeMode: 'cover',
//     },
//     headerContainer: {
//         flexDirection: 'row',
//         alignItems: 'center',
//         justifyContent: 'space-between',
//         padding: 16,
//         marginTop:30,
//     },
//     headerTitle: {
//         color: '#fff',
//         fontSize: 20,
//         fontWeight: 'bold',
//     },
//     actionButtonsContainer: {
//         flexDirection: 'row',
//         justifyContent: 'space-around',
//         marginBottom: 16,
//         paddingHorizontal:12,
//     },
//     actionButton: {
//         backgroundColor: '#2A2A2A',
//         width: '48%',
//         paddingVertical: 15,
//
//         paddingHorizontal: 20,
//         borderRadius: 5,
//     },
//     actionText: {
//         color: '#fff',
//         alignSelf:'center',
//         fontWeight: 'bold',
//     },
//     notificationList: {
//         paddingHorizontal: 16,
//     },
//     notificationCard: {
//         backgroundColor: '#2A2A2A',
//         borderRadius: 10,
//         padding: 16,
//         marginBottom: 16,
//     },
//     notificationHeader: {
//         flexDirection: 'row',
//         alignItems: 'flex-start',
//         position: 'relative',
//     },
//     dot: {
//         width: 8,
//         height: 8,
//         backgroundColor: '#F5A623',
//         borderRadius: 4,
//         position: 'absolute',
//         top: 4,
//         left: -12,
//     },
//     icon: {
//         width: 24,
//         height: 24,
//         resizeMode: 'contain',
//         marginRight: 12,
//     },
//     notificationTextContainer: {
//         flex: 1,
//     },
//     notificationTitle: {
//         color: '#fff',
//         fontWeight: 'bold',
//         fontSize: 15,
//     },
//     notificationMessage: {
//         color: '#ccc',
//         fontSize: 13,
//         marginTop: 4,
//     },
//     timeText: {
//         color: '#aaa',
//         fontSize: 12,
//         alignSelf: 'flex-start',
//         marginLeft: 10,
//     },
// });


// import { useEffect, useState } from 'react';
// import { View, Text, StyleSheet, TouchableOpacity, RefreshControl, Modal, ImageBackground } from 'react-native';
// import { FlashList } from '@shopify/flash-list';
// import { useNotificationStore } from '../lib/stores/notificationStore';
// import { Bell, X, Gift } from 'lucide-react-native';
// import globalStyles, { BORDER, COLORS } from '../styles/globalStyles';
// import { useUser } from '@clerk/clerk-expo';
//
// export default function NotificationsScreen() {
//     const [refreshing, setRefreshing] = useState(false);
//     const [selectedNotification, setSelectedNotification] = useState<any>(null);
//     const [modalVisible, setModalVisible] = useState(false);
//
//     const { user } = useUser();
//     const { notifications, fetchNotifications, markAsRead, initializeNotifications } = useNotificationStore();
//
//     useEffect(() => {
//         if (user?.id) {
//             initializeNotifications(user.id);
//             handleRefresh();
//         }
//     }, [user?.id]);
//
//     const handleRefresh = async () => {
//         if (!user?.id) return;
//         setRefreshing(true);
//         await fetchNotifications(user.id);
//         setRefreshing(false);
//     };
//
//     const handleNotificationPress = (notification: any) => {
//         setSelectedNotification(notification);
//         setModalVisible(true);
//         if (!notification.read_by.includes(user?.id)) {
//             markAsRead(notification.$id, user?.id);
//         }
//     };
//
//     const renderNotificationItem = ({ item }: { item: any }) => (
//         <TouchableOpacity
//             style={[localStyles.notificationItem, !item.read_by.includes(user?.id) && localStyles.unreadNotification]}
//             onPress={() => handleNotificationPress(item)}
//         >
//             <View style={localStyles.notificationIcon}>
//                 <Gift size={25} color={!item.read_by.includes(user?.id) ? COLORS.primary : '#9ca3af'} />
//             </View>
//             <View style={localStyles.notificationContent}>
//                 <Text style={[localStyles.notificationTitle, !item.read_by.includes(user?.id) && localStyles.unreadNotificationTitle]} numberOfLines={1}>
//                     {item.title}
//                 </Text>
//                 <Text style={localStyles.notificationPreview} numberOfLines={2}>
//                     {item.message}
//                 </Text>
//                 <Text style={localStyles.notificationTime}>
//                     {new Date(item.$createdAt).toLocaleString()}
//                 </Text>
//             </View>
//         </TouchableOpacity>
//     );
//
//     return (
//         <ImageBackground source={require('@/assets/images/bg.webp')} style={globalStyles.container}>
//             <Text style={localStyles.title}>Notifications</Text>
//             <View style={localStyles.content}>
//                 {notifications.length === 0 ? (
//                     <View style={localStyles.emptyContainer}>
//                         <Bell size={60} color="#d1d5db" />
//                         <Text style={localStyles.emptyText}>No notifications yet</Text>
//                         <Text style={localStyles.emptySubtext}>
//                             When you receive notifications, they will appear here
//                         </Text>
//                     </View>
//                 ) : (
//                     <FlashList
//                         data={notifications}
//                         estimatedItemSize={20}
//                         renderItem={renderNotificationItem}
//                         keyExtractor={(item) => item.$id}
//                         contentContainerStyle={localStyles.listContainer}
//                         refreshControl={
//                             <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} colors={[COLORS.primary]} />
//                         }
//                     />
//                 )}
//
//                 <Modal
//                     animationType="slide"
//                     transparent={true}
//                     visible={modalVisible}
//                     onRequestClose={() => setModalVisible(false)}
//                 >
//                     <View style={localStyles.modalOverlay}>
//                         <View style={localStyles.modalContent}>
//                             <View style={localStyles.modalHeader}>
//                                 <Text style={localStyles.modalTitle}>
//                                     {selectedNotification?.title}
//                                 </Text>
//                                 <TouchableOpacity
//                                     style={localStyles.closeButton}
//                                     onPress={() => setModalVisible(false)}
//                                 >
//                                     <X size={24} color="#6b7280" />
//                                 </TouchableOpacity>
//                             </View>
//                             <Text style={localStyles.modalDate}>
//                                 {selectedNotification && new Date(selectedNotification.$createdAt).toLocaleString()}
//                             </Text>
//                             <Text style={localStyles.modalMessage}>
//                                 {selectedNotification?.message}
//                             </Text>
//                         </View>
//                     </View>
//                 </Modal>
//             </View>
//         </ImageBackground>
//     );
// }
//
// const localStyles = StyleSheet.create({
//     content: {
//         flex: 1,
//     },
//     title: {
//         fontSize: 24,
//         fontWeight: 'bold',
//         color: COLORS.text,
//         textAlign: 'center',
//         marginBottom: 20,
//         marginTop: 40
//     },
//     listContainer: {
//         padding: 10,
//     },
//     notificationItem: {
//         flexDirection: 'row',
//         backgroundColor: '#FFFFFF0A',
//         borderRadius: BORDER.primaryRadius,
//         padding: 15,
//         marginBottom: 12,
//         shadowColor: '#000',
//         shadowOffset: { width: 0, height: 1 },
//         shadowOpacity: 0.05,
//         shadowRadius: 2,
//         elevation: 1,
//     },
//     unreadNotification: {
//         backgroundColor: COLORS.overlay,
//         borderLeftWidth: 3,
//         borderLeftColor: COLORS.primary,
//     },
//     notificationIcon: {
//         marginRight: 12,
//         alignItems: 'center',
//         justifyContent: 'center',
//         width: 36,
//         aspectRatio: 1,
//         borderRadius: 100,
//         backgroundColor: '#f3f4f6',
//     },
//     notificationContent: {
//         flex: 1,
//     },
//     unreadNotificationTitle: {
//         color: COLORS.text,
//     },
//     notificationTitle: {
//         color: '#f3f4f6',
//         fontSize: 16,
//         fontWeight: '600',
//         marginBottom: 4,
//         fontFamily: 'Inter-SemiBold',
//     },
//     notificationPreview: {
//         fontSize: 14,
//         color: COLORS.secondaryTxt,
//         marginBottom: 8,
//         fontFamily: 'Inter-Regular',
//     },
//     notificationTime: {
//         fontSize: 12,
//         color: '#9ca3af',
//         fontFamily: 'Inter-Regular',
//     },
//     emptyContainer: {
//         flex: 1,
//         justifyContent: 'center',
//         alignItems: 'center',
//         padding: 20,
//     },
//     emptyText: {
//         fontSize: 18,
//         fontWeight: '600',
//         color: COLORS.text,
//         marginTop: 16,
//         marginBottom: 8,
//         fontFamily: 'Inter-SemiBold',
//     },
//     emptySubtext: {
//         fontSize: 14,
//         color: COLORS.secondaryTxt,
//         textAlign: 'center',
//         maxWidth: 250,
//         fontFamily: 'Inter-Regular',
//     },
//     modalOverlay: {
//         flex: 1,
//         justifyContent: 'flex-end',
//         backgroundColor: 'rgba(0, 0, 0, 0.5)',
//     },
//     modalContent: {
//         backgroundColor: '#ffffff',
//         borderTopLeftRadius: 20,
//         borderTopRightRadius: 20,
//         padding: 20,
//         maxHeight: '80%',
//     },
//     modalHeader: {
//         flexDirection: 'row',
//         justifyContent: 'space-between',
//         alignItems: 'center',
//         marginBottom: 12,
//     },
//     modalTitle: {
//         fontSize: 20,
//         fontWeight: '700',
//         color: '#1f2937',
//         flex: 1,
//         fontFamily: 'Inter-Bold',
//     },
//     closeButton: {
//         padding: 4,
//     },
//     modalDate: {
//         fontSize: 14,
//         color: COLORS.secondaryTxt,
//         marginBottom: 16,
//         fontFamily: 'Inter-Regular',
//     },
//     modalMessage: {
//         fontSize: 16,
//         color: '#1f2937',
//         lineHeight: 24,
//         fontFamily: 'Inter-Regular',
//     },
// });





















// import React, { useEffect, useState } from 'react';
// import {
//     View,
//     Text,
//     StyleSheet,
//     TouchableOpacity,
//     FlatList,
//     ImageBackground,
//     RefreshControl,
//     SafeAreaView,
//     Modal,
//     Dimensions,
// } from 'react-native';
// import { useUser } from '@clerk/clerk-expo';
// import { useNotificationStore } from '../lib/stores/notificationStore';
// import { router } from 'expo-router';
// import { FontAwesome } from '@expo/vector-icons';
// import { Gift } from 'lucide-react-native';
// import { COLORS } from '../styles/globalStyles';
//
// const { width } = Dimensions.get('window');
//
// const NotificationScreen = () => {
//     const { user } = useUser();
//     const [refreshing, setRefreshing] = useState(false);
//     const [selectedNotification, setSelectedNotification] = useState<any>(null);
//     const [modalVisible, setModalVisible] = useState(false);
//
//     const {
//         notifications,
//         fetchNotifications,
//         markAsRead,
//         markAllAsRead,
//         clearAllNotifications,
//         initializeNotifications,
//     } = useNotificationStore();
//
//
//
//     useEffect(() => {
//         if (user?.id) {
//             initializeNotifications(user.id);
//             handleRefresh();
//         }
//     }, [user?.id]);
//
//     const handleRefresh = async () => {
//         if (!user?.id) return;
//         setRefreshing(true);
//         await fetchNotifications(user.id);
//         setRefreshing(false);
//     };
//
//     const handleNotificationPress = (notification: any) => {
//         if (!notification.read_by.includes(user?.id)) {
//             markAsRead(notification.$id, user?.id);
//         }
//         setSelectedNotification(notification);
//         setModalVisible(true);
//     };
//
//     const handleMarkAllRead = async () => {
//         if (!user?.id) return;
//         await markAllAsRead(user.id);
//         await fetchNotifications(user.id);
//     };
//
//     const handleClearAll = async () => {
//         if (!user?.id) return;
//         await clearAllNotifications(user.id);
//         await fetchNotifications(user.id);
//     };
//
//     const renderNotification = ({ item }: { item: any }) => (
//         <TouchableOpacity onPress={() => handleNotificationPress(item)} activeOpacity={0.8}>
//             <View style={[styles.notificationCard, !item.read_by.includes(user?.id) && styles.unread]}>
//                 <View style={styles.notificationHeader}>
//                     {!item.read_by.includes(user?.id) && <View style={styles.dot} />}
//                     <Gift size={24} color={COLORS.primary} style={styles.icon} />
//                     <View style={styles.notificationTextContainer}>
//                         <Text style={styles.notificationTitle}>{item.title}</Text>
//                         <Text numberOfLines={2} style={styles.notificationMessage}>{item.message}</Text>
//                     </View>
//                     <Text style={styles.timeText}>
//                         {new Date(item.$createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
//                     </Text>
//                 </View>
//             </View>
//         </TouchableOpacity>
//     );
//
//     return (
//         <SafeAreaView style={styles.container}>
//             <ImageBackground source={require('../../assets/images/bg.webp')} style={styles.backgroundImage}>
//                 {/* Header */}
//                 <View style={styles.headerContainer}>
//                     <TouchableOpacity onPress={() => router.back()}>
//                         <FontAwesome name="arrow-left" size={20} color="#fff" />
//                     </TouchableOpacity>
//                     <Text style={styles.headerTitle}>Notifications</Text>
//                     <View style={{ width: 24 }} />
//                 </View>
//
//                 {/* Action Buttons */}
//                 <View style={styles.actionButtonsContainer}>
//                     <TouchableOpacity style={styles.actionButton} onPress={handleMarkAllRead}>
//                         <Text style={styles.actionText}>Mark All Read</Text>
//                     </TouchableOpacity>
//                     <TouchableOpacity style={styles.actionButton} onPress={handleClearAll}>
//                         <Text style={styles.actionText}>Clear All</Text>
//                     </TouchableOpacity>
//                 </View>
//
//                 {/* Notification List */}
//                 <FlatList
//                     data={notifications}
//                     renderItem={renderNotification}
//                     keyExtractor={(item) => item.$id}
//                     contentContainerStyle={styles.notificationList}
//                     refreshControl={
//                         <RefreshControl
//                             refreshing={refreshing}
//                             onRefresh={handleRefresh}
//                             colors={[COLORS.primary]}
//                         />
//                     }
//                     ListEmptyComponent={
//                         <View style={{ alignItems: 'center', marginTop: 50 }}>
//                             <Text style={{ color: '#ccc', fontSize: 16 }}>No notifications yet.</Text>
//                         </View>
//                     }
//                 />
//
//                 {/* Modal */}
//                 <Modal visible={modalVisible} transparent animationType="fade">
//                     <View style={styles.modalOverlay}>
//                         <View style={styles.modalContainer}>
//                             <Text style={styles.modalTitle}>{selectedNotification?.title}</Text>
//                             <Text style={styles.modalMessage}>{selectedNotification?.message}</Text>
//
//                             <TouchableOpacity
//                                 style={styles.closeButton}
//                                 onPress={() => setModalVisible(false)}
//                             >
//                                 <Text style={styles.closeButtonText}>Close</Text>
//                             </TouchableOpacity>
//                         </View>
//                     </View>
//                 </Modal>
//             </ImageBackground>
//         </SafeAreaView>
//     );
// };
//
// export default NotificationScreen;
//
// const styles = StyleSheet.create({
//     container: {
//         flex: 1,
//     },
//     backgroundImage: {
//         flex: 1,
//         resizeMode: 'cover',
//     },
//     headerContainer: {
//         flexDirection: 'row',
//         alignItems: 'center',
//         justifyContent: 'space-between',
//         padding: 16,
//         marginTop: 30,
//     },
//     headerTitle: {
//         color: '#fff',
//         fontSize: 20,
//         fontWeight: 'bold',
//     },
//     actionButtonsContainer: {
//         flexDirection: 'row',
//         justifyContent: 'space-around',
//         marginBottom: 16,
//         paddingHorizontal: 12,
//     },
//     actionButton: {
//         backgroundColor: '#2A2A2A',
//         width: '48%',
//         paddingVertical: 15,
//         borderRadius: 5,
//     },
//     actionText: {
//         color: '#fff',
//         alignSelf: 'center',
//         fontWeight: 'bold',
//     },
//     notificationList: {
//         paddingHorizontal: 16,
//     },
//     notificationCard: {
//         backgroundColor: '#2A2A2A',
//         borderRadius: 10,
//         padding: 16,
//         marginBottom: 16,
//     },
//     unread: {
//         borderLeftWidth: 3,
//         borderLeftColor: COLORS.primary,
//     },
//     notificationHeader: {
//         flexDirection: 'row',
//         alignItems: 'flex-start',
//         position: 'relative',
//     },
//     dot: {
//         width: 8,
//         height: 8,
//         backgroundColor: COLORS.primary,
//         borderRadius: 4,
//         position: 'absolute',
//         top: 4,
//         left: -12,
//     },
//     icon: {
//         marginRight: 12,
//         marginTop: 2,
//     },
//     notificationTextContainer: {
//         flex: 1,
//     },
//     notificationTitle: {
//         color: '#fff',
//         fontWeight: 'bold',
//         fontSize: 15,
//     },
//     notificationMessage: {
//         color: '#ccc',
//         fontSize: 13,
//         marginTop: 4,
//     },
//     timeText: {
//         color: '#aaa',
//         fontSize: 12,
//         alignSelf: 'flex-start',
//         marginLeft: 10,
//     },
//     modalOverlay: {
//         flex: 1,
//         backgroundColor: 'rgba(0, 0, 0, 0.6)',
//         justifyContent: 'center',
//         alignItems: 'center',
//     },
//     modalContainer: {
//         backgroundColor: '#2A2A2A',
//         padding: 20,
//         borderRadius: 10,
//         width: width * 0.85,
//     },
//     modalTitle: {
//         color: '#fff',
//         fontWeight: 'bold',
//         fontSize: 18,
//         marginBottom: 10,
//     },
//     modalMessage: {
//         color: '#ccc',
//         fontSize: 14,
//     },
//     closeButton: {
//         marginTop: 20,
//         backgroundColor: COLORS.primary,
//         paddingVertical: 12,
//         borderRadius: 8,
//         alignItems: 'center',
//     },
//     closeButtonText: {
//         color: '#000',
//         fontWeight: 'bold',
//         fontSize: 16,
//     },
// });















import React, { useEffect, useState } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    FlatList,
    ImageBackground,
    RefreshControl,
    SafeAreaView,
    Modal,
    Dimensions,
} from 'react-native';
import { useUser } from '@clerk/clerk-expo';
import { useNotificationStore } from '../lib/stores/notificationStore';
import { useUserStore } from '@/app/lib/stores/userStore'; // ✅ Zustand store
import { router } from 'expo-router';
import { FontAwesome } from '@expo/vector-icons';
import { Gift } from 'lucide-react-native';
import { COLORS } from '../styles/globalStyles';

const { width } = Dimensions.get('window');

const NotificationScreen = () => {
    const { user } = useUser();
    const { appwriteUserId } = useUserStore(); // ✅ Zustand hook

    const [refreshing, setRefreshing] = useState(false);
    const [selectedNotification, setSelectedNotification] = useState<any>(null);
    const [modalVisible, setModalVisible] = useState(false);

    const clerkUserId = user?.id;

    const {
        notifications,
        fetchNotifications,
        markAsRead,
        markAllAsRead,
        clearAllNotifications,
        initializeNotifications,
    } = useNotificationStore();

    useEffect(() => {
        if (clerkUserId || appwriteUserId) {
            initializeNotifications(clerkUserId, appwriteUserId);
            handleRefresh();
        }
    }, [clerkUserId, appwriteUserId]);

    const handleRefresh = async () => {
        setRefreshing(true);
        await fetchNotifications(clerkUserId, appwriteUserId);
        setRefreshing(false);
    };

    const handleNotificationPress = (notification: any) => {
        const isRead = notification.read_by.includes(clerkUserId) || notification.read_by.includes(appwriteUserId);
        if (!isRead) {
            if (clerkUserId) markAsRead(notification.$id, clerkUserId);
            if (appwriteUserId) markAsRead(notification.$id, appwriteUserId);
        }
        setSelectedNotification(notification);
        setModalVisible(true);
    };

    const handleMarkAllRead = async () => {
        if (clerkUserId) await markAllAsRead(clerkUserId);
        if (appwriteUserId) await markAllAsRead(appwriteUserId);
        await fetchNotifications(clerkUserId, appwriteUserId);
    };

    const handleClearAll = async () => {
        if (clerkUserId) await clearAllNotifications(clerkUserId);
        if (appwriteUserId) await clearAllNotifications(appwriteUserId);
        await fetchNotifications(clerkUserId, appwriteUserId);
    };

    const renderNotification = ({ item }: { item: any }) => {
        const isUnread = !item.read_by.includes(clerkUserId) && !item.read_by.includes(appwriteUserId);
        return (
            <TouchableOpacity onPress={() => handleNotificationPress(item)} activeOpacity={0.8}>
                <View style={[styles.notificationCard, isUnread && styles.unread]}>
                    <View style={styles.notificationHeader}>
                        {isUnread && <View style={styles.dot} />}
                        <Gift size={24} color={COLORS.primary} style={styles.icon} />
                        <View style={styles.notificationTextContainer}>
                            <Text style={styles.notificationTitle}>{item.title}</Text>
                            <Text numberOfLines={2} style={styles.notificationMessage}>{item.message}</Text>
                        </View>
                        <Text style={styles.timeText}>
                            {new Date(item.$createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </Text>
                    </View>
                </View>
            </TouchableOpacity>
        );
    };

    return (
        <SafeAreaView style={styles.container}>
            <ImageBackground source={require('../../assets/images/bg.webp')} style={styles.backgroundImage}>
                {/* Header */}
                <View style={styles.headerContainer}>
                    <TouchableOpacity onPress={() => router.back()}>
                        <FontAwesome name="arrow-left" size={20} color="#fff" />
                    </TouchableOpacity>
                    <Text style={styles.headerTitle}>Notifications</Text>
                    <View style={{ width: 24 }} />
                </View>

                {/* Action Buttons */}
                <View style={styles.actionButtonsContainer}>
                    <TouchableOpacity style={styles.actionButton} onPress={handleMarkAllRead}>
                        <Text style={styles.actionText}>Mark All Read</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.actionButton} onPress={handleClearAll}>
                        <Text style={styles.actionText}>Clear All</Text>
                    </TouchableOpacity>
                </View>

                {/* Notification List */}
                <FlatList
                    data={notifications}
                    renderItem={renderNotification}
                    keyExtractor={(item) => item.$id}
                    contentContainerStyle={styles.notificationList}
                    refreshControl={
                        <RefreshControl
                            refreshing={refreshing}
                            onRefresh={handleRefresh}
                            colors={[COLORS.primary]}
                        />
                    }
                    ListEmptyComponent={
                        <View style={{ alignItems: 'center', marginTop: 50 }}>
                            <Text style={{ color: '#ccc', fontSize: 16 }}>No notifications yet.</Text>
                        </View>
                    }
                />

                {/* Modal */}
                <Modal visible={modalVisible} transparent animationType="fade">
                    <View style={styles.modalOverlay}>
                        <View style={styles.modalContainer}>
                            <Text style={styles.modalTitle}>{selectedNotification?.title}</Text>
                            <Text style={styles.modalMessage}>{selectedNotification?.message}</Text>

                            <TouchableOpacity
                                style={styles.closeButton}
                                onPress={() => setModalVisible(false)}
                            >
                                <Text style={styles.closeButtonText}>Close</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                </Modal>
            </ImageBackground>
        </SafeAreaView>
    );
};

export default NotificationScreen;

const styles = StyleSheet.create({
    container: { flex: 1 },
    backgroundImage: { flex: 1, resizeMode: 'cover' },
    headerContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: 16,
        marginTop: 30,
    },
    headerTitle: { color: '#fff', fontSize: 20, fontWeight: 'bold' },
    actionButtonsContainer: {
        flexDirection: 'row',
        justifyContent: 'space-around',
        marginBottom: 16,
        paddingHorizontal: 12,
    },
    actionButton: {
        backgroundColor: '#2A2A2A',
        width: '48%',
        paddingVertical: 15,
        borderRadius: 5,
    },
    actionText: { color: '#fff', alignSelf: 'center', fontWeight: 'bold' },
    notificationList: { paddingHorizontal: 16 },
    notificationCard: {
        backgroundColor: '#2A2A2A',
        borderRadius: 10,
        padding: 16,
        marginBottom: 16,
    },
    unread: {
        borderLeftWidth: 3,
        borderLeftColor: COLORS.primary,
    },
    notificationHeader: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        position: 'relative',
    },
    dot: {
        width: 8,
        height: 8,
        backgroundColor: COLORS.primary,
        borderRadius: 4,
        position: 'absolute',
        top: 4,
        left: -12,
    },
    icon: { marginRight: 12, marginTop: 2 },
    notificationTextContainer: { flex: 1 },
    notificationTitle: {
        color: '#fff',
        fontWeight: 'bold',
        fontSize: 15,
    },
    notificationMessage: {
        color: '#ccc',
        fontSize: 13,
        marginTop: 4,
    },
    timeText: {
        color: '#aaa',
        fontSize: 12,
        alignSelf: 'flex-start',
        marginLeft: 10,
    },
    modalOverlay: {
        flex: 1,
        backgroundColor: 'rgba(0, 0, 0, 0.6)',
        justifyContent: 'center',
        alignItems: 'center',
    },
    modalContainer: {
        backgroundColor: '#2A2A2A',
        padding: 20,
        borderRadius: 10,
        width: width * 0.85,
    },
    modalTitle: {
        color: '#fff',
        fontWeight: 'bold',
        fontSize: 18,
        marginBottom: 10,
    },
    modalMessage: { color: '#ccc', fontSize: 14 },
    closeButton: {
        marginTop: 20,
        backgroundColor: COLORS.primary,
        paddingVertical: 12,
        borderRadius: 8,
        alignItems: 'center',
    },
    closeButtonText: {
        color: '#000',
        fontWeight: 'bold',
        fontSize: 16,
    },
});




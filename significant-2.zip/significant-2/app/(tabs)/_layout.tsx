import { Tabs } from 'expo-router';
import React from 'react';
import { Platform } from 'react-native';

import { HapticTab } from '@/components/HapticTab';
import { IconSymbol } from '@/components/ui/IconSymbol';
import TabBarBackground from '@/components/ui/TabBarBackground';
import { Colors } from '@/constants/Colors';
import { useColorScheme } from '@/hooks/useColorScheme';
import { FontAwesome } from '@expo/vector-icons';

export default function TabLayout() {
    const colorScheme = useColorScheme();

    return (
        <Tabs
            screenOptions={{
                tabBarActiveTintColor: Colors[colorScheme ?? 'light'].tint,
                headerShown: false,
                tabBarButton: HapticTab,
                tabBarBackground: TabBarBackground,
                tabBarStyle: {
                    position: 'absolute',
                    backgroundColor: '#1e1e1e', // Match your screen background
                    borderTopLeftRadius: 40,
                    borderTopRightRadius: 40,
                    height: 70,
                    paddingTop: 10,
                    paddingBottom: Platform.OS === 'android' ? 10 : 20,
                    borderTopWidth: 0,
                    elevation: 10,
                    shadowColor: '#000',
                    shadowOffset: { width: 0, height: -2 },
                    shadowOpacity: 0.2,
                    shadowRadius: 8,
                    overflow: 'hidden',
                },
            }}
        >
            <Tabs.Screen
                name="IP/IP-1"
                options={{
                    title: '',
                    tabBarIcon: ({ color }) => (
                        <FontAwesome size={28} name="home" color={color} />
                    ),
                }}
            />

            <Tabs.Screen
                name="Search"
                options={{
                    title: '',
                    tabBarIcon: ({ color }) => (
                        <FontAwesome size={24} name="search" color={color} />
                    ),
                }}
            />

            <Tabs.Screen
                name="Notification"
                options={{
                    title: '',
                    tabBarIcon: ({ color }) => (
                        <FontAwesome size={24} name="bell-o" color={color} />
                    ),
                }}
            />

            <Tabs.Screen
                name="My-Account"
                options={{
                    title: '',
                    tabBarIcon: ({ color }) => (
                        <FontAwesome size={24} name="user-o" color={color} />
                    ),
                }}
            />
        </Tabs>
    );
}

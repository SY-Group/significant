import React, { useState } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TextInput,
    TouchableOpacity,
    FlatList,
    Image,
} from 'react-native';
import { FontAwesome, Feather } from '@expo/vector-icons';
import { router, useRouter } from 'expo-router';

export default function DiscoverScreen() {
    const [searchText, setSearchText] = useState("");
    const router = useRouter();

    const data = [
        {
            id: "1",
            title: "T10–STCL",
            description: "T10 Super Tennis Cricket League",
            tagline: "Fast, Fierce, Unstoppable Cricket Action!",
            image: require('../../assets/images/t10stcl-card.webp'),
        },
        // {
        //     id: '2',
        //     title: 'GL-60',
        //     description: 'Global Legends 60',
        //     tagline: 'Fast, Fierce, Unstoppable Cricket Action!',
        //     image: require('../../assets/images/global-legends-card.webp'),
        // },
        // {
        //     id: '3',
        //     title: 'Gaya Gladiators',
        //     description: 'Bihar Tennis Cricket League',
        //     tagline: 'Fast, Fierce, Unstoppable Cricket Action!',
        //     image: require('../../assets/images/gaya-gladiators-card.webp'),
        // },
        {
            id: "2",
            title: "I am Dance",
            image: require('../../assets/images/i-am-dance-card.webp'),
        },
        // {
        //     id: "5",
        //     title: "Tasavvur",
        //     image: require('../../assets/images/tasavvur-card.webp'),
        // },
        // {
        //     id: "6",
        //     title: "Zabt-E-Ishq",
        //     image: require('../../assets/images/zabt-e-ishq-card.webp'),
        // },
        // {
        //     id: "7",
        //     title: "Zindagi Aur Hum",
        //     image: require('../../assets/images/zindagi-aur-hum-card.webp'),
        // },
    ];

    const filteredData = data.filter((item) =>
        item.title.toLowerCase().includes(searchText.toLowerCase())
    );

    const renderCard = ({ item }) => (
        <TouchableOpacity
            onPress={() => handleCardPress(item.title)} // ✅ Pass item.title
            activeOpacity={0.85}
            style={styles.card}
        >
            <Image source={item.image} style={styles.cardImage} />
            <View style={styles.cardContent}>
                <Text style={styles.cardTitle}>{item.title}</Text>
                {item.description && <Text style={styles.cardDescription}>{item.description}</Text>}
                {item.tagline && <Text style={styles.cardTagline}>{item.tagline}</Text>}
            </View>
        </TouchableOpacity>
    );

    const handleCardPress = (title: string) => {
        switch (title) {
            case 'T10–STCL':
                router.push('../../Register-t10stcl/register-t10stcl');
                break;
            case 'I am Dance':
                router.push('../../Register-IamDance/Register-IAD');
                break;
            // Add more navigations as needed
        }
    };

    return (
        <View style={styles.container}>
            {/* Header */}
            <View style={styles.header}>
                <TouchableOpacity onPress={() => router.back()} >
                    <FontAwesome name="arrow-left" size={20} color="#fff" />
                </TouchableOpacity>
                <Text style={styles.headerTitle}>Discover</Text>
            </View>

            {/* Search Bar */}
            <View style={styles.searchBarContainer}>
                <Feather name="search" size={20} color="#aaa" />
                <TextInput
                    style={styles.searchInput}
                    placeholder="Search"
                    placeholderTextColor="#aaa"
                    value={searchText}
                    onChangeText={setSearchText}
                />
                {searchText.length > 0 && (
                    <TouchableOpacity onPress={() => setSearchText("")}>
                        <Feather name="x-circle" size={20} color="#aaa" />
                    </TouchableOpacity>
                )}
            </View>

            {/* Top Searches */}
            {searchText.trim().length > 0 ? (
                <>
                    <Text style={styles.topSearchesTitle}>Top searches</Text>
                    <FlatList
                        data={filteredData}
                        renderItem={renderCard}
                        keyExtractor={(item) => item.id}
                        contentContainerStyle={styles.listContainer}

                    />
                </>
            ) : (
                <Text style={styles.placeholderText}>Search to explore content</Text>
            )}
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#121212',
        paddingHorizontal: 20,
        paddingTop: 40,
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 20,
    },
    headerTitle: {
        fontSize: 20,
        fontWeight: 'bold',
        color: '#fff',
        marginLeft: 10,
    },
    searchBarContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: 'rgba(255, 255, 255, 0.1)',
        borderRadius: 25,
        paddingHorizontal: 15,
        height: 50,
        marginBottom: 20,
        borderWidth: 1,
        borderColor: '#f90',
    },
    searchInput: {
        flex: 1,
        marginLeft: 10,
        color: '#fff',
        fontSize: 16,
    },
    topSearchesTitle: {
        fontSize: 16,
        color: '#aaa',
        marginBottom: 10,
    },
    placeholderText: {
        color: '#666',
        fontSize: 16,
        marginTop: 20,
        textAlign: 'center',
    },
    listContainer: {
        marginTop: 10,
        paddingBottom: 40,
    },
    card: {
        flexDirection: 'row',
        backgroundColor: '#2c2c2c',
        borderRadius: 12,
        padding: 20,
        marginBottom: 20,
    },
    cardImage: {
        width: 80,
        height: 80,
        borderRadius: 10,
    },
    cardContent: {
        marginLeft: 20,
        flex: 1,
    },
    cardTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#fff',
    },
    cardDescription: {
        fontSize: 14,
        color: '#aaa',
        marginTop: 5,
        width: '80%',
    },
    cardTagline: {
        fontSize: 13,
        color: '#f90',
        marginTop: 5,
        width: '80%',
    },
});

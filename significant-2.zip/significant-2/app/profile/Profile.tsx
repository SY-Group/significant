import React, { useEffect, useState } from 'react';
import {
    View,
    Text,
    TextInput,
    StyleSheet,
    TouchableOpacity,
    SafeAreaView,
    Alert,
    Modal,
    Image,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import RNPickerSelect from 'react-native-picker-select';
import Icon from 'react-native-vector-icons/FontAwesome';
import { router } from "expo-router";
import { useUserContext } from '../../context/UserContext';
import { FontAwesome } from "@expo/vector-icons";
import { databases, DATABASE_ID, COLLECTION_ID } from '@/utils/appwrite-edit-profile';
import { ID } from 'appwrite';

const EditProfileScreen = () => {
    const { email } = useUserContext();
    const [userEmail, setUserEmail] = useState('');
    const [fullname, setFullName] = useState('');
    const [phone, setPhone] = useState('');
    const [gender, setGender] = useState('');
    const [showModal, setShowModal] = useState(false);
    const [imageUri, setImageUri] = useState<string | null>(null);
    const {profileImage, setProfileImage } = useUserContext();

    useEffect(() => {
        if (email) setUserEmail(email);
    }, [email]);

    const handleUpdate = async () => {
        const formData = {
            Full_Name: fullname,
            email: userEmail,
            phone: phone,
            gender: gender,
            // image: imageUri, // if you plan to upload image URI
        };
        try {
            await databases.createDocument(
                DATABASE_ID,
                COLLECTION_ID,
                ID.unique(),
                formData
            );
            setShowModal(true);
        } catch (error) {
            console.error('Error submitting form:', error);
            Alert.alert('Error', 'Failed to update data. Please try again.');
        }
    };

    const openCamera = async () => {
        const permission = await ImagePicker.requestCameraPermissionsAsync();
        if (permission.granted === false) {
            Alert.alert("Permission Denied", "Camera permission is required to take a photo.");
            return;
        }

        const result = await ImagePicker.launchCameraAsync({
            mediaTypes: ImagePicker.MediaTypeOptions.Images,
            allowsEditing: true,
            aspect: [1, 1],
            quality: 0.5,
            cameraType: ImagePicker.CameraType.front,
        });

        if (!result.canceled) {
            setImageUri(result.assets[0].uri);
            setProfileImage(result.assets[0].uri);
        }
    };

    return (
        <SafeAreaView style={styles.container}>
            <TouchableOpacity onPress={() => router.back()}>
                <FontAwesome name="arrow-left" size={20} color="#fff" />
            </TouchableOpacity>

            <Text style={styles.title}>Edit Profile</Text>

            {/* Profile Image Circle with Camera Icon */}
            <View style={styles.profileImageContainer}>
                <View style={styles.profileCircle} >
                    {imageUri ? (
                        <Image source={{ uri: imageUri }} style={styles.profileImage} />
                    ) : (
                        <FontAwesome name="camera" size={50} color="#777" onPress={openCamera}/>
                    )}
                    {/*<TouchableOpacity style={styles.cameraIcon} >*/}
                    {/*    <Icon name="camera" size={14} color="#fff" />*/}
                    {/*</TouchableOpacity>*/}
                </View>
            </View>

            <TextInput
                style={styles.input}
                placeholder="Full Name"
                value={fullname}
                onChangeText={setFullName}
                placeholderTextColor="#999"
            />
            <TextInput
                style={styles.input}
                placeholder="example@gmail.com"
                placeholderTextColor="#999"
                keyboardType="email-address"
                value={userEmail}
                onChangeText={setUserEmail}
            />

            <View style={styles.row}>
                <TextInput
                    style={[styles.input, styles.flexHalf, { marginRight: 10 }]}
                    placeholder="+91"
                    placeholderTextColor="#999"
                    keyboardType="phone-pad"
                    value={phone}
                    onChangeText={setPhone}
                />
                <View style={[styles.input, styles.flexHalf, { paddingHorizontal: 10 }]}>
                    <RNPickerSelect
                        onValueChange={setGender}
                        value={gender}
                        placeholder={{ label: 'Gender', value: null }}
                        items={[
                            { label: 'Male', value: 'male' },
                            { label: 'Female', value: 'female' },
                            { label: 'Other', value: 'other' },
                        ]}
                        style={pickerSelectStyles}
                        Icon={() => (
                            <Icon name="chevron-down" size={14} color="#999" />
                        )}
                        useNativeAndroidPickerStyle={false}
                    />
                </View>
            </View>

            <TouchableOpacity style={styles.updateButton} onPress={handleUpdate}>
                <Text style={styles.updateButtonText}>Update</Text>
            </TouchableOpacity>

            <Modal
                visible={showModal}
                transparent
                animationType="fade"
                onRequestClose={() => setShowModal(false)}
            >
                <View style={styles.modalOverlay}>
                    <View style={styles.modalContent}>
                        <TouchableOpacity
                            style={styles.closeButton}
                            onPress={() => setShowModal(false)}
                        >
                            <Text style={{ color: '#fff', fontSize: 18 }}>×</Text>
                        </TouchableOpacity>
                        <Text style={styles.modalText}>Profile updated successfully!</Text>
                    </View>
                </View>
            </Modal>
        </SafeAreaView>
    );
};

export default EditProfileScreen;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#121212',
        padding: 20,
        paddingTop: 40,
    },
    title: {
        fontSize: 20,
        color: '#fff',
        alignSelf: 'center',
        fontWeight: 'bold',
        marginBottom: 20,
    },
    profileImageContainer: {
        alignItems: 'center',
        marginBottom: 30,
    },
    profileCircle: {
        width: 100,
        height: 100,
        borderRadius: 50,
        borderWidth: 1,
        borderColor: '#555',
        justifyContent: 'center',
        alignItems: 'center',
        position: 'relative',
        overflow: 'hidden',
    },
    profileImage: {
        width: '100%',
        height: '100%',
        borderRadius: 50,
    },
    cameraIcon: {
        position: 'absolute',
        bottom: 0,
        right: 0,
        backgroundColor: '#F5A623',
        borderRadius: 12,
        padding: 6,
        zIndex: 2,
    },
    input: {
        backgroundColor: '#1E1E1E',
        borderRadius: 6,
        paddingVertical: 14,
        paddingHorizontal: 12,
        color: '#fff',
        marginBottom: 15,
    },
    row: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    flexHalf: {
        flex: 1,
    },
    updateButton: {
        backgroundColor: '#F5A623',
        padding: 16,
        borderRadius: 8,
        marginTop: 30,
    },
    updateButtonText: {
        textAlign: 'center',
        color: '#fff',
        fontWeight: 'bold',
        fontSize: 16,
    },
    modalOverlay: {
        flex: 1,
        backgroundColor: 'rgba(0,0,0,0.7)',
        justifyContent: 'center',
        alignItems: 'center',
    },
    modalContent: {
        backgroundColor: '#1E1E1E',
        borderRadius: 10,
        padding: 25,
        width: '80%',
        alignItems: 'center',
        borderColor: '#F5A623',
        borderWidth: 1,
    },
    modalText: {
        color: '#fff',
        fontSize: 16,
        fontWeight: 'bold',
        textAlign: 'center',
    },
    closeButton: {
        position: 'absolute',
        top: 10,
        right: 10,
        padding: 5,
    },
});

const pickerSelectStyles = StyleSheet.create({
    inputIOS: {
        fontSize: 12,
        paddingVertical: 2,
        color: '#fff',
    },
    inputAndroid: {
        fontSize: 12,
        paddingVertical: 2,
        color: '#fff',
    },
    placeholder: {
        color: '#999',
    },
    iconContainer: {
        top: 2,
        right: 6,
        position: 'absolute',
    },
});


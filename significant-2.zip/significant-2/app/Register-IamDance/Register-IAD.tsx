// import React, { useState, useEffect } from 'react';
// import {
//     View,
//     Text,
//     TextInput,
//     ScrollView,
//     TouchableOpacity,
//     StyleSheet,
//     ImageBackground,
//     Alert, Platform,
// } from 'react-native';
// import { useRouter } from 'expo-router';
// import * as WebBrowser from 'expo-web-browser';
// import DropDownPicker from 'react-native-dropdown-picker';
// import Icon from 'react-native-vector-icons/FontAwesome';
// import { useLocationStore } from '../../stores/locationStore';
// import { databases, DATABASE_ID, COLLECTION_ID } from '@/utils/appwrite-register-iamdance';
// import { ID } from 'appwrite';
// import { FontAwesome } from '@expo/vector-icons';
// import DateTimePicker from "@react-native-community/datetimepicker";
//
// const razorpayLinks = {
//     SOLO: 'https://rzp.io/rzp/Gbu54Ut',
//     DUO: 'https://rzp.io/rzp/FU1AAyh',
//     GROUP: 'https://rzp.io/rzp/zzGKUFGT',
// };
//
// const RegisterScreen = () => {
//     const [registrationNumber, setRegistrationNumber] = useState('');
//     const [danceCategory, setDanceCategory] = useState('');
//     const [danceStyle, setDanceStyle] = useState(null);
//     const [agree, setAgree] = useState(false);
//     const [registrationFees, setRegistrationFees] = useState(0);
//     const [fullName, setFullName] = useState('');
//     const [dobDay, setDobDay] = useState('');
//     const [dobMonth, setDobMonth] = useState('');
//     const [dobYear, setDobYear] = useState('');
//
//     const [aadhaar, setAadhaar] = useState('');
//     const [email, setEmail] = useState('');
//     const [phone, setPhone] = useState('');
//     const [street, setStreet] = useState('');
//     const [cityAddress, setCityAddress] = useState('');
//     const [postalCode, setPostalCode] = useState('');
//     const [stateAddress, setStateAddress] = useState('');
//     const [countryAddress, setCountryAddress] = useState('');
//     const [referralCode, setReferralCode] = useState('');
//
//     const router = useRouter();
//     const { country, region } = useLocationStore();
//
//     const [showDatePicker, setShowDatePicker] = useState(false);
//     const [selectedDate, setSelectedDate] = useState<Date | null>(null);
//
//     useEffect(() => {
//         setStateAddress(region || '');
//         setCountryAddress(country || '');
//     }, [country, region]);
//
//     useEffect(() => {
//         const prefix = country?.toLowerCase() === 'india' ? 'IADIN' : country?.toLowerCase() === 'dubai' ? 'IADUAE' : 'IADAE';
//         const random = Math.floor(100000 + Math.random() * 900000);
//         setRegistrationNumber(`${prefix}${random}`);
//     }, [country]);
//
//     useEffect(() => {
//         if (danceCategory === 'SOLO') setRegistrationFees(1178.82);
//         else if (danceCategory === 'DUO') setRegistrationFees(1886.82);
//         else if (danceCategory === 'GROUP') setRegistrationFees(2358.82);
//         else setRegistrationFees(0);
//     }, [danceCategory]);
//
//     const handlePay = async () => {
//         if (!dobDay || !dobMonth || !dobYear || isNaN(+dobDay) || isNaN(+dobMonth) || isNaN(+dobYear)) {
//             Alert.alert('Invalid DOB', 'Please enter a valid Date of Birth.');
//             return;
//         }
//
//         const dob = `${dobYear}-${dobMonth.padStart(2, '0')}-${dobDay.padStart(2, '0')}`;
//
//         const formData = {
//             Register_Number: registrationNumber,
//             Full_Name: fullName,
//             DOB: dob,
//             adhaar_num: aadhaar,
//             Email: email,
//             Phone: phone,
//             reffer_code: referralCode,
//             dance_style: danceStyle,
//             dance_cat: danceCategory,
//             street_address: street,
//             city: cityAddress,
//             postal_code: postalCode,
//             state: stateAddress,
//             country: countryAddress,
//         };
//
//         if (!agree) {
//             Alert.alert('Terms Required', 'You must agree to the terms and conditions to proceed.');
//             return;
//         }
//
//         if (!danceCategory) {
//             Alert.alert('Select Category', 'Please select a dance category to proceed.');
//             return;
//         }
//
//         try {
//             await databases.createDocument(DATABASE_ID, COLLECTION_ID, ID.unique(), formData);
//
//             if (country?.toLowerCase() === 'india') {
//                 await WebBrowser.openBrowserAsync(razorpayLinks[danceCategory]);
//             } else {
//                 Alert.alert('Unsupported Region', 'Payment is only supported for India.');
//             }
//         } catch (error) {
//             console.error(error);
//             Alert.alert('Error', 'Failed to submit registration. Please try again.');
//         }
//     };
//
//     const danceStyles = [
//         { label: 'Hip Hop', value: 'hiphop' },
//         { label: 'Breaking', value: 'breaking' },
//         { label: 'Popping', value: 'popping' },
//         { label: 'Locking', value: 'locking' },
//         { label: 'Krump', value: 'krump' },
//         { label: 'Waacking', value: 'waacking' },
//         { label: 'House', value: 'house' },
//         { label: 'Litefeet', value: 'litefeet' },
//         { label: 'Dancehall', value: 'dancehall' },
//         { label: 'Bharatanatyam', value: 'bharatanatyam' },
//         { label: 'Kathak', value: 'kathak' },
//         { label: 'Odissi', value: 'odissi' },
//         { label: 'Kuchipudi', value: 'kuchipudi' },
//         { label: 'Mohiniyattam', value: 'mohiniyattam' },
//         { label: 'Manipuri', value: 'manipuri' },
//         { label: 'Kathakali', value: 'kathakali' },
//         { label: 'Sattriya', value: 'sattriya' },
//         { label: 'Jazz', value: 'jazz' },
//         { label: 'Contemporary', value: 'contemporary' },
//         { label: 'Ballet', value: 'ballet' },
//         { label: 'Freestyle', value: 'freestyle' },
//         { label: 'Bollywood', value: 'bollywood' },
//         { label: 'Semi-Classical', value: 'semiclassical' },
//         { label: 'Lyrical Hip Hop', value: 'lyricalhiphop' },
//         { label: 'Jazz Funk', value: 'jazzfunk' },
//         { label: 'Latin (Salsa, Bachata)', value: 'latin' },
//         { label: 'Afro', value: 'afro' },
//         { label: 'Urban Choreography', value: 'urban' },
//         { label: 'Folk (Garba, Bhangra, Lavani, Kalbelia)', value: 'folk' },
//         { label: 'Tribal Fusion', value: 'tribalfusion' },
//         { label: 'Experimental Movement', value: 'experimental' },
//     ];
//
//     const [open, setOpen] = useState(false);
//     const [items, setItems] = useState(danceStyles);
//
//     return (
//         <ImageBackground source={require('../../assets/images/bg.webp')} style={styles.background}>
//             <ScrollView contentContainerStyle={styles.container} showsVerticalScrollIndicator={false}>
//                 <View style={{ flex: 1, padding: 15 }}>
//                     <TouchableOpacity onPress={() => router.back()} >
//                         <FontAwesome name="arrow-left" size={20} color="#fff" />
//                     </TouchableOpacity>
//
//                     <Text style={styles.title}>Register</Text>
//
//                     <Text style={styles.label}>REGISTRATION NUMBER</Text>
//                     <TextInput
//                         style={[styles.input, { backgroundColor: 'rgba(255,255,255,0.1)' }]}
//                         value={registrationNumber}
//                         editable={false}
//                         selectTextOnFocus={false}
//                         placeholderTextColor="#888"
//                     />
//
//                     <Text style={styles.label}>FULL NAME</Text>
//                     <TextInput style={styles.input} placeholder="Full Name" placeholderTextColor="#888" value={fullName} onChangeText={setFullName} />
//
//
//                     <Text style={styles.label}>DATE-OF-BIRTH</Text>
//                     <TouchableOpacity onPress={() => setShowDatePicker(true)}>
//                         <View style={[styles.input, { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }]}>
//                             <Text style={{ color: dobDay ? '#fff' : '#888' }}>
//                                 {dobDay && dobMonth && dobYear
//                                     ? `${dobDay.padStart(2, '0')}-${dobMonth.padStart(2, '0')}-${dobYear}`
//                                     : 'Select Date of Birth'}
//                             </Text>
//                             <FontAwesome name="calendar" size={18} color="#fff" />
//                         </View>
//                     </TouchableOpacity>
//
//                     {showDatePicker && (
//                         <DateTimePicker
//                             testID="dateTimePicker"
//                             value={selectedDate || new Date(2005, 0, 1)}
//                             mode="date"
//                             display={Platform.OS === 'ios' ? 'spinner' : 'default'}
//                             maximumDate={new Date()}
//                             onChange={(event, date) => {
//                                 setShowDatePicker(false);
//                                 if (date) {
//                                     const day = `${date.getDate()}`;
//                                     const month = `${date.getMonth() + 1}`;
//                                     const year = `${date.getFullYear()}`;
//
//                                     setSelectedDate(date);
//                                     setDobDay(day);
//                                     setDobMonth(month);
//                                     setDobYear(year);
//                                 }
//                             }}
//                         />
//                     )}
//
//                     <Text style={styles.label}>ADDRESS</Text>
//                     <TextInput style={styles.input} placeholder="Street Address" placeholderTextColor="#888" value={street} onChangeText={setStreet} />
//                     <View style={styles.row}>
//                         <TextInput style={[styles.input, styles.halfInput]} placeholder="City" placeholderTextColor="#888" value={cityAddress} onChangeText={setCityAddress} />
//                         <TextInput
//                             style={[styles.input, styles.halfInput]}
//                             value={region || ''}
//                             editable={false}
//                             placeholder="State"
//                             placeholderTextColor="#888"
//                         />
//                     </View>
//                     <View style={styles.row}>
//                         <TextInput style={[styles.input, styles.halfInput]} placeholder="Postal Code" placeholderTextColor="#888" value={postalCode} onChangeText={setPostalCode} />
//                         <TextInput
//                             style={[styles.input, styles.halfInput]}
//                             value={country || ''}
//                             editable={false}
//                             placeholder="Country"
//                             placeholderTextColor="#888"
//                         />
//                     </View>
//
//                     <Text style={styles.label}>ADHAAR CARD NUMBER (No Spaces)</Text>
//                     <TextInput
//                         style={styles.input}
//                         placeholder="XXXXXXXXXXXX"
//                         value={aadhaar}
//                         onChangeText={setAadhaar}
//                         placeholderTextColor="#888"
//                         keyboardType="numeric"
//                     />
//
//                     <View style={styles.row}>
//                         <TextInput style={[styles.input, styles.halfInput]} placeholder="Email ID" placeholderTextColor="#888" value={email} onChangeText={setEmail}/>
//                         <TextInput style={[styles.input, styles.halfInput]} placeholder="Phone No." placeholderTextColor="#888" keyboardType="phone-pad" value={phone} onChangeText={setPhone}/>
//                     </View>
//
//                     <Text style={styles.label}>DANCE CATEGORY</Text>
//                     <View style={styles.row}>
//                         {['SOLO', 'DUO', 'GROUP'].map((type) => (
//                             <TouchableOpacity
//                                 key={type}
//                                 style={[styles.radioButton, danceCategory === type && styles.radioSelected]}
//                                 onPress={() => setDanceCategory(type)}
//                             >
//                                 <Text style={[styles.radioText, danceCategory === type && { color: '#000' }]}>{type}</Text>
//                             </TouchableOpacity>
//                         ))}
//                     </View>
//
//                     <Text style={styles.label}>SELECT DANCE STYLE</Text>
//                     <DropDownPicker
//                         open={open}
//                         setOpen={setOpen}
//                         value={danceStyle}
//                         setValue={setDanceStyle}
//                         items={items}
//                         setItems={setItems}
//                         placeholder="Select Dance Style"
//                         style={styles.dropdown}
//                         dropDownContainerStyle={styles.dropdownContainer}
//                         textStyle={{ color: '#fff' }}
//                         listMode="SCROLLVIEW"
//                         ArrowDownIconComponent={() => <Icon name="chevron-down" size={14} color="#999" />}
//                         ArrowUpIconComponent={() => <Icon name="chevron-up" size={14} color="#999" />}
//                     />
//
//                     <Text style={styles.label}>REFERRAL CODE (Optional)</Text>
//                     <TextInput style={styles.input} placeholder="Code" placeholderTextColor="#888" value={referralCode} onChangeText={setReferralCode}/>
//
//                     <Text style={styles.label}>COMPETITION TERMS AND SERVICES</Text>
//                     <View style={styles.noteBox}>
//                         <Text style={styles.noteTitle}>NOTE :-</Text>
//                         <Text style={styles.noteText}>
//                             1. The registration fee for participation in the I AM DANCE trials conducted by Significant Sports and Entertainment Pvt. Ltd. is a non-refundable trial fee of ₹999 plus 18% GST for SOLO, ₹1599 plus 18% GST for DUO, ₹1999 plus 18% GST for GROUP.
//                         </Text>
//                         <Text style={styles.noteText}>
//                             2. Once the payment is completed, please check your registered email ID for a copy of the registration form.
//                         </Text>
//                         <Text style={styles.noteText}>
//                             3. Trial details will be shared one week before the trials to your registered email ID.
//                         </Text>
//                     </View>
//
//                     <TouchableOpacity style={styles.checkboxRow} onPress={() => setAgree(!agree)}>
//                         <View style={[styles.checkbox, agree && styles.checkboxChecked]}>
//                             {agree && <Text style={styles.checkboxTick}>✓</Text>}
//                         </View>
//                         <Text style={styles.checkboxText}>I agree to the competition terms and conditions</Text>
//                     </TouchableOpacity>
//
//                     <Text style={styles.label}>REGISTRATION FEES</Text>
//                     <View style={styles.feeRow}>
//                         <Text style={styles.originalFee}>
//                             ₹ {(registrationFees * 1.3).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
//                         </Text>
//                         <Text style={styles.discountedFee}>
//                             ₹ {registrationFees.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
//                         </Text>
//                     </View>
//
//                     <TouchableOpacity style={styles.payButton} onPress={handlePay}>
//                         <Text style={styles.payText}>Pay</Text>
//                     </TouchableOpacity>
//                 </View>
//             </ScrollView>
//         </ImageBackground>
//     );
// };
//
// const styles = StyleSheet.create({
//     dropdown: {
//         backgroundColor: 'rgba(255, 255, 255, 0.05)',
//         borderColor: 'rgba(255, 255, 255, 0.1)',
//         marginTop: 15,
//     },
//     dropdownContainer: {
//         backgroundColor: 'rgba(0,0,0,1)',
//         borderColor: 'rgba(255, 255, 255, 0.1)',
//         marginTop: 16,
//     },
//     label: { color: '#aaa', fontSize: 13, marginTop: 30, marginBottom: 5 },
//     background: { flex: 1 },
//     container: { padding: 0, paddingBottom: 40,marginTop:30, },
//     backButton: {
//         width: 32,
//         height: 32,
//         marginTop: 20,
//         justifyContent: 'center',
//         alignItems: 'center',
//         marginBottom: 10,
//     },
//     backText: { color: '#fff', fontSize: 24 },
//     title: { fontSize: 22, fontWeight: '700', color: '#fff', alignSelf: 'center', marginBottom: 20 },
//
//     input: {
//         backgroundColor: 'rgba(255, 255, 255, 0.05)',
//         borderRadius: 8,
//         color: '#fff',
//         padding: 15,
//         marginTop: 15,
//         fontSize: 14,
//         borderWidth: 1,
//         borderColor: 'rgba(255, 255, 255, 0.1)',
//     },
//     halfInput: { flex: 1, marginRight: 10 },
//     dobInput: { flex: 1, marginRight: 10 },
//     row: { flexDirection: 'row', justifyContent: 'space-between' },
//     radioButton: {
//         flex: 1,
//         marginRight: 10,
//         borderRadius: 20,
//         paddingVertical: 10,
//         backgroundColor: 'transparent',
//         borderWidth: 1,
//         borderColor: '#aaa',
//         alignItems: 'center',
//     },
//     radioSelected: { backgroundColor: '#FFD700', borderColor: '#FFD700' },
//     radioText: { color: '#fff', fontSize: 12 },
//     noteBox: {
//         backgroundColor: 'rgba(255, 255, 255, 0.05)',
//         borderRadius: 10,
//         padding: 12,
//         marginTop: 5,
//         borderWidth: 1,
//         borderColor: '#333',
//     },
//     noteTitle: { color: '#fff', fontWeight: 'bold', marginBottom: 10 },
//     noteText: { color: '#aaa', fontSize: 12, marginBottom: 10 },
//     checkboxRow: { flexDirection: 'row', alignItems: 'center', marginTop: 15 },
//     checkbox: {
//         width: 18,
//         height: 18,
//         borderRadius: 4,
//         borderWidth: 1,
//         borderColor: '#999',
//         justifyContent: 'center',
//         alignItems: 'center',
//         marginRight: 10,
//     },
//     checkboxChecked: { backgroundColor: '#FFD700', borderColor: '#FFD700' },
//     checkboxTick: { fontSize: 12, color: '#000' },
//     checkboxText: { color: '#ccc', fontSize: 13, flex: 1 },
//     feeRow: {
//         flexDirection: 'row',
//         alignItems: 'center',
//         gap: 10,
//         marginTop: 4,
//     },
//     originalFee: {
//         color: '#aaa',
//         fontSize: 16,
//         textDecorationLine: 'line-through',
//         marginRight: 10,
//     },
//     discountedFee: {
//         color: '#fff',
//         fontSize: 20,
//         fontWeight: 'bold',
//     },
//     payButton: {
//         backgroundColor: '#FFBF00',
//         borderRadius: 10,
//         paddingVertical: 14,
//         alignItems: 'center',
//         marginTop: 20,
//         shadowColor: '#000',
//         shadowOpacity: 0.4,
//         shadowOffset: { width: 0, height: 2 },
//         shadowRadius: 4,
//         elevation: 3,
//     },
//     payText: { color: '#000', fontWeight: '700', fontSize: 16 },
//
// });
//
// export default RegisterScreen;






import React, { useState, useEffect } from 'react';
import {
    View,
    Text,
    TextInput,
    ScrollView,
    TouchableOpacity,
    StyleSheet,
    ImageBackground,
    Alert,
    Platform,
} from 'react-native';
import { useRouter } from 'expo-router';
import * as WebBrowser from 'expo-web-browser';
import DropDownPicker from 'react-native-dropdown-picker';
import Icon from 'react-native-vector-icons/FontAwesome';
import { useLocationStore } from '../../stores/locationStore';
import { databases, DATABASE_ID, COLLECTION_ID } from '@/utils/appwrite-register-iamdance';
import { ID } from 'appwrite';
import { FontAwesome } from '@expo/vector-icons';
import DateTimePicker from "@react-native-community/datetimepicker";

const razorpayLinks = {
    SOLO: 'https://rzp.io/rzp/Gbu54Ut',
    DUO: 'https://rzp.io/rzp/FU1AAyh',
    GROUP: 'https://rzp.io/rzp/zzGKUFGT',
};

const RegisterScreen = () => {
    const [registrationNumber, setRegistrationNumber] = useState('');
    const [danceCategory, setDanceCategory] = useState('');
    const [danceStyle, setDanceStyle] = useState(null);
    const [agree, setAgree] = useState(false);
    const [registrationFees, setRegistrationFees] = useState(0);
    const [fullName, setFullName] = useState('');
    const [dobDay, setDobDay] = useState('');
    const [dobMonth, setDobMonth] = useState('');
    const [dobYear, setDobYear] = useState('');

    const [aadhaar, setAadhaar] = useState('');
    const [email, setEmail] = useState('');
    const [phone, setPhone] = useState('');
    const [street, setStreet] = useState('');
    const [cityAddress, setCityAddress] = useState('');
    const [postalCode, setPostalCode] = useState('');
    const [stateAddress, setStateAddress] = useState('');
    const [countryAddress, setCountryAddress] = useState('');
    const [referralCode, setReferralCode] = useState('');

    const [manualCountry, setManualCountry] = useState('');
    const [manualRegion, setManualRegion] = useState('');

    const router = useRouter();
    const { country, region } = useLocationStore();

    const isUnknownCountry = !country || country.toLowerCase() === 'unknown country';
    const isUnknownRegion = !region || region.toLowerCase() === 'unknown region';

    const [showDatePicker, setShowDatePicker] = useState(false);
    const [selectedDate, setSelectedDate] = useState<Date | null>(null);

    useEffect(() => {
        if (!isUnknownRegion) setStateAddress(region);
        if (!isUnknownCountry) setCountryAddress(country);
    }, [country, region]);

    useEffect(() => {
        const resolvedCountry = isUnknownCountry ? manualCountry.toLowerCase() : (country || '').toLowerCase();

        const generateRegistrationNumber = () => {
            let prefix = 'IADAE';

            if (resolvedCountry === 'india') {
                prefix = 'IADIN';
            } else if (resolvedCountry === 'uae' || resolvedCountry === 'united arab emirates') {
                prefix = 'IADUAE';
            }

            const random = Math.floor(100000 + Math.random() * 900000);
            return `${prefix}${random}`;
        };

        setRegistrationNumber(generateRegistrationNumber());
    }, [country, manualCountry, isUnknownCountry]);

    useEffect(() => {
        if (danceCategory === 'SOLO') setRegistrationFees(1178.82);
        else if (danceCategory === 'DUO') setRegistrationFees(1886.82);
        else if (danceCategory === 'GROUP') setRegistrationFees(2358.82);
        else setRegistrationFees(0);
    }, [danceCategory]);

    const handlePay = async () => {
        if (!dobDay || !dobMonth || !dobYear || isNaN(+dobDay) || isNaN(+dobMonth) || isNaN(+dobYear)) {
            Alert.alert('Invalid DOB', 'Please enter a valid Date of Birth.');
            return;
        }

        const dob = `${dobYear}-${dobMonth.padStart(2, '0')}-${dobDay.padStart(2, '0')}`;

        const resolvedCountry = (isUnknownCountry ? manualCountry : countryAddress).toLowerCase();
        const resolvedRegion = isUnknownRegion ? manualRegion : stateAddress;

        const formData = {
            Register_Number: registrationNumber,
            Full_Name: fullName,
            DOB: dob,
            adhaar_num: aadhaar,
            Email: email,
            Phone: phone,
            reffer_code: referralCode,
            dance_style: danceStyle,
            dance_cat: danceCategory,
            street_address: street,
            city: cityAddress,
            postal_code: postalCode,
            state: resolvedRegion,
            country: resolvedCountry,
        };

        if (!agree) {
            Alert.alert('Terms Required', 'You must agree to the terms and conditions to proceed.');
            return;
        }

        if (!danceCategory) {
            Alert.alert('Select Category', 'Please select a dance category to proceed.');
            return;
        }

        try {
            await databases.createDocument(DATABASE_ID, COLLECTION_ID, ID.unique(), formData);

            if (resolvedCountry === 'india') {
                await WebBrowser.openBrowserAsync(razorpayLinks[danceCategory]);
            } else {
                Alert.alert('Unsupported Region', 'Payment is only supported for India.');
            }
        } catch (error) {
            console.error(error);
            Alert.alert('Error', 'Failed to submit registration. Please try again.');
        }
    };

    const danceStyles = [
        { label: 'Hip Hop', value: 'hiphop' },
        { label: 'Breaking', value: 'breaking' },
        { label: 'Popping', value: 'popping' },
        { label: 'Locking', value: 'locking' },
        { label: 'Krump', value: 'krump' },
        { label: 'Waacking', value: 'waacking' },
        { label: 'House', value: 'house' },
        { label: 'Litefeet', value: 'litefeet' },
        { label: 'Dancehall', value: 'dancehall' },
        { label: 'Bharatanatyam', value: 'bharatanatyam' },
        { label: 'Kathak', value: 'kathak' },
        { label: 'Odissi', value: 'odissi' },
        { label: 'Kuchipudi', value: 'kuchipudi' },
        { label: 'Mohiniyattam', value: 'mohiniyattam' },
        { label: 'Manipuri', value: 'manipuri' },
        { label: 'Kathakali', value: 'kathakali' },
        { label: 'Sattriya', value: 'sattriya' },
        { label: 'Jazz', value: 'jazz' },
        { label: 'Contemporary', value: 'contemporary' },
        { label: 'Ballet', value: 'ballet' },
        { label: 'Freestyle', value: 'freestyle' },
        { label: 'Bollywood', value: 'bollywood' },
        { label: 'Semi-Classical', value: 'semiclassical' },
        { label: 'Lyrical Hip Hop', value: 'lyricalhiphop' },
        { label: 'Jazz Funk', value: 'jazzfunk' },
        { label: 'Latin (Salsa, Bachata)', value: 'latin' },
        { label: 'Afro', value: 'afro' },
        { label: 'Urban Choreography', value: 'urban' },
        { label: 'Folk (Garba, Bhangra, Lavani, Kalbelia)', value: 'folk' },
        { label: 'Tribal Fusion', value: 'tribalfusion' },
        { label: 'Experimental Movement', value: 'experimental' },
    ];

    const [open, setOpen] = useState(false);
    const [items, setItems] = useState(danceStyles);

    return (
        <ImageBackground source={require('../../assets/images/bg.webp')} style={styles.background}>
            <ScrollView contentContainerStyle={styles.container} showsVerticalScrollIndicator={false}>
                <View style={{ flex: 1, padding: 15 }}>
                    <TouchableOpacity onPress={() => router.back()} >
                        <FontAwesome name="arrow-left" size={20} color="#fff" />
                    </TouchableOpacity>

                    <Text style={styles.title}>Register</Text>

                    <Text style={styles.label}>REGISTRATION NUMBER</Text>
                    <TextInput
                        style={[styles.input, { backgroundColor: 'rgba(255,255,255,0.1)' }]}
                        value={registrationNumber}
                        editable={false}
                        selectTextOnFocus={false}
                        placeholderTextColor="#888"
                    />

                    <Text style={styles.label}>FULL NAME</Text>
                    <TextInput style={styles.input} placeholder="Full Name" placeholderTextColor="#888" value={fullName} onChangeText={setFullName} />


                    <Text style={styles.label}>DATE-OF-BIRTH</Text>
                    <TouchableOpacity onPress={() => setShowDatePicker(true)}>
                        <View style={[styles.input, { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }]}>
                            <Text style={{ color: dobDay ? '#fff' : '#888' }}>
                                {dobDay && dobMonth && dobYear
                                    ? `${dobDay.padStart(2, '0')}-${dobMonth.padStart(2, '0')}-${dobYear}`
                                    : 'Select Date of Birth'}
                            </Text>
                            <FontAwesome name="calendar" size={18} color="#fff" />
                        </View>
                    </TouchableOpacity>

                    {showDatePicker && (
                        <DateTimePicker
                            testID="dateTimePicker"
                            value={selectedDate || new Date(2005, 0, 1)}
                            mode="date"
                            display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                            maximumDate={new Date()}
                            onChange={(event, date) => {
                                setShowDatePicker(false);
                                if (date) {
                                    const day = `${date.getDate()}`;
                                    const month = `${date.getMonth() + 1}`;
                                    const year = `${date.getFullYear()}`;

                                    setSelectedDate(date);
                                    setDobDay(day);
                                    setDobMonth(month);
                                    setDobYear(year);
                                }
                            }}
                        />
                    )}

                    <Text style={styles.label}>ADDRESS</Text>
                    <TextInput style={styles.input} placeholder="Street Address" placeholderTextColor="#888" value={street} onChangeText={setStreet} />

                    <View style={styles.row}>
                        <TextInput style={[styles.input, styles.halfInput]} placeholder="City" value={cityAddress} onChangeText={setCityAddress} placeholderTextColor="#888" />

                        {isUnknownRegion ? (
                            <TextInput
                                style={[styles.input, styles.halfInput]}
                                placeholder="State"
                                placeholderTextColor="#888"
                                value={manualRegion}
                                onChangeText={setManualRegion}
                            />
                        ) : (
                            <TextInput
                                style={[styles.input, styles.halfInput]}
                                value={region || ''}
                                editable={false}
                                placeholder="State"
                            />
                        )}
                    </View>

                    <View style={styles.row}>
                        <TextInput
                            style={[styles.input, styles.halfInput]}
                            placeholder="Postal Code"
                            value={postalCode}
                            onChangeText={setPostalCode}
                            placeholderTextColor="#888"
                        />

                        {isUnknownCountry ? (
                            <TextInput
                                style={[styles.input, styles.halfInput]}
                                placeholder="Country"
                                placeholderTextColor="#888"
                                value={manualCountry}
                                onChangeText={setManualCountry}
                            />
                        ) : (
                            <TextInput
                                style={[styles.input, styles.halfInput]}
                                value={country || ''}
                                editable={false}
                                placeholder="Country"
                            />
                        )}
                    </View>

                    <Text style={styles.label}>ADHAAR CARD NUMBER (No Spaces)</Text>
                    <TextInput
                        style={styles.input}
                        placeholder="XXXXXXXXXXXX"
                        value={aadhaar}
                        onChangeText={setAadhaar}
                        placeholderTextColor="#888"
                        keyboardType="numeric"
                    />

                    <View style={styles.row}>
                        <TextInput style={[styles.input, styles.halfInput]} placeholder="Email ID" placeholderTextColor="#888" value={email} onChangeText={setEmail}/>
                        <TextInput style={[styles.input, styles.halfInput]} placeholder="Phone No." placeholderTextColor="#888" keyboardType="phone-pad" value={phone} onChangeText={setPhone}/>
                    </View>

                    <Text style={styles.label}>DANCE CATEGORY</Text>
                    <View style={styles.row}>
                        {['SOLO', 'DUO', 'GROUP'].map((type) => (
                            <TouchableOpacity
                                key={type}
                                style={[styles.radioButton, danceCategory === type && styles.radioSelected]}
                                onPress={() => setDanceCategory(type)}
                            >
                                <Text style={[styles.radioText, danceCategory === type && { color: '#000' }]}>{type}</Text>
                            </TouchableOpacity>
                        ))}
                    </View>

                    <Text style={styles.label}>SELECT DANCE STYLE</Text>
                    <DropDownPicker
                        open={open}
                        setOpen={setOpen}
                        value={danceStyle}
                        setValue={setDanceStyle}
                        items={items}
                        setItems={setItems}
                        placeholder="Select Dance Style"
                        style={styles.dropdown}
                        dropDownContainerStyle={styles.dropdownContainer}
                        textStyle={{ color: '#fff' }}
                        listMode="SCROLLVIEW"
                        ArrowDownIconComponent={() => <Icon name="chevron-down" size={14} color="#999" />}
                        ArrowUpIconComponent={() => <Icon name="chevron-up" size={14} color="#999" />}
                    />

                    <Text style={styles.label}>REFERRAL CODE (Optional)</Text>
                    <TextInput style={styles.input} placeholder="Code" placeholderTextColor="#888" value={referralCode} onChangeText={setReferralCode}/>

                    <Text style={styles.label}>COMPETITION TERMS AND SERVICES</Text>
                    <View style={styles.noteBox}>
                        <Text style={styles.noteTitle}>NOTE :-</Text>
                        <Text style={styles.noteText}>
                            1. The registration fee for participation in the I AM DANCE trials conducted by Significant Sports and Entertainment Pvt. Ltd. is a non-refundable trial fee of ₹999 plus 18% GST for SOLO, ₹1599 plus 18% GST for DUO, ₹1999 plus 18% GST for GROUP.
                        </Text>
                        <Text style={styles.noteText}>
                            2. Once the payment is completed, please check your registered email ID for a copy of the registration form.
                        </Text>
                        <Text style={styles.noteText}>
                            3. Trial details will be shared one week before the trials to your registered email ID.
                        </Text>
                    </View>

                    <TouchableOpacity style={styles.checkboxRow} onPress={() => setAgree(!agree)}>
                        <View style={[styles.checkbox, agree && styles.checkboxChecked]}>
                            {agree && <Text style={styles.checkboxTick}>✓</Text>}
                        </View>
                        <Text style={styles.checkboxText}>I agree to the competition terms and conditions</Text>
                    </TouchableOpacity>

                    <Text style={styles.label}>REGISTRATION FEES</Text>
                    <View style={styles.feeRow}>
                        <Text style={styles.originalFee}>
                            ₹ {(registrationFees * 1.3).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                        </Text>
                        <Text style={styles.discountedFee}>
                            ₹ {registrationFees.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                        </Text>
                    </View>

                    <TouchableOpacity style={styles.payButton} onPress={handlePay}>
                        <Text style={styles.payText}>Pay</Text>
                    </TouchableOpacity>
                </View>

            </ScrollView>
        </ImageBackground>
    );
};

const styles = StyleSheet.create({
    dropdown: {
        backgroundColor: 'rgba(255, 255, 255, 0.05)',
        borderColor: 'rgba(255, 255, 255, 0.1)',
        marginTop: 15,
    },
    dropdownContainer: {
        backgroundColor: 'rgba(0,0,0,1)',
        borderColor: 'rgba(255, 255, 255, 0.1)',
        marginTop: 16,
    },
    label: { color: '#aaa', fontSize: 13, marginTop: 30, marginBottom: 5 },
    background: { flex: 1 },
    container: { padding: 0, paddingBottom: 40,marginTop:30, },
    backButton: {
        width: 32,
        height: 32,
        marginTop: 20,
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 10,
    },
    backText: { color: '#fff', fontSize: 24 },
    title: { fontSize: 22, fontWeight: '700', color: '#fff', alignSelf: 'center', marginBottom: 20 },

    input: {
        backgroundColor: 'rgba(255, 255, 255, 0.05)',
        borderRadius: 8,
        color: '#fff',
        padding: 15,
        marginTop: 15,
        fontSize: 14,
        borderWidth: 1,
        borderColor: 'rgba(255, 255, 255, 0.1)',
    },
    halfInput: { flex: 1, marginRight: 10 },
    dobInput: { flex: 1, marginRight: 10 },
    row: { flexDirection: 'row', justifyContent: 'space-between' },
    radioButton: {
        flex: 1,
        marginRight: 10,
        borderRadius: 20,
        paddingVertical: 10,
        backgroundColor: 'transparent',
        borderWidth: 1,
        borderColor: '#aaa',
        alignItems: 'center',
    },
    radioSelected: { backgroundColor: '#FFD700', borderColor: '#FFD700' },
    radioText: { color: '#fff', fontSize: 12 },
    noteBox: {
        backgroundColor: 'rgba(255, 255, 255, 0.05)',
        borderRadius: 10,
        padding: 12,
        marginTop: 5,
        borderWidth: 1,
        borderColor: '#333',
    },
    noteTitle: { color: '#fff', fontWeight: 'bold', marginBottom: 10 },
    noteText: { color: '#aaa', fontSize: 12, marginBottom: 10 },
    checkboxRow: { flexDirection: 'row', alignItems: 'center', marginTop: 15 },
    checkbox: {
        width: 18,
        height: 18,
        borderRadius: 4,
        borderWidth: 1,
        borderColor: '#999',
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: 10,
    },
    checkboxChecked: { backgroundColor: '#FFD700', borderColor: '#FFD700' },
    checkboxTick: { fontSize: 12, color: '#000' },
    checkboxText: { color: '#ccc', fontSize: 13, flex: 1 },
    feeRow: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 10,
        marginTop: 4,
    },
    originalFee: {
        color: '#aaa',
        fontSize: 16,
        textDecorationLine: 'line-through',
        marginRight: 10,
    },
    discountedFee: {
        color: '#fff',
        fontSize: 20,
        fontWeight: 'bold',
    },
    payButton: {
        backgroundColor: '#FFBF00',
        borderRadius: 10,
        paddingVertical: 14,
        alignItems: 'center',
        marginTop: 20,
        shadowColor: '#000',
        shadowOpacity: 0.4,
        shadowOffset: { width: 0, height: 2 },
        shadowRadius: 4,
        elevation: 3,
    },
    payText: { color: '#000', fontWeight: '700', fontSize: 16 },
});

export default RegisterScreen;



// import React, { useState, useEffect } from 'react';
// import {
//     View,
//     Text,
//     TextInput,
//     ScrollView,
//     TouchableOpacity,
//     StyleSheet,
//     ImageBackground,
//     Alert,
//     Platform,
// } from 'react-native';
// import { useRouter } from 'expo-router';
// import * as WebBrowser from 'expo-web-browser';
// import DropDownPicker from 'react-native-dropdown-picker';
// import Icon from 'react-native-vector-icons/FontAwesome';
// import { useLocationStore } from '../../stores/locationStore';
// import { databases, DATABASE_ID, COLLECTION_ID } from '@/utils/appwrite-register-iamdance';
// import { ID } from 'appwrite';
// import { FontAwesome } from '@expo/vector-icons';
// import DateTimePicker from "@react-native-community/datetimepicker";
//
// const razorpayLinks = {
//     SOLO: 'https://rzp.io/rzp/Gbu54Ut',
//     DUO: 'https://rzp.io/rzp/FU1AAyh',
//     GROUP: 'https://rzp.io/rzp/zzGKUFGT',
// };
//
// const RegisterScreen = () => {
//     const [registrationNumber, setRegistrationNumber] = useState('');
//     const [danceCategory, setDanceCategory] = useState('');
//     const [danceStyle, setDanceStyle] = useState(null);
//     const [agree, setAgree] = useState(false);
//     const [registrationFees, setRegistrationFees] = useState(0);
//     const [fullName, setFullName] = useState('');
//     const [dobDay, setDobDay] = useState('');
//     const [dobMonth, setDobMonth] = useState('');
//     const [dobYear, setDobYear] = useState('');
//
//     const [aadhaar, setAadhaar] = useState('');
//     const [email, setEmail] = useState('');
//     const [phone, setPhone] = useState('');
//     const [street, setStreet] = useState('');
//     const [cityAddress, setCityAddress] = useState('');
//     const [postalCode, setPostalCode] = useState('');
//     const [stateAddress, setStateAddress] = useState('');
//     const [countryAddress, setCountryAddress] = useState('');
//     const [referralCode, setReferralCode] = useState('');
//
//     const [manualCountry, setManualCountry] = useState('');
//     const [manualRegion, setManualRegion] = useState('');
//
//     const router = useRouter();
//     const { country, region } = useLocationStore();
//
//     const isUnknownCountry = !country || country.toLowerCase() === 'unknown country';
//     const isUnknownRegion = !region || region.toLowerCase() === 'unknown region';
//
//     const [showDatePicker, setShowDatePicker] = useState(false);
//     const [selectedDate, setSelectedDate] = useState<Date | null>(null);
//
//     const [isIndia, setIsIndia] = useState(false);
//
//     useEffect(() => {
//         if (!isUnknownRegion) setStateAddress(region);
//         if (!isUnknownCountry) setCountryAddress(country);
//
//         // Check if country is India
//         const currentCountry = isUnknownCountry ? manualCountry.toLowerCase() : (country || '').toLowerCase();
//         setIsIndia(currentCountry === 'india');
//     }, [country, region, manualCountry, isUnknownCountry]);
//
//     useEffect(() => {
//         const resolvedCountry = isUnknownCountry ? manualCountry.toLowerCase() : (country || '').toLowerCase();
//
//         const generateRegistrationNumber = () => {
//             let prefix = 'IADAE';
//
//             if (resolvedCountry === 'india') {
//                 prefix = 'IADIN';
//             } else if (resolvedCountry === 'uae' || resolvedCountry === 'united arab emirates') {
//                 prefix = 'IADUAE';
//             }
//
//             const random = Math.floor(100000 + Math.random() * 900000);
//             return `${prefix}${random}`;
//         };
//
//         setRegistrationNumber(generateRegistrationNumber());
//     }, [country, manualCountry, isUnknownCountry]);
//
//     useEffect(() => {
//         if (danceCategory === 'SOLO') setRegistrationFees(1178.82);
//         else if (danceCategory === 'DUO') setRegistrationFees(1886.82);
//         else if (danceCategory === 'GROUP') setRegistrationFees(2358.82);
//         else setRegistrationFees(0);
//     }, [danceCategory]);
//
//     const handlePay = async () => {
//         if (!isIndia) {
//             Alert.alert('Registration Closed', 'Registrations are currently only open for India.');
//             return;
//         }
//
//         if (!dobDay || !dobMonth || !dobYear || isNaN(+dobDay) || isNaN(+dobMonth) || isNaN(+dobYear)) {
//             Alert.alert('Invalid DOB', 'Please enter a valid Date of Birth.');
//             return;
//         }
//
//         const dob = `${dobYear}-${dobMonth.padStart(2, '0')}-${dobDay.padStart(2, '0')}`;
//
//         const resolvedCountry = (isUnknownCountry ? manualCountry : countryAddress).toLowerCase();
//         const resolvedRegion = isUnknownRegion ? manualRegion : stateAddress;
//
//         const formData = {
//             Register_Number: registrationNumber,
//             Full_Name: fullName,
//             DOB: dob,
//             adhaar_num: aadhaar,
//             Email: email,
//             Phone: phone,
//             reffer_code: referralCode,
//             dance_style: danceStyle,
//             dance_cat: danceCategory,
//             street_address: street,
//             city: cityAddress,
//             postal_code: postalCode,
//             state: resolvedRegion,
//             country: resolvedCountry,
//         };
//
//         if (!agree) {
//             Alert.alert('Terms Required', 'You must agree to the terms and conditions to proceed.');
//             return;
//         }
//
//         if (!danceCategory) {
//             Alert.alert('Select Category', 'Please select a dance category to proceed.');
//             return;
//         }
//
//         try {
//             await databases.createDocument(DATABASE_ID, COLLECTION_ID, ID.unique(), formData);
//             await WebBrowser.openBrowserAsync(razorpayLinks[danceCategory]);
//         } catch (error) {
//             console.error(error);
//             Alert.alert('Error', 'Failed to submit registration. Please try again.');
//         }
//     };
//
//     const danceStyles = [
//         { label: 'Hip Hop', value: 'hiphop' },
//         { label: 'Breaking', value: 'breaking' },
//         { label: 'Popping', value: 'popping' },
//         { label: 'Locking', value: 'locking' },
//         { label: 'Krump', value: 'krump' },
//         { label: 'Waacking', value: 'waacking' },
//         { label: 'House', value: 'house' },
//         { label: 'Litefeet', value: 'litefeet' },
//         { label: 'Dancehall', value: 'dancehall' },
//         { label: 'Bharatanatyam', value: 'bharatanatyam' },
//         { label: 'Kathak', value: 'kathak' },
//         { label: 'Odissi', value: 'odissi' },
//         { label: 'Kuchipudi', value: 'kuchipudi' },
//         { label: 'Mohiniyattam', value: 'mohiniyattam' },
//         { label: 'Manipuri', value: 'manipuri' },
//         { label: 'Kathakali', value: 'kathakali' },
//         { label: 'Sattriya', value: 'sattriya' },
//         { label: 'Jazz', value: 'jazz' },
//         { label: 'Contemporary', value: 'contemporary' },
//         { label: 'Ballet', value: 'ballet' },
//         { label: 'Freestyle', value: 'freestyle' },
//         { label: 'Bollywood', value: 'bollywood' },
//         { label: 'Semi-Classical', value: 'semiclassical' },
//         { label: 'Lyrical Hip Hop', value: 'lyricalhiphop' },
//         { label: 'Jazz Funk', value: 'jazzfunk' },
//         { label: 'Latin (Salsa, Bachata)', value: 'latin' },
//         { label: 'Afro', value: 'afro' },
//         { label: 'Urban Choreography', value: 'urban' },
//         { label: 'Folk (Garba, Bhangra, Lavani, Kalbelia)', value: 'folk' },
//         { label: 'Tribal Fusion', value: 'tribalfusion' },
//         { label: 'Experimental Movement', value: 'experimental' },
//     ];
//
//     const [open, setOpen] = useState(false);
//     const [items, setItems] = useState(danceStyles);
//
//     const getInputStyle = () => {
//         return isIndia ? styles.input : [styles.input, styles.disabledInput];
//     };
//
//     return (
//         <ImageBackground source={require('../../assets/images/bg.webp')} style={styles.background}>
//             <ScrollView contentContainerStyle={styles.container} showsVerticalScrollIndicator={false}>
//                 <View style={{ flex: 1, padding: 15 }}>
//                     <TouchableOpacity onPress={() => router.back()} >
//                         <FontAwesome name="arrow-left" size={20} color="#fff" />
//                     </TouchableOpacity>
//
//                     <Text style={styles.title}>Register</Text>
//
//                     {!isIndia && (
//                         <View style={styles.noticeBox}>
//                             <Text style={styles.noticeText}>
//                                 Registrations are currently only open for India
//                             </Text>
//                         </View>
//                     )}
//
//                     <Text style={styles.label}>REGISTRATION NUMBER</Text>
//                     <TextInput
//                         style={[styles.input, { backgroundColor: 'rgba(255,255,255,0.1)' }]}
//                         value={registrationNumber}
//                         editable={false}
//                         selectTextOnFocus={false}
//                         placeholderTextColor="#888"
//                     />
//
//                     <Text style={styles.label}>FULL NAME</Text>
//                     <TextInput
//                         style={getInputStyle()}
//                         placeholder="Full Name"
//                         placeholderTextColor="#888"
//                         value={fullName}
//                         onChangeText={setFullName}
//                         editable={isIndia}
//                     />
//
//                     <Text style={styles.label}>DATE-OF-BIRTH</Text>
//                     <TouchableOpacity onPress={() => isIndia && setShowDatePicker(true)}>
//                         <View style={[getInputStyle(), { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }]}>
//                             <Text style={{ color: dobDay ? '#fff' : '#888' }}>
//                                 {dobDay && dobMonth && dobYear
//                                     ? `${dobDay.padStart(2, '0')}-${dobMonth.padStart(2, '0')}-${dobYear}`
//                                     : 'Select Date of Birth'}
//                             </Text>
//                             <FontAwesome name="calendar" size={18} color={isIndia ? "#fff" : "#555"} />
//                         </View>
//                     </TouchableOpacity>
//
//                     {showDatePicker && (
//                         <DateTimePicker
//                             testID="dateTimePicker"
//                             value={selectedDate || new Date(2005, 0, 1)}
//                             mode="date"
//                             display={Platform.OS === 'ios' ? 'spinner' : 'default'}
//                             maximumDate={new Date()}
//                             onChange={(event, date) => {
//                                 setShowDatePicker(false);
//                                 if (date) {
//                                     const day = `${date.getDate()}`;
//                                     const month = `${date.getMonth() + 1}`;
//                                     const year = `${date.getFullYear()}`;
//
//                                     setSelectedDate(date);
//                                     setDobDay(day);
//                                     setDobMonth(month);
//                                     setDobYear(year);
//                                 }
//                             }}
//                         />
//                     )}
//
//                     <Text style={styles.label}>ADDRESS</Text>
//                     <TextInput
//                         style={getInputStyle()}
//                         placeholder="Street Address"
//                         placeholderTextColor="#888"
//                         value={street}
//                         onChangeText={setStreet}
//                         editable={isIndia}
//                     />
//
//                     <View style={styles.row}>
//                         <TextInput
//                             style={[getInputStyle(), styles.halfInput]}
//                             placeholder="City"
//                             value={cityAddress}
//                             onChangeText={setCityAddress}
//                             placeholderTextColor="#888"
//                             editable={isIndia}
//                         />
//
//                         {isUnknownRegion ? (
//                             <TextInput
//                                 style={[getInputStyle(), styles.halfInput]}
//                                 placeholder="State"
//                                 placeholderTextColor="#888"
//                                 value={isIndia ? manualRegion : (region || '')}
//                                 onChangeText={setManualRegion}
//                                 editable={isIndia}
//                             />
//                         ) : (
//                             <TextInput
//                                 style={[getInputStyle(), styles.halfInput]}
//                                 value={region || ''}
//                                 editable={false}
//                                 placeholder="State"
//                             />
//                         )}
//                     </View>
//
//                     <View style={styles.row}>
//                         <TextInput
//                             style={[getInputStyle(), styles.halfInput]}
//                             placeholder="Postal Code"
//                             value={postalCode}
//                             onChangeText={setPostalCode}
//                             placeholderTextColor="#888"
//                             editable={isIndia}
//                         />
//
//                         {isUnknownCountry ? (
//                             <TextInput
//                                 style={[getInputStyle(), styles.halfInput]}
//                                 placeholder="Country"
//                                 placeholderTextColor="#888"
//                                 value={isIndia ? manualCountry : (country || '')}
//                                 onChangeText={setManualCountry}
//                                 editable={isIndia}
//                             />
//                         ) : (
//                             <TextInput
//                                 style={[getInputStyle(), styles.halfInput]}
//                                 value={country || ''}
//                                 editable={false}
//                                 placeholder="Country"
//                             />
//                         )}
//                     </View>
//
//                     <Text style={styles.label}>ADHAAR CARD NUMBER (No Spaces)</Text>
//                     <TextInput
//                         style={getInputStyle()}
//                         placeholder="XXXXXXXXXXXX"
//                         value={aadhaar}
//                         onChangeText={setAadhaar}
//                         placeholderTextColor="#888"
//                         keyboardType="numeric"
//                         editable={isIndia}
//                     />
//
//                     <View style={styles.row}>
//                         <TextInput
//                             style={[getInputStyle(), styles.halfInput]}
//                             placeholder="Email ID"
//                             placeholderTextColor="#888"
//                             value={email}
//                             onChangeText={setEmail}
//                             editable={isIndia}
//                         />
//                         <TextInput
//                             style={[getInputStyle(), styles.halfInput]}
//                             placeholder="Phone No."
//                             placeholderTextColor="#888"
//                             keyboardType="phone-pad"
//                             value={phone}
//                             onChangeText={setPhone}
//                             editable={isIndia}
//                         />
//                     </View>
//
//                     <Text style={styles.label}>DANCE CATEGORY</Text>
//                     <View style={styles.row}>
//                         {['SOLO', 'DUO', 'GROUP'].map((type) => (
//                             <TouchableOpacity
//                                 key={type}
//                                 style={[
//                                     styles.radioButton,
//                                     danceCategory === type && styles.radioSelected,
//                                     !isIndia && styles.disabledRadioButton
//                                 ]}
//                                 onPress={() => isIndia && setDanceCategory(type)}
//                                 disabled={!isIndia}
//                             >
//                                 <Text style={[
//                                     styles.radioText,
//                                     danceCategory === type && { color: '#000' },
//                                     !isIndia && { color: '#555' }
//                                 ]}>
//                                     {type}
//                                 </Text>
//                             </TouchableOpacity>
//                         ))}
//                     </View>
//
//                     <Text style={styles.label}>SELECT DANCE STYLE</Text>
//                     <DropDownPicker
//                         open={open}
//                         setOpen={setOpen}
//                         value={danceStyle}
//                         setValue={setDanceStyle}
//                         items={items}
//                         setItems={setItems}
//                         placeholder="Select Dance Style"
//                         style={isIndia ? styles.dropdown : [styles.dropdown, styles.disabledDropdown]}
//                         dropDownContainerStyle={isIndia ? styles.dropdownContainer : [styles.dropdownContainer, styles.disabledDropdownContainer]}
//                         textStyle={isIndia ? { color: '#fff' } : { color: '#555' }}
//                         listMode="SCROLLVIEW"
//                         ArrowDownIconComponent={() => <Icon name="chevron-down" size={14} color={isIndia ? "#999" : "#555"} />}
//                         ArrowUpIconComponent={() => <Icon name="chevron-up" size={14} color={isIndia ? "#999" : "#555"} />}
//                         disabled={!isIndia}
//                     />
//
//                     <Text style={styles.label}>REFERRAL CODE (Optional)</Text>
//                     <TextInput
//                         style={getInputStyle()}
//                         placeholder="Code"
//                         placeholderTextColor="#888"
//                         value={referralCode}
//                         onChangeText={setReferralCode}
//                         editable={isIndia}
//                     />
//
//                     <Text style={styles.label}>COMPETITION TERMS AND SERVICES</Text>
//                     <View style={styles.noteBox}>
//                         <Text style={styles.noteTitle}>NOTE :-</Text>
//                         <Text style={styles.noteText}>
//                             1. The registration fee for participation in the I AM DANCE trials conducted by Significant Sports and Entertainment Pvt. Ltd. is a non-refundable trial fee of ₹999 plus 18% GST for SOLO, ₹1599 plus 18% GST for DUO, ₹1999 plus 18% GST for GROUP.
//                         </Text>
//                         <Text style={styles.noteText}>
//                             2. Once the payment is completed, please check your registered email ID for a copy of the registration form.
//                         </Text>
//                         <Text style={styles.noteText}>
//                             3. Trial details will be shared one week before the trials to your registered email ID.
//                         </Text>
//                     </View>
//
//                     {isIndia && (
//                         <TouchableOpacity style={styles.checkboxRow} onPress={() => setAgree(!agree)}>
//                             <View style={[styles.checkbox, agree && styles.checkboxChecked]}>
//                                 {agree && <Text style={styles.checkboxTick}>✓</Text>}
//                             </View>
//                             <Text style={styles.checkboxText}>I agree to the competition terms and conditions</Text>
//                         </TouchableOpacity>
//                     )}
//
//                     {isIndia && (
//                         <>
//                             <Text style={styles.label}>REGISTRATION FEES</Text>
//                             <View style={styles.feeRow}>
//                                 <Text style={styles.originalFee}>
//                                     ₹ {(registrationFees * 1.3).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
//                                 </Text>
//                                 <Text style={styles.discountedFee}>
//                                     ₹ {registrationFees.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
//                                 </Text>
//                             </View>
//                         </>
//                     )}
//
//                     <TouchableOpacity
//                         style={[
//                             styles.payButton,
//                             !isIndia && styles.disabledPayButton
//                         ]}
//                         onPress={handlePay}
//                     >
//                         <Text style={styles.payText}>
//                             {isIndia ? 'Pay' : 'Registrations only opened for India'}
//                         </Text>
//                     </TouchableOpacity>
//                 </View>
//             </ScrollView>
//         </ImageBackground>
//     );
// };
//
// const styles = StyleSheet.create({
//     background: { flex: 1 },
//     container: { padding: 0, paddingBottom: 40, marginTop: 30 },
//     title: { fontSize: 22, fontWeight: '700', color: '#fff', alignSelf: 'center', marginBottom: 20 },
//     label: { color: '#aaa', fontSize: 13, marginTop: 30, marginBottom: 5 },
//     input: {
//         backgroundColor: 'rgba(255, 255, 255, 0.05)',
//         borderRadius: 8,
//         color: '#fff',
//         padding: 15,
//         marginTop: 15,
//         fontSize: 14,
//         borderWidth: 1,
//         borderColor: 'rgba(255, 255, 255, 0.1)',
//     },
//     disabledInput: {
//         backgroundColor: 'rgba(255, 255, 255, 0.02)',
//         borderColor: 'rgba(255, 255, 255, 0.05)',
//         color: '#555',
//     },
//     halfInput: { flex: 1, marginRight: 10 },
//     row: { flexDirection: 'row', justifyContent: 'space-between' },
//     radioButton: {
//         flex: 1,
//         marginRight: 10,
//         borderRadius: 20,
//         paddingVertical: 10,
//         backgroundColor: 'transparent',
//         borderWidth: 1,
//         borderColor: '#aaa',
//         alignItems: 'center',
//     },
//     disabledRadioButton: {
//         borderColor: '#555',
//     },
//     radioSelected: { backgroundColor: '#FFD700', borderColor: '#FFD700' },
//     radioText: { color: '#fff', fontSize: 12 },
//     noteBox: {
//         backgroundColor: 'rgba(255, 255, 255, 0.05)',
//         borderRadius: 10,
//         padding: 12,
//         marginTop: 5,
//         borderWidth: 1,
//         borderColor: '#333',
//     },
//     noticeBox: {
//         backgroundColor: 'rgba(255, 0, 0, 0.2)',
//         padding: 10,
//         borderRadius: 5,
//         marginBottom: 20,
//         borderWidth: 1,
//         borderColor: 'rgba(255, 0, 0, 0.5)',
//     },
//     noticeText: {
//         color: '#fff',
//         textAlign: 'center',
//     },
//     noteTitle: { color: '#fff', fontWeight: 'bold', marginBottom: 10 },
//     noteText: { color: '#aaa', fontSize: 12, marginBottom: 10 },
//     checkboxRow: { flexDirection: 'row', alignItems: 'center', marginTop: 15 },
//     checkbox: {
//         width: 18,
//         height: 18,
//         borderRadius: 4,
//         borderWidth: 1,
//         borderColor: '#999',
//         justifyContent: 'center',
//         alignItems: 'center',
//         marginRight: 10,
//     },
//     checkboxChecked: { backgroundColor: '#FFD700', borderColor: '#FFD700' },
//     checkboxTick: { fontSize: 12, color: '#000' },
//     checkboxText: { color: '#ccc', fontSize: 13, flex: 1 },
//     feeRow: {
//         flexDirection: 'row',
//         alignItems: 'center',
//         gap: 10,
//         marginTop: 4,
//     },
//     originalFee: {
//         color: '#aaa',
//         fontSize: 16,
//         textDecorationLine: 'line-through',
//         marginRight: 10,
//     },
//     discountedFee: {
//         color: '#fff',
//         fontSize: 20,
//         fontWeight: 'bold',
//     },
//     payButton: {
//         backgroundColor: '#FFBF00',
//         borderRadius: 10,
//         paddingVertical: 14,
//         alignItems: 'center',
//         marginTop: 20,
//         shadowColor: '#000',
//         shadowOpacity: 0.4,
//         shadowOffset: { width: 0, height: 2 },
//         shadowRadius: 4,
//         elevation: 3,
//     },
//     disabledPayButton: {
//         backgroundColor: '#555',
//     },
//     payText: { color: '#000', fontWeight: '700', fontSize: 16 },
//     dropdown: {
//         backgroundColor: 'rgba(255, 255, 255, 0.05)',
//         borderColor: 'rgba(255, 255, 255, 0.1)',
//         marginTop: 15,
//     },
//     disabledDropdown: {
//         backgroundColor: 'rgba(255, 255, 255, 0.02)',
//         borderColor: 'rgba(255, 255, 255, 0.05)',
//     },
//     dropdownContainer: {
//         backgroundColor: 'rgba(0,0,0,1)',
//         borderColor: 'rgba(255, 255, 255, 0.1)',
//         marginTop: 16,
//     },
//     disabledDropdownContainer: {
//         backgroundColor: 'rgba(20,20,20,1)',
//     },
// });
//
// export default RegisterScreen;




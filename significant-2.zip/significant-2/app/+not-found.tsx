// import { Link, Stack } from 'expo-router';
// import { StyleSheet } from 'react-native';
//
// import { ThemedText } from '@/components/ThemedText';
// import { ThemedView } from '@/components/ThemedView';
//
// export default function NotFoundScreen() {
//   return (
//     <>
//       <Stack.Screen options={{ title: 'Oops!' }} />
//       <ThemedView style={styles.container}>
//         <ThemedText type="title">This screen does not exist.</ThemedText>
//         <Link href="/" style={styles.link}>
//           <ThemedText type="link">Go to home screen!</ThemedText>
//         </Link>
//       </ThemedView>
//     </>
//   );
// }
//
// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     alignItems: 'center',
//     justifyContent: 'center',
//     padding: 20,
//   },
//   link: {
//     marginTop: 15,
//     paddingVertical: 15,
//   },
// });

import React, { useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Animated,
  Image,
  Easing,
} from 'react-native';
import { useRouter } from 'expo-router';

export default function NotFoundScreen() {
  const router = useRouter();

  const batRotate = useRef(new Animated.Value(0)).current;
  const ballTranslate = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    // Auto redirect after 2s
    const timeout = setTimeout(() => {
      router.replace('/');
    }, 2000);

    // Animate bat swing
    Animated.loop(
        Animated.sequence([
          Animated.timing(batRotate, {
            toValue: 1,
            duration: 300,
            useNativeDriver: true,
            easing: Easing.out(Easing.ease),
          }),
          Animated.timing(batRotate, {
            toValue: 0,
            duration: 300,
            useNativeDriver: true,
            easing: Easing.in(Easing.ease),
          }),
        ])
    ).start();

    // Animate ball motion
    Animated.loop(
        Animated.sequence([
          Animated.timing(ballTranslate, {
            toValue: 80,
            duration: 600,
            useNativeDriver: true,
          }),
          Animated.timing(ballTranslate, {
            toValue: 0,
            duration: 0,
            useNativeDriver: true,
          }),
        ])
    ).start();

    return () => clearTimeout(timeout);
  }, []);

  const batRotateInterpolate = batRotate.interpolate({
    inputRange: [0, 1],
    outputRange: ['-20deg', '20deg'],
  });

  return (
      <View style={styles.container}>
        <View style={styles.animationContainer}>
          <Animated.Image
              source={require('../assets/images/cricket-bat.png')} // 🔁 Use your own bat image
              style={[
                styles.bat,
                { transform: [{ rotate: batRotateInterpolate }] },
              ]}
              resizeMode="contain"
          />
          <Animated.Image
              source={require('../assets/images/cricket-ball.png')} // 🔁 Use your own ball image
              style={[
                styles.ball,
                { transform: [{ translateX: ballTranslate }] },
              ]}
              resizeMode="contain"
          />
        </View>
        <Text style={styles.text}>Just a moment...</Text>
      </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#121212',
    justifyContent: 'center',
    alignItems: 'center',
  },
  animationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    height: 100,
    marginBottom: 20,
  },
  bat: {
    width: 60,
    height: 120,
    marginRight: 10,
  },
  ball: {
    width: 20,
    height: 20,
  },
  text: {
    color: '#fff',
    fontSize: 16,
    marginTop: 16,
  },
});



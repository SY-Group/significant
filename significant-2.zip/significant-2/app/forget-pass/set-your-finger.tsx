import React from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    ImageBackground,
    Modal,
    Image,
} from 'react-native';
import { FontAwesome } from '@expo/vector-icons';

export default function FingerprintScreen() {
    return (
        <ImageBackground
            source={require('../../assets/images/bg.webp')} // Replace with your background image
            style={styles.background}
            resizeMode="cover"
        >
            <View style={styles.overlay} />

            {/* Back Button */}
            <TouchableOpacity style={styles.backButton}>
                <FontAwesome name="arrow-left" size={20} color="#fff" />
            </TouchableOpacity>

            {/* Title */}
            <Text style={styles.title}>Set Your Fingerprint</Text>
            <Text style={styles.subtitle}>
                Add a fingerprint to make your account more secure
            </Text>

            {/* Fingerprint Instructions */}
            <Text style={styles.instruction}>
                Please put your finger on the fingerprint scanner to get started
            </Text>

            {/* Footer Buttons */}
            <View style={styles.buttonContainer}>
                <TouchableOpacity style={styles.skipButton}>
                    <Text style={styles.skipButtonText}>Skip</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.continueButton}>
                    <Text style={styles.continueButtonText}>Continue</Text>
                </TouchableOpacity>
            </View>

            {/* Congratulation Modal */}
            <View style={styles.modalContainer}>
                <View style={styles.modal}>
                    <Image
                        source={require('../../assets/images/icon.png')} // Replace with your checkmark icon
                        style={styles.checkIcon}
                    />
                    <Text style={styles.modalTitle}>Congratulations!</Text>
                    <Text style={styles.modalMessage}>
                        Your account is already to use. You will be redirected to the Homepage in a few seconds.
                    </Text>
                </View>
            </View>
        </ImageBackground>
    );
}

const styles = StyleSheet.create({
    background: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    overlay: {
        ...StyleSheet.absoluteFillObject,
        backgroundColor: 'rgba(0, 0, 0, 0.6)',
    },
    backButton: {
        position: 'absolute',
        top: 50,
        left: 20,
        width: 40,
        height: 40,
        borderRadius: 20,
        backgroundColor: 'rgba(255, 255, 255, 0.1)',
        justifyContent: 'center',
        alignItems: 'center',
    },
    title: {
        fontSize: 22,
        fontWeight: '600',
        color: '#fff',
        textAlign: 'center',
        marginTop: 80,
    },
    subtitle: {
        fontSize: 14,
        color: '#aaa',
        textAlign: 'center',
        marginTop: 10,
        marginBottom: 80,
    },
    instruction: {
        fontSize: 14,
        color: '#aaa',
        textAlign: 'center',
        position: 'absolute',
        bottom: 100,
    },
    buttonContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        width: '80%',
        position: 'absolute',
        bottom: 40,
    },
    skipButton: {
        flex: 1,
        borderWidth: 1,
        borderColor: '#fff',
        paddingVertical: 15,
        marginRight: 10,
        borderRadius: 30,
        alignItems: 'center',
    },
    skipButtonText: {
        color: '#fff',
        fontWeight: '500',
        fontSize: 14,
    },
    continueButton: {
        flex: 1,
        backgroundColor: '#f90',
        paddingVertical: 15,
        marginLeft: 10,
        borderRadius: 30,
        alignItems: 'center',
    },
    continueButtonText: {
        color: '#fff',
        fontWeight: '500',
        fontSize: 14,
    },
    modalContainer: {
        position: 'absolute',
        top: '40%',
        width: '90%',
        alignSelf: 'center',
    },
    modal: {
        backgroundColor: '#1e1e1e',
        borderRadius: 20,
        padding: 20,
        alignItems: 'center',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 5 },
        shadowOpacity: 0.3,
        shadowRadius: 10,
    },
    checkIcon: {
        width: 50,
        height: 50,
        marginBottom: 10,
    },
    modalTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#fff',
        marginBottom: 10,
    },
    modalMessage: {
        fontSize: 14,
        color: '#aaa',
        textAlign: 'center',
    },
});

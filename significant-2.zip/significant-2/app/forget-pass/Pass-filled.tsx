// import React, { useState } from 'react';
// import {
//     View,
//     Text,
//     TextInput,
//     StyleSheet,
//     TouchableOpacity,
//     Image,
//     SafeAreaView,
// } from 'react-native';
// import Icon from 'react-native-vector-icons/FontAwesome';
// import MaterialIcon from 'react-native-vector-icons/MaterialCommunityIcons';
//
// const CreatePasswordScreen = () => {
//     const [showPassword1, setShowPassword1] = useState(false);
//     const [showPassword2, setShowPassword2] = useState(false);
//     const [remember, setRemember] = useState(false);
//
//     return (
//         <SafeAreaView style={styles.container}>
//             {/* Back Button */}
//             <TouchableOpacity style={styles.backButton}>
//                 <Icon name="arrow-left" size={20} color="#fff" />
//             </TouchableOpacity>
//
//             {/* Title */}
//             <Text style={styles.title}>Create New Password</Text>
//
//             {/* Illustration */}
//             <Image
//                 source={require('../../assets/images/enter-password.webp')} // replace with your local image
//                 style={styles.image}
//                 resizeMode="contain"
//             />
//
//             {/* Password tooltips */}
//             <View style={styles.tooltipRow}>
//                 <Icon name="check-circle" size={14} color="lightgreen" />
//                 <Text style={styles.tooltipText}>Cannot contain your name or email address</Text>
//             </View>
//             <View style={styles.tooltipRow}>
//                 <Icon name="check-circle" size={14} color="lightgreen" />
//                 <Text style={styles.tooltipText}>At least 8 characters</Text>
//             </View>
//             <View style={styles.tooltipRow}>
//                 <Icon name="check-circle" size={14} color="lightgreen" />
//                 <Text style={styles.tooltipText}>This is a success tooltip</Text>
//             </View>
//
//             {/* New Password */}
//             <View style={styles.inputContainer}>
//                 <Icon name="lock" size={18} color="#999" style={styles.inputIcon} />
//                 <TextInput
//                     style={styles.input}
//                     placeholder="********"
//                     placeholderTextColor="#999"
//                     secureTextEntry={!showPassword1}
//                 />
//                 <TouchableOpacity onPress={() => setShowPassword1(!showPassword1)}>
//                     <MaterialIcon
//                         name={showPassword1 ? 'eye' : 'eye-off'}
//                         size={20}
//                         color="#999"
//                     />
//                 </TouchableOpacity>
//             </View>
//
//             {/* Confirm Password */}
//             <View style={styles.inputContainer}>
//                 <Icon name="lock" size={18} color="#999" style={styles.inputIcon} />
//                 <TextInput
//                     style={styles.input}
//                     placeholder="********"
//                     placeholderTextColor="#999"
//                     secureTextEntry={!showPassword2}
//                 />
//                 <TouchableOpacity onPress={() => setShowPassword2(!showPassword2)}>
//                     <MaterialIcon
//                         name={showPassword2 ? 'eye' : 'eye-off'}
//                         size={20}
//                         color="#999"
//                     />
//                 </TouchableOpacity>
//             </View>
//
//             {/* Remember Me - Custom Checkbox */}
//             <TouchableOpacity
//                 style={styles.checkboxContainer}
//                 onPress={() => setRemember(!remember)}
//                 activeOpacity={0.8}
//             >
//                 <View style={[styles.checkboxBox, remember && styles.checkboxChecked]}>
//                     {remember && <Icon name="check" size={14} color="#fff" />}
//                 </View>
//                 <Text style={styles.rememberText}>Remember me</Text>
//             </TouchableOpacity>
//
//             {/* Continue Button */}
//             <TouchableOpacity style={styles.continueButton}>
//                 <Text style={styles.continueButtonText}>Continue</Text>
//             </TouchableOpacity>
//         </SafeAreaView>
//     );
// };
//
// export default CreatePasswordScreen;
//
// const styles = StyleSheet.create({
//     container: {
//         flex: 1,
//         backgroundColor: '#121212',
//         padding: 20,
//     },
//     backButton: {
//         marginBottom: 10,
//     },
//     title: {
//         fontSize: 22,
//         fontWeight: 'bold',
//         color: '#fff',
//         alignSelf: 'center',
//         marginTop: 10,
//     },
//     image: {
//         width: 200,
//         height: 200,
//         alignSelf: 'center',
//         marginVertical: 20,
//     },
//     tooltipRow: {
//         flexDirection: 'row',
//         alignItems: 'center',
//         marginBottom: 6,
//     },
//     tooltipText: {
//         color: 'lightgreen',
//         fontSize: 14,
//         marginLeft: 8,
//     },
//     inputContainer: {
//         flexDirection: 'row',
//         alignItems: 'center',
//         backgroundColor: '#1E1E1E',
//         borderRadius: 8,
//         paddingHorizontal: 12,
//         paddingVertical: 12,
//         marginTop: 15,
//     },
//     inputIcon: {
//         marginRight: 4,
//     },
//     input: {
//         flex: 1,
//         color: '#fff',
//         fontSize: 16,
//         marginLeft: 8,
//     },
//     checkboxContainer: {
//         flexDirection: 'row',
//         alignItems: 'center',
//         marginTop: 12,
//     },
//     checkboxBox: {
//         width: 20,
//         height: 20,
//         borderWidth: 1,
//         borderColor: '#999',
//         borderRadius: 4,
//         justifyContent: 'center',
//         alignItems: 'center',
//     },
//     checkboxChecked: {
//         backgroundColor: '#F5A623',
//         borderColor: '#F5A623',
//     },
//     rememberText: {
//         color: '#fff',
//         marginLeft: 8,
//         fontSize: 14,
//     },
//     continueButton: {
//         backgroundColor: '#F5A623',
//         padding: 16,
//         borderRadius: 10,
//         marginTop: 30,
//     },
//     continueButtonText: {
//         textAlign: 'center',
//         color: '#fff',
//         fontWeight: 'bold',
//         fontSize: 16,
//     },
// });


// import React, { useState } from 'react';
// import {
//     View,
//     Text,
//     TextInput,
//     StyleSheet,
//     TouchableOpacity,
//     Image,
//     SafeAreaView,
//     Alert,
// } from 'react-native';
// import Icon from 'react-native-vector-icons/FontAwesome';
// import MaterialIcon from 'react-native-vector-icons/MaterialCommunityIcons';
// import { useRouter, useLocalSearchParams } from 'expo-router';
// import { useSignIn } from '@clerk/clerk-expo';
//
// const CreatePasswordScreen = () => {
//     const [password, setPassword] = useState('');
//     const [confirm, setConfirm] = useState('');
//     const [showPassword1, setShowPassword1] = useState(false);
//     const [showPassword2, setShowPassword2] = useState(false);
//     const [remember, setRemember] = useState(false);
//
//     const router = useRouter();
//     const { email } = useLocalSearchParams();
//     const { signIn } = useSignIn();
//
//     const handlePasswordReset = async () => {
//         if (!password || !confirm) {
//             Alert.alert('Error', 'Please fill in both fields.');
//             return;
//         }
//
//         if (password.length < 6) {
//             Alert.alert('Error', 'Password must be at least 6 characters.');
//             return;
//         }
//
//         if (password !== confirm) {
//             Alert.alert('Error', 'Passwords do not match.');
//             return;
//         }
//
//         try {
//             await signIn.resetPassword({ password });
//             await signIn.create({ identifier: email, password });
//
//             router.replace('/home'); // change to your screen
//         } catch (err) {
//             console.error('Reset failed:', err);
//             Alert.alert('Error', 'Something went wrong. Please try again.');
//         }
//     };
//
//     return (
//         <SafeAreaView style={styles.container}>
//             {/* Back Button */}
//             <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
//                 <Icon name="arrow-left" size={20} color="#fff" />
//             </TouchableOpacity>
//
//             {/* Title */}
//             <Text style={styles.title}>Create New Password</Text>
//
//             {/* Illustration */}
//             <Image
//                 source={require('../../assets/images/enter-password.webp')}
//                 style={styles.image}
//                 resizeMode="contain"
//             />
//
//             {/* Password tooltips */}
//             <View style={styles.tooltipRow}>
//                 <Icon name="check-circle" size={14} color="lightgreen" />
//                 <Text style={styles.tooltipText}>Cannot contain your name or email address</Text>
//             </View>
//             <View style={styles.tooltipRow}>
//                 <Icon name="check-circle" size={14} color="lightgreen" />
//                 <Text style={styles.tooltipText}>At least 8 characters</Text>
//             </View>
//             <View style={styles.tooltipRow}>
//                 <Icon name="check-circle" size={14} color="lightgreen" />
//                 <Text style={styles.tooltipText}>Include uppercase and symbols</Text>
//             </View>
//
//             {/* New Password */}
//             <View style={styles.inputContainer}>
//                 <Icon name="lock" size={18} color="#999" style={styles.inputIcon} />
//                 <TextInput
//                     style={styles.input}
//                     placeholder="New Password"
//                     placeholderTextColor="#999"
//                     secureTextEntry={!showPassword1}
//                     value={password}
//                     onChangeText={setPassword}
//                 />
//                 <TouchableOpacity onPress={() => setShowPassword1(!showPassword1)}>
//                     <MaterialIcon
//                         name={showPassword1 ? 'eye' : 'eye-off'}
//                         size={20}
//                         color="#999"
//                     />
//                 </TouchableOpacity>
//             </View>
//
//             {/* Confirm Password */}
//             <View style={styles.inputContainer}>
//                 <Icon name="lock" size={18} color="#999" style={styles.inputIcon} />
//                 <TextInput
//                     style={styles.input}
//                     placeholder="Confirm Password"
//                     placeholderTextColor="#999"
//                     secureTextEntry={!showPassword2}
//                     value={confirm}
//                     onChangeText={setConfirm}
//                 />
//                 <TouchableOpacity onPress={() => setShowPassword2(!showPassword2)}>
//                     <MaterialIcon
//                         name={showPassword2 ? 'eye' : 'eye-off'}
//                         size={20}
//                         color="#999"
//                     />
//                 </TouchableOpacity>
//             </View>
//
//             {/* Remember Me */}
//             <TouchableOpacity
//                 style={styles.checkboxContainer}
//                 onPress={() => setRemember(!remember)}
//                 activeOpacity={0.8}
//             >
//                 <View style={[styles.checkboxBox, remember && styles.checkboxChecked]}>
//                     {remember && <Icon name="check" size={14} color="#fff" />}
//                 </View>
//                 <Text style={styles.rememberText}>Remember me</Text>
//             </TouchableOpacity>
//
//             {/* Submit */}
//             <TouchableOpacity style={styles.continueButton} onPress={handlePasswordReset}>
//                 <Text style={styles.continueButtonText}>Continue</Text>
//             </TouchableOpacity>
//         </SafeAreaView>
//     );
// };
//
// export default CreatePasswordScreen;
//
// const styles = StyleSheet.create({
//     container: {
//         flex: 1,
//         backgroundColor: '#121212',
//         padding: 20,
//     },
//     backButton: {
//         marginBottom: 10,
//     },
//     title: {
//         fontSize: 22,
//         fontWeight: 'bold',
//         color: '#fff',
//         alignSelf: 'center',
//         marginTop: 10,
//     },
//     image: {
//         width: 200,
//         height: 200,
//         alignSelf: 'center',
//         marginVertical: 20,
//     },
//     tooltipRow: {
//         flexDirection: 'row',
//         alignItems: 'center',
//         marginBottom: 6,
//     },
//     tooltipText: {
//         color: 'lightgreen',
//         fontSize: 14,
//         marginLeft: 8,
//     },
//     inputContainer: {
//         flexDirection: 'row',
//         alignItems: 'center',
//         backgroundColor: '#1E1E1E',
//         borderRadius: 8,
//         paddingHorizontal: 12,
//         paddingVertical: 12,
//         marginTop: 15,
//     },
//     inputIcon: {
//         marginRight: 4,
//     },
//     input: {
//         flex: 1,
//         color: '#fff',
//         fontSize: 16,
//         marginLeft: 8,
//     },
//     checkboxContainer: {
//         flexDirection: 'row',
//         alignItems: 'center',
//         marginTop: 12,
//     },
//     checkboxBox: {
//         width: 20,
//         height: 20,
//         borderWidth: 1,
//         borderColor: '#999',
//         borderRadius: 4,
//         justifyContent: 'center',
//         alignItems: 'center',
//     },
//     checkboxChecked: {
//         backgroundColor: '#F5A623',
//         borderColor: '#F5A623',
//     },
//     rememberText: {
//         color: '#fff',
//         marginLeft: 8,
//         fontSize: 14,
//     },
//     continueButton: {
//         backgroundColor: '#F5A623',
//         padding: 16,
//         borderRadius: 10,
//         marginTop: 30,
//     },
//     continueButtonText: {
//         textAlign: 'center',
//         color: '#fff',
//         fontWeight: 'bold',
//         fontSize: 16,
//     },
// });

import React, { useState, useMemo } from 'react';
import {
    View,
    Text,
    TextInput,
    StyleSheet,
    TouchableOpacity,
    Image,
    SafeAreaView,
    Alert,
    ScrollView,
} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import MaterialIcon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { useSignIn } from '@clerk/clerk-expo';

const CreatePasswordScreen = () => {
    const [password, setPassword] = useState('');
    const [confirm, setConfirm] = useState('');
    const [showPassword1, setShowPassword1] = useState(false);
    const [showPassword2, setShowPassword2] = useState(false);
    const [remember, setRemember] = useState(false);

    const router = useRouter();
    const { email } = useLocalSearchParams();
    const { signIn } = useSignIn();

    const constraints = useMemo(() => ({
        minLength: password.length >= 8,
        hasUpper: /[A-Z]/.test(password),
        hasLower: /[a-z]/.test(password),
        hasNumber: /[0-9]/.test(password),
        hasSpecial: /[!@#$%^&*(),.?":{}|<>]/.test(password),
        match: password === confirm && confirm.length > 0,
    }), [password, confirm]);

    const isAllValid = Object.values(constraints).every(Boolean);

    const handlePasswordReset = async () => {
        if (!isAllValid) {
            Alert.alert('Invalid Password', 'Please meet all password requirements.');
            return;
        }

        try {
            await signIn.resetPassword({ password });
            await signIn.create({ identifier: password });
            router.replace('../(tabs)/App'); // change this route if needed
        } catch (err) {
            console.error('Reset failed:', err);
            Alert.alert('Error', 'Something went wrong. Please try again.');
        }
    };

    const renderConstraint = (label, isValid) => (
        <View style={styles.tooltipRow}>
            <Icon
                name={isValid ? 'check-circle' : 'times-circle'}
                size={14}
                color={isValid ? 'lightgreen' : '#f55'}
            />
            <Text style={[styles.tooltipText, { color: isValid ? 'lightgreen' : '#f55' }]}> {label}</Text>
        </View>
    );

    return (
        <SafeAreaView style={styles.container}>
            <ScrollView contentContainerStyle={styles.scrollContent} keyboardShouldPersistTaps="handled">
                <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
                    <Icon name="arrow-left" size={20} color="#fff" />
                </TouchableOpacity>

                <Text style={styles.title}>Create New Password</Text>

                <Image
                    source={require('../../assets/images/enter-password.webp')}
                    style={styles.image}
                    resizeMode="contain"
                />

                {renderConstraint("At least 8 characters", constraints.minLength)}
                {renderConstraint("At least 1 uppercase letter", constraints.hasUpper)}
                {renderConstraint("At least 1 lowercase letter", constraints.hasLower)}
                {renderConstraint("At least 1 number", constraints.hasNumber)}
                {renderConstraint("At least 1 special character", constraints.hasSpecial)}
                {renderConstraint("Passwords match", constraints.match)}

                <View style={styles.inputContainer}>
                    <Icon name="lock" size={18} color="#999" style={styles.inputIcon} />
                    <TextInput
                        style={styles.input}
                        placeholder="New Password"
                        placeholderTextColor="#999"
                        secureTextEntry={!showPassword1}
                        value={password}
                        onChangeText={setPassword}
                    />
                    <TouchableOpacity onPress={() => setShowPassword1(!showPassword1)}>
                        <MaterialIcon
                            name={showPassword1 ? 'eye' : 'eye-off'}
                            size={20}
                            color="#999"
                        />
                    </TouchableOpacity>
                </View>

                <View style={styles.inputContainer}>
                    <Icon name="lock" size={18} color="#999" style={styles.inputIcon} />
                    <TextInput
                        style={styles.input}
                        placeholder="Confirm Password"
                        placeholderTextColor="#999"
                        secureTextEntry={!showPassword2}
                        value={confirm}
                        onChangeText={setConfirm}
                    />
                    <TouchableOpacity onPress={() => setShowPassword2(!showPassword2)}>
                        <MaterialIcon
                            name={showPassword2 ? 'eye' : 'eye-off'}
                            size={20}
                            color="#999"
                        />
                    </TouchableOpacity>
                </View>

                <TouchableOpacity
                    style={styles.checkboxContainer}
                    onPress={() => setRemember(!remember)}
                    activeOpacity={0.8}
                >
                    <View style={[styles.checkboxBox, remember && styles.checkboxChecked]}>
                        {remember && <Icon name="check" size={14} color="#fff" />}
                    </View>
                    <Text style={styles.rememberText}>Remember me</Text>
                </TouchableOpacity>

                <TouchableOpacity
                    style={[styles.continueButton, !isAllValid && { backgroundColor: '#555' }]}
                    onPress={handlePasswordReset}
                    disabled={!isAllValid}
                >
                    <Text style={styles.continueButtonText}>Continue</Text>
                </TouchableOpacity>
            </ScrollView>
        </SafeAreaView>
    );
};

export default CreatePasswordScreen;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#121212',
    },
    scrollContent: {
        padding: 20,
        paddingBottom: 40,
    },
    backButton: {
        marginBottom: 10,
        marginTop:25,
    },
    title: {
        fontSize: 22,
        fontWeight: 'bold',
        color: '#fff',
        alignSelf: 'center',
        marginTop: 10,
    },
    image: {
        width: 200,
        height: 200,
        alignSelf: 'center',
        marginVertical: 20,
    },
    tooltipRow: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 6,
    },
    tooltipText: {
        fontSize: 14,
        marginLeft: 8,
    },
    inputContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#1E1E1E',
        borderRadius: 8,
        paddingHorizontal: 12,
        paddingVertical: 12,
        marginTop: 15,
    },
    inputIcon: {
        marginRight: 4,
    },
    input: {
        flex: 1,
        color: '#fff',
        fontSize: 16,
        marginLeft: 8,
    },
    checkboxContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        marginTop: 12,
    },
    checkboxBox: {
        width: 20,
        height: 20,
        borderWidth: 1,
        borderColor: '#999',
        borderRadius: 4,
        justifyContent: 'center',
        alignItems: 'center',
    },
    checkboxChecked: {
        backgroundColor: '#F5A623',
        borderColor: '#F5A623',
    },
    rememberText: {
        color: '#fff',
        marginLeft: 8,
        fontSize: 14,
    },
    continueButton: {
        backgroundColor: '#F5A623',
        padding: 16,
        borderRadius: 10,
        marginTop: 30,
    },
    continueButtonText: {
        textAlign: 'center',
        color: '#fff',
        fontWeight: 'bold',
        fontSize: 16,
    },
});





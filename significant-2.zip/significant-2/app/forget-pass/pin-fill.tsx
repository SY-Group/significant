// import React, { useState } from 'react';
// import {
//     View,
//     Text,
//     StyleSheet,
//     TouchableOpacity,
//     TextInput,
//     ImageBackground,
// } from 'react-native';
// import { FontAwesome } from '@expo/vector-icons';
//
// export default function CreatePinScreen() {
//     const [pin, setPin] = useState(["", "", "", ""]); // State to hold the PIN digits
//     const [focusedIndex, setFocusedIndex] = useState(null); // Track which box is focused
//
//     const handleInputChange = (text, index) => {
//         if (text.length > 1) return; // Limit input to one character
//         const updatedPin = [...pin];
//         updatedPin[index] = text;
//         setPin(updatedPin);
//
//         // Automatically move to the next input
//         if (text && index < 3) setFocusedIndex(index + 1);
//     };
//
//     return (
//         <ImageBackground
//             source={require('../../assets/images/bg.webp')} // Replace with your background image
//             style={styles.background}
//             resizeMode="cover"
//         >
//             <View style={styles.overlay} />
//
//             {/* Back Button */}
//             <TouchableOpacity style={styles.backButton}>
//                 <FontAwesome name="arrow-left" size={20} color="#fff" />
//             </TouchableOpacity>
//
//             {/* Title */}
//             <Text style={styles.title}>Create New PIN</Text>
//             <Text style={styles.subtitle}>
//                 Add a PIN number to make your account more secure.
//             </Text>
//
//             {/* PIN Input Boxes */}
//             <View style={styles.pinContainer}>
//                 {pin.map((digit, index) => (
//                     <TextInput
//                         key={index}
//                         style={[
//                             styles.pinBox,
//                             focusedIndex === index && styles.activePinBox,
//                         ]}
//                         value={digit}
//                         keyboardType="numeric"
//                         maxLength={1}
//                         onFocus={() => setFocusedIndex(index)}
//                         onChangeText={(text) => handleInputChange(text, index)}
//                     />
//                 ))}
//             </View>
//
//             {/* Buttons */}
//             <View style={styles.buttonContainer}>
//                 <TouchableOpacity style={styles.skipButton}>
//                     <Text style={styles.skipButtonText}>Skip</Text>
//                 </TouchableOpacity>
//                 <TouchableOpacity style={styles.continueButton}>
//                     <Text style={styles.continueButtonText}>Continue</Text>
//                 </TouchableOpacity>
//             </View>
//         </ImageBackground>
//     );
// }
//
// const styles = StyleSheet.create({
//     background: {
//         flex: 1,
//         justifyContent: 'flex-start',
//         alignItems: 'center',
//     },
//     overlay: {
//         ...StyleSheet.absoluteFillObject,
//         backgroundColor: 'rgba(0, 0, 0, 0.6)',
//     },
//     backButton: {
//         position: 'absolute',
//         top: 50,
//         left: 20,
//         width: 40,
//         height: 40,
//         borderRadius: 20,
//         backgroundColor: 'rgba(255, 255, 255, 0.1)',
//         justifyContent: 'center',
//         alignItems: 'center',
//     },
//     title: {
//         fontSize: 24,
//         fontWeight: '600',
//         color: '#fff',
//         marginTop: 55,
//         textAlign: 'center',
//     },
//     subtitle: {
//         fontSize: 14,
//         color: '#aaa',
//         marginTop: 30,
//         paddingLeft:10,
//         textAlign: 'center',
//     },
//     pinContainer: {
//         flexDirection: 'row',
//         justifyContent: 'space-between',
//         marginTop: 40,
//         width: '80%',
//     },
//     pinBox: {
//         width: 60,
//         height: 60,
//         borderRadius: 10,
//         backgroundColor: 'rgba(255, 255, 255, 0.1)',
//         textAlign: 'center',
//         fontSize: 22,
//         fontWeight: 'bold',
//         color: '#fff',
//         borderWidth: 1,
//         borderColor: 'rgba(255, 255, 255, 0.2)',
//     },
//     activePinBox: {
//         borderColor: '#f90',
//         borderWidth: 2,
//     },
//     buttonContainer: {
//         flexDirection: 'row',
//         justifyContent: 'space-between',
//         width: '80%',
//         marginTop: 280,
//     },
//     skipButton: {
//         flex: 1,
//         borderWidth: 1,
//         borderColor: '#fff',
//         paddingVertical: 15,
//         marginRight: 10,
//         borderRadius: 30,
//         alignItems: 'center',
//     },
//     skipButtonText: {
//         color: '#fff',
//         fontWeight: '500',
//         fontSize: 14,
//     },
//     continueButton: {
//         flex: 1,
//         backgroundColor: '#f90',
//         paddingVertical: 15,
//         marginLeft: 10,
//         borderRadius: 30,
//         alignItems: 'center',
//     },
//     continueButtonText: {
//         color: '#fff',
//         fontWeight: '500',
//         fontSize: 14,
//     },
// });

import React, { useState, useEffect, useRef } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    TextInput,
    ImageBackground,
    Alert,
} from 'react-native';
import { FontAwesome } from '@expo/vector-icons';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useSignIn } from '@clerk/clerk-expo';

export default function PinFillScreen() {
    const [pin, setPin] = useState(["", "", "", "", "", ""]);
    const [focusedIndex, setFocusedIndex] = useState(0);
    const inputRefs = useRef([]);
    const router = useRouter();
    const { email } = useLocalSearchParams();
    const { signIn } = useSignIn();

    useEffect(() => {
        const sendOTP = async () => {
            try {
                const signInAttempt = await signIn.create({ identifier: email });

                const emailFactor = signInAttempt.supportedFirstFactors.find(
                    (factor) => factor.strategy === 'reset_password_email_code'
                );

                if (!emailFactor?.emailAddressId) {
                    throw new Error('No email factor available for this user');
                }

                await signIn.prepareFirstFactor({
                    strategy: 'reset_password_email_code',
                    emailAddressId: emailFactor.emailAddressId,
                });
            } catch (error) {
                console.error("Error sending OTP:", error);
                Alert.alert('Error', 'Failed to send OTP. Please check your email.');
            }
        };

        if (email) sendOTP();
    }, [email]);

    const handleInputChange = (text, index) => {
        if (text.length > 1) return;

        const updatedPin = [...pin];
        updatedPin[index] = text;
        setPin(updatedPin);

        if (text && index < 5) {
            inputRefs.current[index + 1]?.focus();
        } else if (!text && index > 0) {
            inputRefs.current[index - 1]?.focus();
        }
    };

    const handleVerifyOTP = async () => {
        const code = pin.join('');
        if (code.length !== 6 || pin.includes("")) {
            Alert.alert("Incomplete Code", "Please enter all 6 digits.");
            return;
        }

        try {
            await signIn.attemptFirstFactor({
                strategy: 'reset_password_email_code',
                code,
            });

            router.push({
                pathname: '../forget-pass/Pass-filled',
                params: { email },
            });
        } catch (error) {
            console.error("OTP Verification Failed", error);
            Alert.alert("Invalid Code", "The code entered is incorrect or expired.");
        }
    };

    return (
        <ImageBackground
            source={require('../../assets/images/bg.webp')}
            style={styles.background}
            resizeMode="cover"
        >
            <View style={styles.overlay} />

            <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
                <FontAwesome name="arrow-left" size={20} color="#fff" />
            </TouchableOpacity>

            <Text style={styles.title}>Enter Verification Code</Text>
            <Text style={styles.subtitle}>
                We sent a 6-digit code to your email: {email}
            </Text>

            <View style={styles.pinContainer}>
                {pin.map((digit, index) => (
                    <TextInput
                        key={index}
                        ref={(ref) => (inputRefs.current[index] = ref)}
                        style={[
                            styles.pinBox,
                            focusedIndex === index && styles.activePinBox,
                        ]}
                        value={digit}
                        keyboardType="numeric"
                        maxLength={1}
                        onFocus={() => setFocusedIndex(index)}
                        onChangeText={(text) => handleInputChange(text, index)}
                    />
                ))}
            </View>

            <View style={styles.buttonContainer}>
                <TouchableOpacity style={styles.skipButton}>
                    <Text style={styles.skipButtonText}>Resend</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.continueButton} onPress={handleVerifyOTP}>
                    <Text style={styles.continueButtonText}>Continue</Text>
                </TouchableOpacity>
            </View>
        </ImageBackground>
    );
}

const styles = StyleSheet.create({
    background: {
        flex: 1,
        justifyContent: 'flex-start',
        alignItems: 'center',
    },
    overlay: {
        ...StyleSheet.absoluteFillObject,
        backgroundColor: 'rgba(0, 0, 0, 0.6)',
    },
    backButton: {
        position: 'absolute',
        top: 50,
        left: 20,
        width: 40,
        height: 40,
        borderRadius: 20,
        backgroundColor: 'rgba(255, 255, 255, 0.1)',
        justifyContent: 'center',
        alignItems: 'center',
    },
    title: {
        fontSize: 24,
        fontWeight: '600',
        color: '#fff',
        marginTop: 55,
        textAlign: 'center',
    },
    subtitle: {
        fontSize: 14,
        color: '#aaa',
        marginTop: 30,
        paddingHorizontal: 20,
        textAlign: 'center',
    },
    pinContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginTop: 40,
        width: '90%',
        paddingHorizontal: 10,
    },
    pinBox: {
        width: 50,
        height: 60,
        borderRadius: 10,
        backgroundColor: 'rgba(255, 255, 255, 0.1)',
        textAlign: 'center',
        fontSize: 22,
        fontWeight: 'bold',
        color: '#fff',
        borderWidth: 1,
        borderColor: 'rgba(255, 255, 255, 0.2)',
    },
    activePinBox: {
        borderColor: '#f90',
        borderWidth: 2,
    },
    buttonContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        width: '80%',
        marginTop: 250,
    },
    skipButton: {
        flex: 1,
        borderWidth: 1,
        borderColor: '#fff',
        paddingVertical: 15,
        marginRight: 10,
        borderRadius: 30,
        alignItems: 'center',
    },
    skipButtonText: {
        color: '#fff',
        fontWeight: '500',
        fontSize: 14,
    },
    continueButton: {
        flex: 1,
        backgroundColor: '#f90',
        paddingVertical: 15,
        marginLeft: 10,
        borderRadius: 30,
        alignItems: 'center',
    },
    continueButtonText: {
        color: '#fff',
        fontWeight: '500',
        fontSize: 14,
    },
});





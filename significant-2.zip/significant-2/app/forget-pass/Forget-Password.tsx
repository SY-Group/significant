// import React, { useState } from 'react';
// import {
//     View,
//     Text,
//     TouchableOpacity,
//     StyleSheet,
//     Image,
//     SafeAreaView,
// } from 'react-native';
// import Icon from 'react-native-vector-icons/MaterialIcons';
// import {router} from "expo-router";
//
// const ForgotPasswordScreen = () => {
//     const [selectedOption, setSelectedOption] = useState('sms');
//
//     const handlesotp = async () => {
//         router.push('../forget-pass/pin-fill')
//     }
//
//     return (
//         <SafeAreaView style={styles.container}>
//             {/* Back Button */}
//             <TouchableOpacity style={styles.backButton}>
//                 <Icon name="arrow-back" size={24} color="#fff" />
//             </TouchableOpacity>
//
//             {/* Title */}
//             <Text style={styles.title}>Forgot Password</Text>
//             <Text style={styles.subtitle}>
//                 Select which contact details should we use to reset your password.
//             </Text>
//
//             {/* Illustration */}
//             <Image
//                 source={require('../../assets/images/enter-password.webp')} // Replace with your image path
//                 style={styles.image}
//                 resizeMode="contain"
//             />
//
//             {/* Option 1: SMS */}
//             <TouchableOpacity
//                 style={[
//                     styles.optionContainer,
//                     selectedOption === 'sms' && styles.optionSelected,
//                 ]}
//                 onPress={() => setSelectedOption('sms')}
//             >
//                 <View style={styles.optionRow}>
//                     <Icon name="sms" size={20} color="#F5A623" />
//                     <View style={styles.optionTextContainer}>
//                         <Text style={styles.optionTitle}>Via SMS</Text>
//                         <Text style={styles.optionDetail}>+91 123 *** 890</Text>
//                     </View>
//                 </View>
//             </TouchableOpacity>
//
//             {/* Option 2: Email */}
//             <TouchableOpacity
//                 style={[
//                     styles.optionContainer,
//                     selectedOption === 'email' && styles.optionSelected,
//                 ]}
//                 onPress={() => setSelectedOption('email')}
//             >
//                 <View style={styles.optionRow}>
//                     <Icon
//                         name="send"
//                         size={20}
//                         color={selectedOption === 'email' ? '#F5A623' : '#999'}
//                     />
//                     <View style={styles.optionTextContainer}>
//                         <Text style={styles.optionTitle}>Via Email</Text>
//                         <Text style={styles.optionDetail}>ab*@gmail.com</Text>
//                     </View>
//                 </View>
//             </TouchableOpacity>
//
//             {/* Continue Button */}
//             <TouchableOpacity style={styles.continueButton} onPress={handlesotp}>
//                 <Text style={styles.continueButtonText}>Continue</Text>
//             </TouchableOpacity>
//         </SafeAreaView>
//     );
// };
//
// export default ForgotPasswordScreen;
//
// const styles = StyleSheet.create({
//     container: {
//         flex: 1,
//         backgroundColor: '#121212',
//         padding: 20,
//     },
//     backButton: {
//         marginTop:20,
//         marginBottom: 10,
//     },
//     title: {
//         fontSize: 22,
//         fontWeight: 'bold',
//         color: '#fff',
//         alignSelf: 'center',
//         marginTop: 10,
//     },
//     subtitle: {
//         color: '#bbb',
//         fontSize: 14,
//         textAlign: 'center',
//         marginVertical: 10,
//     },
//     image: {
//         width: 200,
//         height: 200,
//         alignSelf: 'center',
//         marginVertical: 20,
//     },
//     optionContainer: {
//         backgroundColor: '#1E1E1E',
//         borderRadius: 8,
//         padding: 15,
//         marginBottom: 15,
//         borderWidth: 1,
//         borderColor: '#1E1E1E',
//     },
//     optionSelected: {
//         borderColor: '#F5A623',
//     },
//     optionRow: {
//         flexDirection: 'row',
//         alignItems: 'center',
//     },
//     optionTextContainer: {
//         marginLeft: 10,
//     },
//     optionTitle: {
//         color: '#bbb',
//         fontSize: 14,
//     },
//     optionDetail: {
//         color: '#fff',
//         fontSize: 16,
//         fontWeight: '600',
//     },
//     continueButton: {
//         backgroundColor: '#F5A623',
//         padding: 16,
//         borderRadius: 10,
//         marginTop: 30,
//     },
//     continueButtonText: {
//         color: '#fff',
//         textAlign: 'center',
//         fontSize: 16,
//         fontWeight: 'bold',
//     },
// });


import React, { useState } from 'react';
import {
    View,
    Text,
    TouchableOpacity,
    StyleSheet,
    Image,
    SafeAreaView,
    TextInput,
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { router } from 'expo-router';

const ForgotPasswordScreen = () => {
    const [email, setEmail] = useState('');

    const handlesotp = () => {
        if (!email) {
            alert('Please enter your email address');
            return;
        }

        // You can store this email in a global store or pass it as a param
        router.push({
            pathname: '../forget-pass/pin-fill',
            params: { email }, // pass to next screen
        });
    };

    return (
        <SafeAreaView style={styles.container}>
            {/* Back Button */}
            <TouchableOpacity style={styles.backButton}>
                <Icon name="arrow-back" size={24} color="#fff" />
            </TouchableOpacity>

            {/* Title */}
            <Text style={styles.title}>Forgot Password</Text>
            <Text style={styles.subtitle}>
                Enter your email address to receive a password reset code.
            </Text>

            {/* Illustration */}
            <Image
                source={require('../../assets/images/enter-password.webp')}
                style={styles.image}
                resizeMode="contain"
            />

            {/* Email Input */}
            <View style={styles.inputContainer}>
                <Icon name="email" size={20} color="#F5A623" style={{ marginRight: 10 }} />
                <TextInput
                    style={styles.input}
                    placeholder="Enter your email"
                    placeholderTextColor="#999"
                    keyboardType="email-address"
                    value={email}
                    onChangeText={setEmail}
                    autoCapitalize="none"
                />
            </View>

            {/* Continue Button */}
            <TouchableOpacity style={styles.continueButton} onPress={handlesotp}>
                <Text style={styles.continueButtonText}>Continue</Text>
            </TouchableOpacity>
        </SafeAreaView>
    );
};

export default ForgotPasswordScreen;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#121212',
        padding: 20,
    },
    backButton: {
        marginTop: 20,
        marginBottom: 10,
    },
    title: {
        fontSize: 22,
        fontWeight: 'bold',
        color: '#fff',
        alignSelf: 'center',
        marginTop: 10,
    },
    subtitle: {
        color: '#bbb',
        fontSize: 14,
        textAlign: 'center',
        marginVertical: 10,
    },
    image: {
        width: 200,
        height: 200,
        alignSelf: 'center',
        marginVertical: 20,
    },
    inputContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#1E1E1E',
        borderRadius: 8,
        paddingHorizontal: 15,
        paddingVertical: 12,
        borderWidth: 1,
        borderColor: '#F5A623',
    },
    input: {
        flex: 1,
        color: '#fff',
        fontSize: 16,
    },
    continueButton: {
        backgroundColor: '#F5A623',
        padding: 16,
        borderRadius: 10,
        marginTop: 30,
    },
    continueButtonText: {
        color: '#fff',
        textAlign: 'center',
        fontSize: 16,
        fontWeight: 'bold',
    },
});

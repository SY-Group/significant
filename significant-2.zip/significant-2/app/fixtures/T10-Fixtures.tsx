import React from 'react';
import {
    View,
    Text,
    StyleSheet,
    Image,
    SafeAreaView,
    ScrollView,
    TouchableOpacity,
} from 'react-native';
import Icon from 'react-native-vector-icons/Feather';

const fixtures = [
    { team1: require('../../assets/images/t10stcl-card.webp'), team2: require('../../assets/images/t10stcl-card.webp') },
    { team1: require('../../assets/images/t10stcl-card.webp'), team2: require('../../assets/images/t10stcl-card.webp') },
    { team1: require('../../assets/images/t10stcl-card.webp'), team2: require('../../assets/images/t10stcl-card.webp') },
    { team1: require('../../assets/images/t10stcl-card.webp'), team2: require('../../assets/images/t10stcl-card.webp') },
    { team1: require('../../assets/images/t10stcl-card.webp'), team2: require('../../assets/images/t10stcl-card.webp') },
    { team1: require('../../assets/images/t10stcl-card.webp'), team2: require('../../assets/images/t10stcl-card.webp') },
    { team1: require('../../assets/images/t10stcl-card.webp'), team2: require('../../assets/images/t10stcl-card.webp') },
    { team1: require('../../assets/images/t10stcl-card.webp'), team2: require('../../assets/images/t10stcl-card.webp') },
    { team1: require('../../assets/images/t10stcl-card.webp'), team2: require('../../assets/images/t10stcl-card.webp') },
    { team1: require('../../assets/images/t10stcl-card.webp'), team2: require('../../assets/images/t10stcl-card.webp') },
];

const FixturesScreen = () => {
    return (
        <SafeAreaView style={styles.container}>
            {/* Top header */}
            <View style={styles.header}>
                <TouchableOpacity style={styles.button}>
                    <Icon name="arrow-left" size={24} color="#fff" />
                </TouchableOpacity>
                <Text style={styles.headerTitle}>FIXTURES</Text>
            </View>

            {/* Greeting */}
            <Text style={styles.greeting}>Good Afternoon <Text style={styles.name}>Anirban</Text></Text>
            <Text style={styles.subtitle}>Curated Fixtures For You</Text>

            {/* Scrollable Fixtures List */}
            <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
                {fixtures.map((match, index) => (
                    <View key={index} style={styles.matchCard}>
                        <Image source={match.team1} style={styles.teamLogo} />
                        <Text style={styles.vsText}>VS</Text>
                        <Image source={match.team2} style={styles.teamLogo} />
                    </View>
                ))}
            </ScrollView>

            {/* Bottom Navigation */}
            {/*<View style={styles.bottomNav}>*/}
            {/*    <Icon name="home" size={22} color="#fff" />*/}
            {/*    <Icon name="search" size={22} color="#fff" />*/}
            {/*    <Icon name="bell" size={22} color="#F5A623" />*/}
            {/*    <Icon name="menu" size={22} color="#fff" />*/}
            {/*</View>*/}
        </SafeAreaView>
    );
};

export default FixturesScreen;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#121212',
        paddingTop: 10,
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',

        paddingHorizontal: 20,
    },

    button:{
        marginTop: 40,

    },
    headerTitle: {
        color: '#fff',
        fontSize: 18,
        fontWeight: 'bold',
        marginLeft: 20,
        marginTop:40,
    },
    greeting: {
        fontSize: 18,
        color: '#fff',
        paddingHorizontal: 20,
        marginTop: 20,
    },
    name: {
        color: '#F5A623',
        fontWeight: 'bold',
    },
    subtitle: {
        color: '#ccc',
        fontSize: 14,
        paddingHorizontal: 20,
        marginBottom: 20,
        paddingTop:5,
    },
    scrollContent: {
        paddingHorizontal: 20,
        paddingBottom: 100, // space for bottom nav
    },
    matchCard: {
        backgroundColor: '#2A2A2A',
        borderRadius: 10,
        paddingVertical: 40,
        paddingHorizontal: 20,
        marginBottom: 15,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
    },
    teamLogo: {
        width: 80,
        height: 80,
        resizeMode: 'contain',
    },
    vsText: {
        color: '#fff',
        fontSize: 16,
        fontWeight: 'bold',
    },
    bottomNav: {
        position: 'absolute',
        bottom: 0,
        height: 60,
        backgroundColor: '#1E1E1E',
        width: '100%',
        flexDirection: 'row',
        justifyContent: 'space-around',
        alignItems: 'center',
        borderTopColor: '#333',
        borderTopWidth: 1,
    },
});

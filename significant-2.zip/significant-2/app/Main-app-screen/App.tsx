// import React, { useState } from 'react';
// import {
//     View,
//     Text,
//     StyleSheet,
//     ScrollView,
//     Image,
//     Modal,
//     TouchableOpacity,
//     Dimensions,
//     SafeAreaView,
// } from 'react-native';
// import { useFocusEffect } from '@react-navigation/native';
// import { useCallback } from 'react';
// import Icon from 'react-native-vector-icons/Feather';
// import {useRouter} from "expo-router";
//
// const { width } = Dimensions.get('window');
//
// const HomeScreen = () => {
//     const [activeTab, setActiveTab] = useState('T10STCL');
//     const [modalVisible, setModalVisible] = useState(true);
//     useFocusEffect(
//         useCallback(() => {
//             setModalVisible(true);
//         }, [])
//     );
//
//     const router = useRouter();
//
//     const handleregister = () => {
//         router.push('../Register-t10stcl/register-t10stcl');
//     };
//
//     return (
//         <SafeAreaView style={styles.container}>
//             <Modal
//                 transparent
//                 animationType="fade"
//                 visible={modalVisible}
//                 onRequestClose={() => setModalVisible(false)}
//             >
//                 <View style={styles.modalOverlay}>
//                     <View style={styles.modalContent}>
//                         <Image
//                             source={require('../../assets/images/t10stcl-card.webp')}
//                             style={styles.modalImage}
//                             resizeMode="contain"
//                         />
//                         <TouchableOpacity style={styles.registerButton} onPress={handleregister}>
//                             <Text style={styles.registerButtonText}>Register Now</Text>
//                         </TouchableOpacity>
//                         <TouchableOpacity
//                             onPress={() => setModalVisible(false)}
//                             style={styles.modalClose}
//                         >
//                             <Icon name="x" size={24} color="#fff" />
//                         </TouchableOpacity>
//                     </View>
//                 </View>
//             </Modal>
//
//             <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
//                 {/* Welcome Header */}
//                 <Text style={styles.title}>Welcome to T10STCL</Text>
//
//                 {/* Tabs */}
//                 <View style={styles.tabs}>
//                     <TouchableOpacity
//                         style={[styles.tabButton, activeTab === 'T10STCL' && styles.activeTab]}
//                         onPress={() => setActiveTab('T10STCL')}
//                     >
//                         <Text style={styles.tabText}>T10STCL</Text>
//                     </TouchableOpacity>
//                     <TouchableOpacity
//                         style={[styles.tabButton, activeTab === 'Significant' && styles.activeTab]}
//                         onPress={() => setActiveTab('Significant')}
//                     >
//                         <Text style={styles.tabText}>Significant</Text>
//                     </TouchableOpacity>
//                 </View>
//
//                 {/* LIVE VIDEO PLACEHOLDER */}
//                 <View style={styles.liveCard}>
//                     <Text style={styles.liveTitle}>Live Now</Text>
//                     <Text style={styles.liveMatch}>Dhakad Delhi vs Rangrez Banaras</Text>
//                     <Text style={styles.liveDate}>25th September 2025 | ** Views</Text>
//                     <View style={styles.liveBadge}>
//                         <Text style={styles.liveBadgeText}>🔴 LIVE</Text>
//                     </View>
//                 </View>
//
//                 {/* Score Box */}
//                 <View style={styles.scoreBox}>
//                     <Text style={styles.scoreText}>11/1</Text>
//                     <Text style={styles.teamName}>DD</Text>
//                     <Text style={styles.scoreText}>vs</Text>
//                     <Text style={styles.teamName}>RB</Text>
//                     <Text style={styles.scoreText}>22/2</Text>
//                 </View>
//
//                 {/* Greeting and News */}
//                 <Text style={styles.greeting}>
//                     Good Afternoon <Text style={styles.name}>Anirban</Text>
//                 </Text>
//                 <Text style={styles.sectionLabel}>Curated News for You</Text>
//
//                 {/* News Cards */}
//                 <View style={styles.newsCard}>
//                     <Image source={require('../../assets/images/t10stcl-card.webp')} style={styles.newsLogo} />
//                     <View style={styles.newsText}>
//                         <Text style={styles.newsTitle}>Trial Dates</Text>
//                         <Text style={styles.newsSub}>The Trial Dates for T10STCL are announced. Check your mail now for latest updates</Text>
//                     </View>
//                 </View>
//                 <View style={styles.newsCard}>
//                     <Image source={require('../../assets/images/t10stcl-card.webp')} style={styles.newsLogo} />
//                     <View style={styles.newsText}>
//                         <Text style={styles.newsTitle}>Trial Dates</Text>
//                         <Text style={styles.newsSub}>The Trial Dates for T10STCL are announced. Check your mail now for latest updates</Text>
//                     </View>
//                 </View>
//
//                 {/* Quick Access Buttons */}
//                 <Text style={styles.sectionSubHeader}>What Are You Looking For</Text>
//                 <View style={styles.quickAccessContainer}>
//                     <TouchableOpacity style={styles.quickButton}>
//                         <Text style={styles.quickText}>Fixtures</Text>
//                     </TouchableOpacity>
//                     <TouchableOpacity style={styles.quickButton}>
//                         <Text style={styles.quickText}>Points Table</Text>
//                     </TouchableOpacity>
//                 </View>
//                 <View style={styles.quickAccessContainer}>
//                     <TouchableOpacity style={styles.quickButton}>
//                         <Text style={styles.quickText}>Overall Stats</Text>
//                     </TouchableOpacity>
//                     <TouchableOpacity style={styles.quickButton}>
//                         <Text style={styles.quickText}>All Teams</Text>
//                     </TouchableOpacity>
//                 </View>
//
//                 {/* Fixtures Section */}
//                 <Text style={styles.sectionLabel}>Curated Fixtures For You</Text>
//                 <View style={styles.fixtureCard}>
//                     <Image source={require('../../assets/images/t10stcl-card.webp')} style={styles.teamLogo} />
//                     <Text style={styles.vsText}>VS</Text>
//                     <Image source={require('../../assets/images/t10stcl-card.webp')} style={styles.teamLogo} />
//                 </View>
//                 <View style={styles.fixtureCard}>
//                     <Image source={require('../../assets/images/t10stcl-card.webp')} style={styles.teamLogo} />
//                     <Text style={styles.vsText}>VS</Text>
//                     <Image source={require('../../assets/images/t10stcl-card.webp')} style={styles.teamLogo} />
//                 </View>
//
//                 {/* Points Table */}
//                 <Text style={styles.sectionLabel}>Points table</Text>
//                 {[0, 1].map((_, index) => (
//                     <View style={styles.pointsCard} key={index}>
//                         <Image source={require('../../assets/images/t10stcl-card.webp')} style={styles.teamLogoSmall} />
//                         <View style={{ flex: 1 }}>
//                             <Text style={styles.teamTitle}>Dhakad Delhi</Text>
//                             <Text style={styles.pointsInfo}>Points: 19</Text>
//                             <Text style={styles.pointsInfo}>Played: 14</Text>
//                             <Text style={styles.pointsInfo}>Won: 9</Text>
//                             <Text style={styles.pointsInfo}>NRR: +0.372</Text>
//                             <View style={styles.statusIcons}>
//                                 {['green', 'green', 'red', 'red', 'green'].map((color, i) => (
//                                     <View
//                                         key={i}
//                                         style={[styles.statusDot, { backgroundColor: color === 'green' ? 'limegreen' : 'red' }]}
//                                     />
//                                 ))}
//                             </View>
//                         </View>
//                     </View>
//                 ))}
//             </ScrollView>
//
//             {/* Bottom Nav */}
//             {/*<View style={styles.bottomNav}>*/}
//             {/*    <Icon name="home" size={22} color="#fff" />*/}
//             {/*    <Icon name="grid" size={22} color="#fff" />*/}
//             {/*    <Icon name="search" size={22} color="#fff" />*/}
//             {/*    <Icon name="bell" size={22} color="#F5A623" />*/}
//             {/*    <Icon name="menu" size={22} color="#fff" />*/}
//             {/*</View>*/}
//         </SafeAreaView>
//     );
// };
//
// export default HomeScreen;
//
// const styles = StyleSheet.create({
//     container: {
//         flex: 1,
//         backgroundColor: '#121212',
//         marginTop:30,
//     },
//     scrollContent: {
//         paddingBottom: 120,
//     },
//     title: {
//         fontSize: 18,
//         fontWeight: 'bold',
//         color: '#fff',
//         padding: 16,
//     },
//     tabs: {
//         flexDirection: 'row',
//         marginHorizontal: 16,
//         marginBottom: 10,
//     },
//     tabButton: {
//         flex: 1,
//         backgroundColor: '#1E1E1E',
//         padding: 12,
//         marginRight: 8,
//         borderRadius: 10,
//         alignItems: 'center',
//     },
//     activeTab: {
//         backgroundColor: '#333',
//     },
//     tabText: {
//         color: '#fff',
//         fontWeight: 'bold',
//     },
//     liveCard: {
//         backgroundColor: '#1E1E1E',
//         marginHorizontal: 16,
//         borderRadius: 10,
//         padding: 16,
//         alignItems: 'center',
//         marginBottom: 10,
//     },
//     liveTitle: {
//         color: '#F5A623',
//         fontWeight: 'bold',
//         marginBottom: 4,
//     },
//     liveMatch: {
//         color: '#fff',
//         fontSize: 16,
//         marginBottom: 4,
//     },
//     liveDate: {
//         color: '#bbb',
//         fontSize: 12,
//     },
//     liveBadge: {
//         marginTop: 8,
//         paddingVertical: 4,
//         paddingHorizontal: 10,
//         backgroundColor: 'red',
//         borderRadius: 10,
//     },
//     liveBadgeText: {
//         color: '#fff',
//         fontSize: 12,
//     },
//     scoreBox: {
//         backgroundColor: '#2A2A2A',
//         borderRadius: 10,
//
//         marginHorizontal: 16,
//         flexDirection: 'row',
//         paddingHorizontal: 40,
//         justifyContent: 'space-between',
//         padding: 30,
//         alignItems: 'center',
//     },
//     scoreText: {
//         color: '#fff',
//         fontWeight: 'bold',
//         fontSize: 14,
//     },
//     teamName: {
//         color: '#F5A623',
//         fontWeight: 'bold',
//         fontSize: 14,
//     },
//     greeting: {
//         fontSize: 20,
//         color: '#fff',
//         fontWeight: 'bold',
//         paddingHorizontal: 16,
//         marginTop: 20,
//     },
//     name: {
//         color: '#F5A623',
//         fontWeight: 'bold',
//     },
//     sectionLabel: {
//         fontSize: 16,
//         fontWeight: 'bold',
//         color: '#ccc',
//         paddingHorizontal: 16,
//         marginTop: 20,
//         marginBottom: 15,
//     },
//     newsCard: {
//         backgroundColor: '#2A2A2A',
//         borderRadius: 10,
//         paddingVertical:20,
//         marginHorizontal: 16,
//         flexDirection: 'row',
//         padding: 12,
//         marginBottom: 12,
//     },
//     newsLogo: {
//         width: 90,
//         height: 90,
//         resizeMode: 'contain',
//         marginRight: 12,
//     },
//     newsText: {
//         flex: 1,
//     },
//     newsTitle: {
//         color: '#fff',
//         fontWeight: 'bold',
//         fontSize: 17,
//         marginTop:5,
//         marginBottom: 10,
//     },
//     newsSub: {
//         color: '#aaa',
//         fontSize: 13,
//     },
//     sectionSubHeader: {
//         color: '#bbb',
//         paddingHorizontal: 16,
//         marginTop: 10,
//         marginBottom: 6,
//     },
//     quickAccessContainer: {
//         flexDirection: 'row',
//         justifyContent: 'space-between',
//         marginHorizontal: 16,
//         marginBottom: 10,
//     },
//     quickButton: {
//         backgroundColor: '#2A2A2A',
//         flex: 0.48,
//         padding: 14,
//         borderRadius: 10,
//         alignItems: 'center',
//     },
//     quickText: {
//         color: '#fff',
//         fontWeight: 'bold',
//     },
//     fixtureCard: {
//         backgroundColor: '#2A2A2A',
//         borderRadius: 10,
//         marginHorizontal: 16,
//         marginBottom: 12,
//         flexDirection: 'row',
//         padding: 12,
//         paddingVertical:20,
//         alignItems: 'center',
//         justifyContent: 'space-between',
//     },
//     teamLogo: {
//         width: 90,
//         height: 90,
//         resizeMode: 'contain',
//     },
//     vsText: {
//         color: '#fff',
//         fontWeight: 'bold',
//         fontSize: 16,
//     },
//     pointsCard: {
//         backgroundColor: '#2A2A2A',
//         marginHorizontal: 16,
//         borderRadius: 10,
//         padding: 16,
//         marginBottom: 12,
//         paddingVertical:20,
//         flexDirection: 'row',
//     },
//     teamLogoSmall: {
//         width: 100,
//         height: 100,
//         resizeMode: 'contain',
//         marginRight: 12,
//         marginTop:7,
//     },
//     teamTitle: {
//         color: '#fff',
//         fontWeight: 'bold',
//         fontSize: 18,
//         marginBottom:10,
//     },
//     pointsInfo: {
//         color: '#ccc',
//         fontSize: 13,
//     },
//     statusIcons: {
//         flexDirection: 'row',
//         marginTop: 10,
//     },
//     statusDot: {
//         width: 12,
//         height: 12,
//         borderRadius: 6,
//         marginRight: 6,
//     },
//     bottomNav: {
//         position: 'absolute',
//         bottom: 0,
//         height: 60,
//         backgroundColor: '#1E1E1E',
//         width: '100%',
//         flexDirection: 'row',
//         justifyContent: 'space-around',
//         alignItems: 'center',
//         borderTopColor: '#333',
//         borderTopWidth: 1,
//     },
//
//     modalOverlay: {
//         flex: 1,
//         backgroundColor: 'rgba(0,0,0,0.6)',
//         justifyContent: 'center',
//
//         alignItems: 'center',
//     },
//     modalContent: {
//         width: '85%',
//
//         backgroundColor: '#1E1E1E',
//         borderRadius: 15,
//         padding: 20,
//         alignItems: 'center',
//         position: 'relative',
//     },
//     modalImage: {
//         width: '100%',
//         height:200,
//         borderRadius: 5,
//         marginBottom: 20,
//     },
//     registerButton: {
//         backgroundColor: '#F5A623',
//         width: '100%',
//
//         paddingVertical: 18,
//         paddingHorizontal: 30,
//         borderRadius: 8,
//     },
//     registerButtonText: {
//         color: '#121212',
//         alignSelf: "center",
//         fontWeight: 'bold',
//         fontSize: 16,
//     },
//     modalClose: {
//         position: 'absolute',
//         top: 10,
//         right: 10,
//     },
//
// });

// import React, { useState } from 'react';
// import {
//     View,
//     Text,
//     StyleSheet,
//     ScrollView,
//     Image,
//     Modal,
//     TouchableOpacity,
//     Dimensions,
//     SafeAreaView,
// } from 'react-native';
// import { useFocusEffect } from '@react-navigation/native';
// import { useCallback } from 'react';
// import Icon from 'react-native-vector-icons/Feather';
// import { useRouter } from "expo-router";
//
// const { width } = Dimensions.get('window');
//
// const HomeScreen = () => {
//     const [activeTab, setActiveTab] = useState('Significant'); // Focus on Significant
//     const [modalVisible, setModalVisible] = useState(true);
//
//     useFocusEffect(
//         useCallback(() => {
//             setModalVisible(true);
//         }, [])
//     );
//
//     const router = useRouter();
//
//     const handleregister = () => {
//         router.push('../Register-t10stcl/register-t10stcl');
//     };
//
//     return (
//         <SafeAreaView style={styles.container}>
//             <Modal
//                 transparent
//                 animationType="fade"
//                 visible={modalVisible}
//                 onRequestClose={() => setModalVisible(false)}
//             >
//                 <View style={styles.modalOverlay}>
//                     <View style={styles.modalContent}>
//                         <Image
//                             source={require('../../assets/images/t10stcl-card.webp')}
//                             style={styles.modalImage}
//                             resizeMode="contain"
//                         />
//                         <TouchableOpacity style={styles.registerButton} onPress={handleregister}>
//                             <Text style={styles.registerButtonText}>Register Now</Text>
//                         </TouchableOpacity>
//                         <TouchableOpacity
//                             onPress={() => setModalVisible(false)}
//                             style={styles.modalClose}
//                         >
//                             <Icon name="x" size={24} color="#fff" />
//                         </TouchableOpacity>
//                     </View>
//                 </View>
//             </Modal>
//
//             <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
//                 {/* Welcome Header */}
//                 <Text style={styles.title}>Welcome to I AM DANCE</Text>
//
//                 {/* Tabs */}
//                 <View style={styles.tabs}>
//                     <TouchableOpacity
//                         style={[styles.tabButton, activeTab === 'T10STCL' && styles.activeTab]}
//                         onPress={() => setActiveTab('T10STCL')}
//                     >
//                         <Text style={styles.tabText}>T10STCL</Text>
//                     </TouchableOpacity>
//                     <TouchableOpacity
//                         style={[styles.tabButton, activeTab === 'Significant' && styles.activeTab]}
//                         onPress={() => setActiveTab('Significant')}
//                     >
//                         <Text style={styles.tabText}>Significant</Text>
//                     </TouchableOpacity>
//                 </View>
//
//                 {/* LIVE DANCE SHOW PLACEHOLDER */}
//                 <View style={styles.liveCard}>
//                     <Text style={styles.liveTitle}>Live Now</Text>
//                     <Text style={styles.liveMatch}>Battle of Styles: Urban Fusion vs Classical Crew</Text>
//                     <Text style={styles.liveDate}>1st July 2025 | 45K+ Views</Text>
//                     <View style={styles.liveBadge}>
//                         <Text style={styles.liveBadgeText}>🔴 LIVE</Text>
//                     </View>
//                 </View>
//
//                 {/* Quick Access Buttons */}
//                 <Text style={styles.sectionSubHeader}>What Are You Looking For</Text>
//                 <View style={styles.quickAccessContainer}>
//                     <TouchableOpacity style={styles.quickButton} onPress={handleregister}>
//                         <Text style={styles.quickText}>Register Now</Text>
//                     </TouchableOpacity>
//                     <TouchableOpacity style={styles.quickButton}>
//                         <Text style={styles.quickText}>Explore Styles</Text>
//                     </TouchableOpacity>
//                 </View>
//                 <View style={styles.quickAccessContainer}>
//                     <TouchableOpacity style={styles.quickButton}>
//                         <Text style={styles.quickText}>Schedule</Text>
//                     </TouchableOpacity>
//                     <TouchableOpacity style={styles.quickButton}>
//                         <Text style={styles.quickText}>FAQs</Text>
//                     </TouchableOpacity>
//                 </View>
//             </ScrollView>
//         </SafeAreaView>
//     );
// };
//
// export default HomeScreen;
//
// // Styles remain unchanged (from your current stylesheet)
// const styles = StyleSheet.create({
//     container: {
//         flex: 1,
//         backgroundColor: '#121212',
//         marginTop: 30,
//     },
//     scrollContent: {
//         paddingBottom: 120,
//     },
//     title: {
//         fontSize: 18,
//         fontWeight: 'bold',
//         color: '#fff',
//         padding: 16,
//     },
//     tabs: {
//         flexDirection: 'row',
//         marginHorizontal: 16,
//         marginBottom: 10,
//     },
//     tabButton: {
//         flex: 1,
//         backgroundColor: '#1E1E1E',
//         padding: 12,
//         marginRight: 8,
//         borderRadius: 10,
//         alignItems: 'center',
//     },
//     activeTab: {
//         backgroundColor: '#333',
//     },
//     tabText: {
//         color: '#fff',
//         fontWeight: 'bold',
//     },
//     liveCard: {
//         backgroundColor: '#1E1E1E',
//         marginHorizontal: 16,
//         borderRadius: 10,
//         padding: 16,
//         alignItems: 'center',
//         marginBottom: 10,
//     },
//     liveTitle: {
//         color: '#F5A623',
//         fontWeight: 'bold',
//         marginBottom: 4,
//     },
//     liveMatch: {
//         color: '#fff',
//         fontSize: 16,
//         marginBottom: 4,
//         textAlign: 'center',
//     },
//     liveDate: {
//         color: '#bbb',
//         fontSize: 12,
//     },
//     liveBadge: {
//         marginTop: 8,
//         paddingVertical: 4,
//         paddingHorizontal: 10,
//         backgroundColor: 'red',
//         borderRadius: 10,
//     },
//     liveBadgeText: {
//         color: '#fff',
//         fontSize: 12,
//     },
//     sectionSubHeader: {
//         color: '#bbb',
//         paddingHorizontal: 16,
//         marginTop: 20,
//         marginBottom: 6,
//         fontWeight: 'bold',
//         fontSize: 16,
//     },
//     quickAccessContainer: {
//         flexDirection: 'row',
//         justifyContent: 'space-between',
//         marginHorizontal: 16,
//         marginBottom: 10,
//     },
//     quickButton: {
//         backgroundColor: '#2A2A2A',
//         flex: 0.48,
//         padding: 14,
//         borderRadius: 10,
//         alignItems: 'center',
//     },
//     quickText: {
//         color: '#fff',
//         fontWeight: 'bold',
//     },
//     modalOverlay: {
//         flex: 1,
//         backgroundColor: 'rgba(0,0,0,0.6)',
//         justifyContent: 'center',
//         alignItems: 'center',
//     },
//     modalContent: {
//         width: '85%',
//         backgroundColor: '#1E1E1E',
//         borderRadius: 15,
//         padding: 20,
//         alignItems: 'center',
//         position: 'relative',
//     },
//     modalImage: {
//         width: '100%',
//         height: 200,
//         borderRadius: 5,
//         marginBottom: 20,
//     },
//     registerButton: {
//         backgroundColor: '#F5A623',
//         width: '100%',
//         paddingVertical: 18,
//         paddingHorizontal: 30,
//         borderRadius: 8,
//     },
//     registerButtonText: {
//         color: '#121212',
//         alignSelf: "center",
//         fontWeight: 'bold',
//         fontSize: 16,
//     },
//     modalClose: {
//         position: 'absolute',
//         top: 10,
//         right: 10,
//     },
// });

import React, { useCallback, useState } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    ScrollView,
    Image,
    Modal,
    SafeAreaView,
    Dimensions,
} from 'react-native';
import Icon from 'react-native-vector-icons/Feather';
import { useFocusEffect } from '@react-navigation/native';
import { useRouter } from 'expo-router';

const { width } = Dimensions.get('window');

const HomeScreen = () => {
    const [activeTab, setActiveTab] = useState<'T10STCL' | 'Significant'>('T10STCL');
    const [modalVisible, setModalVisible] = useState(false);
    const router = useRouter();

    useFocusEffect(
        useCallback(() => {
            setModalVisible(true);
        }, [activeTab])
    );

    const handleRegister = () => {
        if (activeTab === 'T10STCL') {
            router.push('../Register-t10stcl/register-t10stcl');
        } else {
            router.push('../Register-IamDance/Register-IAD');
        }
    };

    const renderT10STCLContent = () => (
        <>
            <Text style={styles.title}>Welcome to T10STCL</Text>

            {/* LIVE Video Card */}
            <View style={styles.liveCard}>
                <Text style={styles.liveTitle}>Live Now</Text>
                <Text style={styles.liveMatch}>Dhakad Delhi vs Rangrez Banaras</Text>
                <Text style={styles.liveDate}>25th September 2025 | ** Views</Text>
                <View style={styles.liveBadge}>
                    <Text style={styles.liveBadgeText}>🔴 LIVE</Text>
                </View>
            </View>

            {/* Score Box */}
            <View style={styles.scoreBox}>
                <Text style={styles.scoreText}>11/1</Text>
                <Text style={styles.teamName}>DD</Text>
                <Text style={styles.scoreText}>vs</Text>
                <Text style={styles.teamName}>RB</Text>
                <Text style={styles.scoreText}>22/2</Text>
            </View>

            {/* Greeting */}
            <Text style={styles.greeting}>
                Good Afternoon <Text style={styles.name}>Anirban</Text>
            </Text>
            <Text style={styles.sectionLabel}>Curated News for You</Text>

            {/* News Cards */}
            {[1, 2].map((_, index) => (
                <View style={styles.newsCard} key={index}>
                    <Image source={require('../../assets/images/t10stcl-card.webp')} style={styles.newsLogo} />
                    <View style={styles.newsText}>
                        <Text style={styles.newsTitle}>Trial Dates</Text>
                        <Text style={styles.newsSub}>
                            The Trial Dates for T10STCL are announced. Check your mail now for latest updates
                        </Text>
                    </View>
                </View>
            ))}

            {/* Quick Access */}
            <Text style={styles.sectionSubHeader}>What Are You Looking For</Text>
            <View style={styles.quickAccessContainer}>
                <TouchableOpacity style={styles.quickButton}><Text style={styles.quickText}>Fixtures</Text></TouchableOpacity>
                <TouchableOpacity style={styles.quickButton}><Text style={styles.quickText}>Points Table</Text></TouchableOpacity>
            </View>
            <View style={styles.quickAccessContainer}>
                <TouchableOpacity style={styles.quickButton}><Text style={styles.quickText}>Overall Stats</Text></TouchableOpacity>
                <TouchableOpacity style={styles.quickButton}><Text style={styles.quickText}>All Teams</Text></TouchableOpacity>
            </View>

            {/* Fixtures */}
            <Text style={styles.sectionLabel}>Curated Fixtures For You</Text>
            {[1, 2].map((_, index) => (
                <View style={styles.fixtureCard} key={index}>
                    <Image source={require('../../assets/images/t10stcl-card.webp')} style={styles.teamLogo} />
                    <Text style={styles.vsText}>VS</Text>
                    <Image source={require('../../assets/images/t10stcl-card.webp')} style={styles.teamLogo} />
                </View>
            ))}

            {/* Points Table */}
            <Text style={styles.sectionLabel}>Points table</Text>
            {[0, 1].map((_, index) => (
                <View style={styles.pointsCard} key={index}>
                    <Image source={require('../../assets/images/t10stcl-card.webp')} style={styles.teamLogoSmall} />
                    <View style={{ flex: 1 }}>
                        <Text style={styles.teamTitle}>Dhakad Delhi</Text>
                        <Text style={styles.pointsInfo}>Points: 19</Text>
                        <Text style={styles.pointsInfo}>Played: 14</Text>
                        <Text style={styles.pointsInfo}>Won: 9</Text>
                        <Text style={styles.pointsInfo}>NRR: +0.372</Text>
                        <View style={styles.statusIcons}>
                            {['green', 'green', 'red', 'red', 'green'].map((color, i) => (
                                <View key={i} style={[styles.statusDot, { backgroundColor: color === 'green' ? 'limegreen' : 'red' }]} />
                            ))}
                        </View>
                    </View>
                </View>
            ))}
        </>
    );

    const renderSignificantContent = () => (
        <>
            <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
                {/* Welcome Header */}
                                 <Text style={styles.title}>Welcome to I AM DANCE</Text>


                                {/* LIVE DANCE SHOW PLACEHOLDER */}
                                <View style={styles.liveCard}>
                                    <Text style={styles.liveTitle}>Live Now</Text>
                                    <Text style={styles.liveMatch}>Battle of Styles: Urban Fusion vs Classical Crew</Text>
                                    <Text style={styles.liveDate}>1st July 2025 | 45K+ Views</Text>
                                    <View style={styles.liveBadge}>
                                        <Text style={styles.liveBadgeText}>🔴 LIVE</Text>
                                    </View>
                                </View>

                                {/* Quick Access Buttons */}
                                <Text style={styles.sectionSubHeader}>What Are You Looking For</Text>
                                <View style={styles.quickAccessContainer}>
                                    <TouchableOpacity style={styles.quickButton} onPress={handleRegister}>
                                        <Text style={styles.quickText}>Register Now</Text>
                                    </TouchableOpacity>
                                    <TouchableOpacity style={styles.quickButton}>
                                        <Text style={styles.quickText}>Explore Styles</Text>
                                    </TouchableOpacity>
                                </View>
                                <View style={styles.quickAccessContainer}>
                                    <TouchableOpacity style={styles.quickButton}>
                                        <Text style={styles.quickText}>Schedule</Text>
                                    </TouchableOpacity>
                                    <TouchableOpacity style={styles.quickButton}>
                                        <Text style={styles.quickText}>FAQs</Text>
                                    </TouchableOpacity>
                                </View>
                            </ScrollView>
        </>
    );

    return (
        <SafeAreaView style={styles.container}>
            {/* Register Modal */}
            <Modal transparent animationType="fade" visible={modalVisible} onRequestClose={() => setModalVisible(false)}>
                <View style={styles.modalOverlay}>
                    <View style={styles.modalContent}>
                        <Image
                            source={require('../../assets/images/t10stcl-card.webp')}
                            style={styles.modalImage}
                            resizeMode="contain"
                        />
                        <TouchableOpacity style={styles.registerButton} onPress={handleRegister}>
                            <Text style={styles.registerButtonText}>Register Now</Text>
                        </TouchableOpacity>
                        <TouchableOpacity onPress={() => setModalVisible(false)} style={styles.modalClose}>
                            <Icon name="x" size={24} color="#fff" />
                        </TouchableOpacity>
                    </View>
                </View>
            </Modal>

            {/* Top Tabs */}
            <View style={styles.tabs}>
                <TouchableOpacity
                    style={[styles.tabButton, activeTab === 'T10STCL' && styles.activeTab]}
                    onPress={() => setActiveTab('T10STCL')}
                >
                    <Text style={styles.tabText}>T10STCL</Text>
                </TouchableOpacity>
                <TouchableOpacity
                    style={[styles.tabButton, activeTab === 'Significant' && styles.activeTab]}
                    onPress={() => setActiveTab('Significant')}
                >
                    <Text style={styles.tabText}>Significant</Text>
                </TouchableOpacity>
            </View>

            {/* Scrollable Content */}
            <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
                {activeTab === 'T10STCL' ? renderT10STCLContent() : renderSignificantContent()}
            </ScrollView>
        </SafeAreaView>
    );
};

export default HomeScreen;

// Reuse the full T10STCL styles you've already written.
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#121212',
        marginTop: 30,
    },
    scrollContent: {
        paddingBottom: 120,
    },
    title: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#fff',
        padding: 16,
    },
    tabs: {
        flexDirection: 'row',
        marginHorizontal: 16,
        marginBottom: 10,
        marginTop:20,
    },
    tabButton: {
        flex: 1,
        backgroundColor: '#1E1E1E',
        padding: 12,
        marginRight: 8,
        borderRadius: 10,
        alignItems: 'center',
    },
    activeTab: {
        backgroundColor: '#333',
    },
    tabText: {
        color: '#fff',
        fontWeight: 'bold',
    },
    liveCard: {
        backgroundColor: '#1E1E1E',
        marginHorizontal: 16,
        borderRadius: 10,
        padding: 16,
        alignItems: 'center',
        marginBottom: 10,
    },
    liveTitle: {
        color: '#F5A623',
        fontWeight: 'bold',
        marginBottom: 4,
    },
    liveMatch: {
        color: '#fff',
        fontSize: 16,
        marginBottom: 4,
    },
    liveDate: {
        color: '#bbb',
        fontSize: 12,
    },
    liveBadge: {
        marginTop: 8,
        paddingVertical: 4,
        paddingHorizontal: 10,
        backgroundColor: 'red',
        borderRadius: 10,
    },
    liveBadgeText: {
        color: '#fff',
        fontSize: 12,
    },
    scoreBox: {
        backgroundColor: '#2A2A2A',
        borderRadius: 10,
        marginHorizontal: 16,
        flexDirection: 'row',
        paddingHorizontal: 40,
        justifyContent: 'space-between',
        padding: 30,
        alignItems: 'center',
    },
    scoreText: {
        color: '#fff',
        fontWeight: 'bold',
        fontSize: 14,
    },
    teamName: {
        color: '#F5A623',
        fontWeight: 'bold',
        fontSize: 14,
    },
    greeting: {
        fontSize: 20,
        color: '#fff',
        fontWeight: 'bold',
        paddingHorizontal: 16,
        marginTop: 20,
    },
    name: {
        color: '#F5A623',
        fontWeight: 'bold',
    },
    sectionLabel: {
        fontSize: 16,
        fontWeight: 'bold',
        color: '#ccc',
        paddingHorizontal: 16,
        marginTop: 20,
        marginBottom: 15,
    },
    sectionSubHeader: {
        color: '#bbb',
        paddingHorizontal: 16,
        marginTop: 10,
        marginBottom: 6,
    },
    newsCard: {
        backgroundColor: '#2A2A2A',
        borderRadius: 10,
        paddingVertical: 20,
        marginHorizontal: 16,
        flexDirection: 'row',
        padding: 12,
        marginBottom: 12,
    },
    newsLogo: {
        width: 90,
        height: 90,
        resizeMode: 'contain',
        marginRight: 12,
    },
    newsText: {
        flex: 1,
    },
    newsTitle: {
        color: '#fff',
        fontWeight: 'bold',
        fontSize: 17,
        marginTop: 5,
        marginBottom: 10,
    },
    newsSub: {
        color: '#aaa',
        fontSize: 13,
    },
    quickAccessContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginHorizontal: 16,
        marginBottom: 10,
    },
    quickButton: {
        backgroundColor: '#2A2A2A',
        flex: 0.48,
        padding: 14,
        borderRadius: 10,
        alignItems: 'center',
    },
    quickText: {
        color: '#fff',
        fontWeight: 'bold',
    },
    fixtureCard: {
        backgroundColor: '#2A2A2A',
        borderRadius: 10,
        marginHorizontal: 16,
        marginBottom: 12,
        flexDirection: 'row',
        padding: 12,
        paddingVertical: 20,
        alignItems: 'center',
        justifyContent: 'space-between',
    },
    teamLogo: {
        width: 90,
        height: 90,
        resizeMode: 'contain',
    },
    vsText: {
        color: '#fff',
        fontWeight: 'bold',
        fontSize: 16,
    },
    pointsCard: {
        backgroundColor: '#2A2A2A',
        marginHorizontal: 16,
        borderRadius: 10,
        padding: 16,
        marginBottom: 12,
        paddingVertical: 20,
        flexDirection: 'row',
    },
    teamLogoSmall: {
        width: 100,
        height: 100,
        resizeMode: 'contain',
        marginRight: 12,
        marginTop: 7,
    },
    teamTitle: {
        color: '#fff',
        fontWeight: 'bold',
        fontSize: 18,
        marginBottom: 10,
    },
    pointsInfo: {
        color: '#ccc',
        fontSize: 13,
    },
    statusIcons: {
        flexDirection: 'row',
        marginTop: 10,
    },
    statusDot: {
        width: 12,
        height: 12,
        borderRadius: 6,
        marginRight: 6,
    },
    modalOverlay: {
        flex: 1,
        backgroundColor: 'rgba(0,0,0,0.6)',
        justifyContent: 'center',
        alignItems: 'center',
    },
    modalContent: {
        width: '85%',
        backgroundColor: '#1E1E1E',
        borderRadius: 15,
        padding: 20,
        alignItems: 'center',
        position: 'relative',
    },
    modalImage: {
        width: '100%',
        height: 200,
        borderRadius: 5,
        marginBottom: 20,
    },
    registerButton: {
        backgroundColor: '#F5A623',
        width: '100%',
        paddingVertical: 18,
        paddingHorizontal: 30,
        borderRadius: 8,
    },
    registerButtonText: {
        color: '#121212',
        alignSelf: 'center',
        fontWeight: 'bold',
        fontSize: 16,
    },
    modalClose: {
        position: 'absolute',
        top: 10,
        right: 10,
    },
});




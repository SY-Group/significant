

//
// // Import the functions you need from the SDKs you need
// firebaseConfig.ts
// firebaseConfig.ts
// import { initializeApp, getApps, getApp } from 'firebase/app';
//
// import {
//     initializeAuth,
//     getReactNativePersistence,
//     getAuth,
// } from 'firebase/auth';
// import AsyncStorage from '@react-native-async-storage/async-storage';
//
// const firebaseConfig = {
//     apiKey: 'AIzaSyCJUjfMxFilcT3U9GbY9NI94q79JOYJ75U',
//     authDomain: 'significant-project-a65d5.firebaseapp.com',
//     projectId: 'significant-project-a65d5',
//     storageBucket: 'significant-project-a65d5.firebasestorage.app',
//     messagingSenderId: '654811083466',
//     appId: '1:654811083466:web:bda8521e3d5755c5fa7a33',
//     measurementId: 'G-LL0D4P2JES',
// };
//
// const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
//
// // ✅ Use initializeAuth with AsyncStorage
// const auth =
//     getApps().length === 0
//         ? initializeAuth(app, {
//             persistence: getReactNativePersistence(AsyncStorage),
//         })
//         : getAuth(app); // if already initialized
//
// export { auth };



// expo_client_id = 961817115168-idpdlsouecidvgaakc9rfcg087mboprj.apps.googleusercontent.com


// client_secret= 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
// clientID = 961817115168-i34jbnlviedv4dhtie5l50jabjsiua0l.apps.googleusercontent.com



// firebaseConfig.ts
// import { initializeApp, getApps, getApp } from 'firebase/app';
// import { getAuth } from 'firebase/auth';
//
// // ✅ Your Firebase project config
// const firebaseConfig = {
//     apiKey: 'AIzaSyCJUjfMxFilcT3U9GbY9NI94q79JOYJ75U',
//     authDomain: 'significant-project-a65d5.firebaseapp.com',
//     projectId: 'significant-project-a65d5',
//     storageBucket: 'significant-project-a65d5.appspot.com', // ✅ fixed from .app to .com
//     messagingSenderId: '654811083466',
//     appId: '1:654811083466:web:bda8521e3d5755c5fa7a33',
//     // measurementId is not needed in React Native (no analytics)
// };
//
// // ✅ Avoid duplicate Firebase App initialization
// const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
//
// // ✅ Firebase Auth with default memory persistence (Expo-compatible)
// const auth = getAuth(app);
//
// export { auth };
